// src/components/ModalRenderer.jsx
import { useCallback, useMemo } from 'react';
import { useSelector } from '../context/StoreContext';
import {
  TaskModal,
  ProjectModal,
  HoursRequestModal,
  RolesModal,
  DeptsModal,
  VacationModal,
  DelegationModal,
  VacNowModal,
  CreateEmployeeModal,
  EditEmployeeModal,
  YearCalendarModal,
  EmployeeTasksModal,
} from './Modals';
import { TemplateModal } from './Templates';
import { collectTaskPayloads } from '../utils/templateNesting';

export default function ModalRenderer({
  modal,
  onClose,
  ur,
  store,
  openTask,
  openProject,
  openHoursReq,
  openRoles,
  openDepts,
  openVacation,
  openDelegation,
  openEmployeeTasks,
  openCopyTask,
  openCopyProject,
  onTabChange,
  toast,
}) {
  const tasks       = useSelector(s => s.tasks);
  const projects    = useSelector(s => s.projects);
  const employees   = useSelector(s => s.employees);
  const vacations   = useSelector(s => s.vacations);
  const departments = useSelector(s => s.departments);
  const kbs         = useSelector(s => s.kbs);

  // db собирается не одним мешком, а мини-объектами под каждую модалку.
  //
  // Раньше здесь был один useMemo со всеми шестью срезами: любое изменение
  // vacations пересоздавало db → новая ссылка уезжала в ProjectModal,
  // HoursRequestModal, EmployeeTasksModal и т.д., которым vacations вообще
  // не нужны. Разбиение не отменяет ре-рендер ModalRenderer (он подписан
  // на все шесть срезов — они реально нужны разным модалкам), но убирает
  // каскад: модалка перерисовывается только когда изменился один из её
  // собственных срезов.
  //
  // Сигнатура пропса db у самих модалок не меняется — внутри они читают
  // те поля, которые им нужны. useDataHelpers корректно работает с
  // частичным db: недостающие срезы он берёт из стора (см. комментарий
  // в hooks/useDataHelpers.js).
  //
  // Какой мини-db кому:
  //   task         — tasks, projects, employees, departments, vacations
  //   project      — tasks, projects, employees, kbs
  //   hours        — tasks, projects
  //   vacation     — employees, departments, kbs, vacations
  //   delegation   — employees
  //   vacnow       — employees, departments, kbs, vacations
  //   employeeTasks— employees, tasks, projects
  //
  // RolesModal, DeptsModal, YearCalendarModal, CreateEmployeeModal,
  // EditEmployeeModal db вообще не принимают — работают через store.
  const taskDb = useMemo(
    () => ({ tasks, projects, employees, departments, vacations }),
    [tasks, projects, employees, departments, vacations],
  );
  const projectDb = useMemo(
    () => ({ tasks, projects, employees, kbs }),
    [tasks, projects, employees, kbs],
  );
  const hoursDb = useMemo(
    () => ({ tasks, projects }),
    [tasks, projects],
  );
  const vacationDb = useMemo(
    () => ({ employees, departments, kbs, vacations }),
    [employees, departments, kbs, vacations],
  );
  const delegationDb = useMemo(
    () => ({ employees }),
    [employees],
  );
  const vacNowDb = useMemo(
    () => ({ employees, departments, kbs, vacations }),
    [employees, departments, kbs, vacations],
  );
  const employeeTasksDb = useMemo(
    () => ({ employees, tasks, projects }),
    [employees, tasks, projects],
  );

  const handleError = useCallback((error) => {
    console.error(error);
    if (toast) toast(error.message || 'Произошла ошибка', 'error');
  }, [toast]);

  const reportTemplateResult = useCallback((label, res) => {
    if (!res) return;
    if (res.failed > 0) {
      toast?.(`${label}: создано ${res.created}, с ошибками ${res.failed}`, 'warning');
    } else if (res.created > 0) {
      toast?.(`${label}: создано ${res.created}`, 'success');
    }
  }, [toast]);

  const closeTaskWithReturn = useCallback(() => {
    if (modal.returnToEmployeeTasksId) {
      openEmployeeTasks(modal.returnToEmployeeTasksId);
      return;
    }
    if (modal.returnToTaskId) {
      openTask(modal.returnToTaskId, modal.returnToTaskTab || 'subtasks');
      return;
    }
    if (modal.returnToProjectId) {
      openProject(modal.returnToProjectId, modal.returnToProjectTab || 'info');
      return;
    }
    onClose();
  }, [modal, onClose, openEmployeeTasks, openTask, openProject]);

  const closeProjectWithReturn = useCallback(() => {
    if (modal.returnToProjectId) {
      openProject(modal.returnToProjectId, modal.returnToProjectTab || 'info');
      return;
    }
    onClose();
  }, [modal, onClose, openProject]);

  const handleTaskSave = useCallback(async (task, isNew, extras = {}) => {
    try {
      await store.upsertTask(task);
      if (extras.templateSubtasks?.length) {
        const res = store.instantiateTemplateSubtasks(task.id, extras.templateSubtasks);
        reportTemplateResult('Подзадачи из шаблона', res);
      }
      closeTaskWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, reportTemplateResult, closeTaskWithReturn, handleError]);

  const handleTaskDelete = useCallback(async (id) => {
    try {
      await store.deleteTask(id);
      closeTaskWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, closeTaskWithReturn, handleError]);

  const handleProjectSave = useCallback(async (p, isNew, extras = {}) => {
    try {
      await store.upsertProject(p);
      if (extras.templateTasks?.length) {
        const res = store.instantiateTemplateTasks(p.id, extras.templateTasks);
        reportTemplateResult('Задачи из шаблона', res);
      }
      closeProjectWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, reportTemplateResult, closeProjectWithReturn, handleError]);

  const handleProjectDelete = useCallback(async (id) => {
    try {
      await store.deleteProject(id);
      closeProjectWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, closeProjectWithReturn, handleError]);

  const handleHoursSubmit = useCallback(async (r) => {
    try {
      const directorIds = employees
        .filter(e => e.roles.includes('director') && !e.fired)
        .map(e => e.id);
      store.addHoursRequest(r, directorIds);
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [employees, store, onClose, handleError]);

  const handleVacationSave = useCallback(async (v) => {
    try {
      await store.upsertVacation(v);
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [store, onClose, handleError]);

  const handleDelegationSubmit = useCallback(async (rd) => {
    try {
      await store.upsertRoleDelegation(rd);
      store.notifyRoleDelegationCreated(rd);
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [store, onClose, handleError]);

  if (!modal) return null;

  switch (modal.type) {
    case 'task': {
      return (
        <TaskModal
          db={taskDb}
          ur={ur}
          taskId={modal.taskId}
          copyFromId={modal.copyFromId}
          initialTab={modal.initialTab || 'form'}
          parentTaskId={modal.parentTaskId}
          initialProjectId={modal.initialProjectId}
          returnToProjectId={modal.returnToProjectId}
          returnToTaskId={modal.returnToTaskId}
          returnToEmployeeTasksId={modal.returnToEmployeeTasksId}
          onClose={closeTaskWithReturn}
          onCopy={openCopyTask}
          onTabChange={onTabChange}
          onSave={handleTaskSave}
          onDelete={handleTaskDelete}
          onHoursReq={openHoursReq}
          store={store}
          openTask={openTask}
          toast={toast}
        />
      );
    }

    case 'project': {
      return (
        <ProjectModal
          db={projectDb}
          ur={ur}
          projectId={modal.projectId}
          copyFromId={modal.copyFromId}
          returnToProjectId={modal.returnToProjectId}
          initialTab={modal.initialTab || 'info'}
          onClose={closeProjectWithReturn}
          onCopy={openCopyProject}
          onTabChange={onTabChange}
          onSave={handleProjectSave}
          onDelete={handleProjectDelete}
          store={store}
          openTask={openTask}
          toast={toast}
        />
      );
    }

    case 'hours':
      return (
        <HoursRequestModal
          db={hoursDb}
          ur={ur}
          kind={modal.kind}
          targetId={modal.targetId}
          onClose={onClose}
          onSubmit={handleHoursSubmit}
          toast={toast}
        />
      );

    case 'roles':
      return (
        <RolesModal
          store={store}
          empId={modal.empId}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'depts':
      return (
        <DeptsModal
          store={store}
          empId={modal.empId}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'vacation':
      return (
        <VacationModal
          db={vacationDb}
          ur={ur}
          vacationId={modal.vacationId}
          forEmpId={modal.forEmpId || null}
          onClose={onClose}
          onSave={handleVacationSave}
          toast={toast}
        />
      );

    case 'delegation':
      return (
        <DelegationModal
          db={delegationDb}
          ur={ur}
          onClose={onClose}
          onSubmit={handleDelegationSubmit}
          toast={toast}
        />
      );

    case 'vacnow':
      return <VacNowModal db={vacNowDb} onClose={onClose} toast={toast} />;

    case 'yearCalendar':
      return <YearCalendarModal store={store} onClose={onClose} />;

    case 'employeeTasks':
      return (
        <EmployeeTasksModal
          db={employeeTasksDb}
          employeeId={modal.empId}
          openTask={openTask}
          onClose={onClose}
        />
      );

    case 'templateFromTask': {
      const task = tasks.find(t => t.id === modal.taskId);
      if (!task) return null;
      return (
        <TemplateModal
          mode="create"
          kind="task"
          source={task}
          nested={collectTaskPayloads(tasks, task.id)}
          onClose={onClose}
          toast={toast}
        />
      );
    }

    case 'templateFromProject': {
      const project = projects.find(p => p.id === modal.projectId);
      if (!project) return null;
      return (
        <TemplateModal
          mode="create"
          kind="project"
          source={project}
          nested={collectTaskPayloads(
            tasks.filter(t => t.projectId === project.id && !t.archived)
          )}
          onClose={onClose}
          toast={toast}
        />
      );
    }

    case 'createEmployee':
      return (
        <CreateEmployeeModal
          store={store}
          ur={ur}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'editEmployee':
      return (
        <EditEmployeeModal
          store={store}
          ur={ur}
          employeeId={modal.employeeId}
          onClose={onClose}
          toast={toast}
        />
      );

    default:
      return null;
  }
}