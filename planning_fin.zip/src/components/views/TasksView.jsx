// src/components/views/TasksView.jsx
import { useMemo, useState, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Kanban from '../Kanban';
import TasksList from './TasksList';
import FloatingMenu from '../FloatingMenu';
import { SearchBox } from '../SearchBox';
import { TASK_STATUSES, TASK_STATUS_ORDER, PRIORITIES } from '../../utils/constants';
import { fmtDMY, daysDiff, TODAY } from '../../utils/date';
import { isTaskActive } from '../../utils/entityState';
import { taskVisible, computeScope, hasRole, canCreateTask } from '../../utils/permissions';
import { changeTaskStatus, deleteTask } from '../../utils/taskActions';
import { useToast } from '../../context/ToastContext';
import { ICONS, Ic } from '../Icons';
import { useDataHelpers } from '../../hooks/useDataHelpers';
import { useFilters } from '../../hooks/useFilters';
import Avatar from '../Avatar';
import { getProjectColor } from '../../utils/projectHelpers';
import { buildTaskMenu } from '../menus';

const INITIAL_FILTERS = Object.freeze({
  projectId: 'all',
  assigneeId: 'all',
  priority: 'all',
  deptId: 'all',
  query: '',
  showOnlyMy: false,
});

function TasksView({
  ur, openTask, store,
  openCopyTask, openTemplateFromTask,
}) {
  const tasks       = useSelector(s => s.tasks);
  const projects    = useSelector(s => s.projects);
  const employees   = useSelector(s => s.employees);
  const departments = useSelector(s => s.departments);

  const db = useMemo(
    () => ({ tasks, projects, employees, departments }),
    [tasks, projects, employees, departments],
  );

  const { showToast } = useToast();
  const { getTaskSpent } = useDataHelpers(db);
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);
  const canSeeAll = hasRole(ur, 'admin', 'director', 'economist', 'kb_chief', 'head', 'project_lead', 'project_manager');

  const [viewMode, setViewMode] = useState('kanban');
  const { filters, setFilter } = useFilters(INITIAL_FILTERS);
  const { projectId, assigneeId, priority, deptId, query, showOnlyMy } = filters;

  const baseTasks = useMemo(
    () => tasks.filter(t => isTaskActive(t) && taskVisible(ur, scope, t, db)),
    [tasks, ur, scope, db],
  );

  const filteredTasks = useMemo(() => {
    let list = baseTasks;
    if (projectId !== 'all') list = list.filter(t => t.projectId === projectId);
    if (assigneeId !== 'all') list = list.filter(t => t.assigneeId === assigneeId);
    if (priority !== 'all') list = list.filter(t => t.priority === priority);
    if (deptId !== 'all') {
      list = list.filter(t => {
        const assignee = t.assigneeId ? employees.find(e => e.id === t.assigneeId) : null;
        return assignee && assignee.departments.some(d => d.deptId === deptId);
      });
    }
    if (query.trim()) {
      const s = query.trim().toLowerCase();
      list = list.filter(t =>
        t.title.toLowerCase().includes(s) ||
        (projects.find(p => p.id === t.projectId)?.name || '').toLowerCase().includes(s)
      );
    }
    if (showOnlyMy) list = list.filter(t => t.assigneeId === ur.id);
    return list;
  }, [baseTasks, employees, projects, ur, projectId, assigneeId, priority, deptId, query, showOnlyMy]);

  const projOptions = useMemo(() => {
    const ids = new Set(baseTasks.map(t => t.projectId).filter(Boolean));
    return projects.filter(p => ids.has(p.id) && !p.archived);
  }, [baseTasks, projects]);

  const execOptions = useMemo(() => {
    const ids = new Set(baseTasks.map(t => t.assigneeId).filter(Boolean));
    return employees.filter(e => ids.has(e.id));
  }, [baseTasks, employees]);

  const isOnlyExecutor = ur.roles.length === 1 && ur.roles[0] === 'executor';

  const handleMoveTask = (taskId, newStatus) => {
    const task = tasks.find(t => t.id === taskId);
    const ok = changeTaskStatus({ task, newStatus, user: ur, db, store });
    if (ok === false) {
      showToast('У вас нет прав на изменение статуса этой задачи.', 'error');
    }
  };

  const handleDeleteTask = (task) => {
    deleteTask({ task, store });
    showToast(`Задача «${task.title}» удалена`, 'success');
  };

  const renderTaskMenu = (task) => buildTaskMenu({
    task, user: ur, db, openTask,
    onMove: handleMoveTask,
    onDelete: handleDeleteTask,
    onCopy: openCopyTask,
    onMakeTemplate: openTemplateFromTask,
  });

  const renderTaskCard = (task) => {
    const p = projects.find(x => x.id === task.projectId);
    const assignee = task.assigneeId ? employees.find(e => e.id === task.assigneeId) : null;
    const sp = getTaskSpent(task);
    const overdue = task.deadline && !['closed', 'cancelled'].includes(task.status) && task.deadline < TODAY;
    const soon = task.deadline && !overdue && !['closed', 'cancelled'].includes(task.status) && daysDiff(TODAY, task.deadline) <= 3;
    const priorityDef = PRIORITIES[task.priority] || { label: task.priority || 'Нет', color: '#64748b' };

    return (
      <FloatingMenu items={renderTaskMenu(task)}>
        {({ anchorProps }) => (
          <div {...anchorProps} onClick={() => openTask(task.id)}>
            <div className="kcard-prio" style={{ background: priorityDef.color }} />
            <div className="kcard-title">{task.title}</div>
            <div className="kcard-proj">
              <span className="pdot" style={{ background: getProjectColor(p) }} />
              {p?.code}
            </div>
            <div className="kcard-meta">
              {assignee && (
                <span className="kassignee">
                  <Avatar employee={assignee} size="xs" />
                </span>
              )}
              <span className="khours">
                <Ic d={ICONS.clock} size={13} /> {sp}/{task.plannedHours ?? '-'} ч
              </span>
              <span className="prio-chip" style={{ color: priorityDef.color }}>
                {priorityDef.label}
              </span>
            </div>
            <div className="kcard-foot">
              <span className={'kdl' + (overdue ? ' late' : soon ? ' soon' : '')}>
                {task.deadline
                  ? (overdue
                    ? `просрочено ${-daysDiff(TODAY, task.deadline)} дн`
                    : `до ${fmtDMY(task.deadline)}`)
                  : 'без дедлайна'}
              </span>
            </div>
          </div>
        )}
      </FloatingMenu>
    );
  };

  const canCreate = canCreateTask(ur);

  return (
    <>
      <div className="toolbar">
        <div className="btn-group">
          <button
            className={`btn ghost sm ${viewMode === 'list' ? 'active' : ''}`}
            onClick={() => setViewMode('list')}
          >
            <Ic d={ICONS.list} size={15} /> Список
          </button>
          <button
            className={`btn ghost sm ${viewMode === 'kanban' ? 'active' : ''}`}
            onClick={() => setViewMode('kanban')}
          >
            <Ic d={ICONS.kanban} size={15} /> Канбан
          </button>
        </div>

        <SearchBox
          value={query}
          onChange={v => setFilter('query', v)}
          placeholder="Поиск..."
          className="filter-search"
        />

        <select
          className="inp sel sm filter-select"
          value={projectId}
          onChange={e => setFilter('projectId', e.target.value)}
        >
          <option value="all">Проект</option>
          {projOptions.map(p => <option key={p.id} value={p.id}>{p.code}</option>)}
        </select>

        {!isOnlyExecutor && (
          <select
            className="inp sel sm filter-select"
            value={assigneeId}
            onChange={e => setFilter('assigneeId', e.target.value)}
          >
            <option value="all">Исполнитель</option>
            {execOptions.map(e => <option key={e.id} value={e.id}>{e.last}</option>)}
          </select>
        )}

        <select
          className="inp sel sm filter-select"
          value={priority}
          onChange={e => setFilter('priority', e.target.value)}
        >
          <option value="all">Приоритет</option>
          {Object.entries(PRIORITIES).map(([k, v]) =>
            <option key={k} value={k}>{v.label}</option>)}
        </select>

        {!isOnlyExecutor && (
          <select
            className="inp sel sm filter-select"
            value={deptId}
            onChange={e => setFilter('deptId', e.target.value)}
          >
            <option value="all">Отдел</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        )}

        {canSeeAll && (
          <label className="dept-pick ml-auto">
            <input
              type="checkbox"
              checked={showOnlyMy}
              onChange={e => setFilter('showOnlyMy', e.target.checked)}
            />
            <span>Мои задачи</span>
          </label>
        )}

        {canCreate && (
          <button className="btn primary" onClick={() => openTask(null)}>
            <Ic d={ICONS.plus} size={15} /> Создать
          </button>
        )}
      </div>

      {viewMode === 'kanban' ? (
        <Kanban
          items={filteredTasks}
          statusOrder={TASK_STATUS_ORDER}
          statusMap={TASK_STATUSES}
          renderCard={renderTaskCard}
          onDrop={handleMoveTask}
        />
      ) : (
        <TasksList
          tasks={filteredTasks}
          db={db}
          user={ur}
          openTask={openTask}
          onMove={handleMoveTask}
          onDelete={handleDeleteTask}
          onCopy={openCopyTask}
          onMakeTemplate={openTemplateFromTask}
        />
      )}
    </>
  );
}

export default memo(TasksView);