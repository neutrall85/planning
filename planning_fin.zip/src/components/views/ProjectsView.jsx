// src/components/views/ProjectsView.jsx
import { useState, useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Kanban from '../Kanban';
import Projects from '../Projects';
import FloatingMenu from '../FloatingMenu';
import { SearchBox } from '../SearchBox';
import {
  PROJECT_STATUSES,
  PROJECT_TYPES,
  PROJECT_STATUS_CONFIG,
  PROJECT_STATUS_ORDER,
  PROJECT_PRIORITIES,
  DIALOGS,
  TOASTS,
} from '../../utils/constants';
import { TODAY } from '../../utils/date';
import { computeScope, hasRole, canChangeProjectStatus } from '../../utils/permissions';
import { Ic, ICONS } from '../Icons';
import Avatar from '../Avatar';
import { getProjectColor } from '../../utils/projectHelpers';
import ProjectProgress from '../ProjectProgress';
import { useToast } from '../../context/ToastContext';
import { useConfirm } from '../../context/ConfirmContext';
import { useFilters } from '../../hooks/useFilters';
import { buildProjectMenu } from '../menus';

const INITIAL_FILTERS = Object.freeze({
  query: '',
  status: 'all',
  type: 'all',
  priority: 'all',
  participant: 'all',
  deptId: 'all',
  showOnlyMy: false,
});

function ProjectsView({
  ur, openProject, store,
  openCopyProject, openTemplateFromProject,
}) {
  const projects    = useSelector(s => s.projects);
  const tasks       = useSelector(s => s.tasks);
  const employees   = useSelector(s => s.employees);
  const departments = useSelector(s => s.departments);

  const db = useMemo(
    () => ({ projects, tasks, employees, departments }),
    [projects, tasks, employees, departments],
  );

  const { showToast } = useToast();
  const { confirm } = useConfirm();
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);
  const [viewMode, setViewMode] = useState('kanban');
  const canSeeAll = hasRole(ur, 'admin', 'director', 'economist', 'kb_chief', 'head', 'project_lead', 'project_manager');

  const { filters, setFilter } = useFilters(INITIAL_FILTERS);
  const { query, status, type, priority, participant, deptId, showOnlyMy } = filters;

  const baseProjects = useMemo(() => {
    let list = scope.all
      ? projects.filter(p => !p.archived || p.status === 'closed' || p.status === 'cancelled')
      : projects.filter(p =>
          (!p.archived || p.status === 'closed' || p.status === 'cancelled') &&
          scope.projIds.has(p.id));
    if (showOnlyMy) {
      const myTasks = tasks.filter(t => t.assigneeId === ur.id && !t.archived);
      const myProjectIds = new Set(myTasks.map(t => t.projectId));
      list = list.filter(p => myProjectIds.has(p.id));
    }
    return list;
  }, [projects, tasks, scope, showOnlyMy, ur.id]);

  const participantOptions = useMemo(() => {
    const activeProjectIds = new Set(
      projects
        .filter(p => !p.archived || p.status === 'closed' || p.status === 'cancelled')
        .map(p => p.id)
    );
    const involvedIds = new Set();
    tasks.forEach(t => {
      if (activeProjectIds.has(t.projectId) && !t.archived && t.assigneeId) {
        involvedIds.add(t.assigneeId);
      }
    });
    return employees.filter(e => involvedIds.has(e.id));
  }, [projects, tasks, employees]);

  const deptOptions = useMemo(() => {
    const deptIds = new Set();
    participantOptions.forEach(e => e.departments.forEach(d => deptIds.add(d.deptId)));
    return departments.filter(d => deptIds.has(d.id));
  }, [participantOptions, departments]);

  const filteredProjects = useMemo(() => {
    let list = baseProjects;

    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.code && p.code.toLowerCase().includes(q))
      );
    }

    if (status !== 'all') list = list.filter(p => p.status === status);
    if (type !== 'all') list = list.filter(p => (p.ptype || 'prod') === type);
    if (priority !== 'all') list = list.filter(p => p.priority === priority);

    if (participant !== 'all') {
      const projectIdsWithParticipant = new Set();
      tasks.forEach(t => {
        if (!t.archived && t.assigneeId === participant) {
          projectIdsWithParticipant.add(t.projectId);
        }
      });
      list = list.filter(p => projectIdsWithParticipant.has(p.id));
    }

    if (deptId !== 'all') {
      const projectIdsWithDept = new Set();
      tasks.forEach(t => {
        if (!t.archived && t.assigneeId) {
          const assignee = employees.find(e => e.id === t.assigneeId);
          if (assignee && assignee.departments.some(d => d.deptId === deptId)) {
            projectIdsWithDept.add(t.projectId);
          }
        }
      });
      list = list.filter(p => projectIdsWithDept.has(p.id));
    }

    return list;
  }, [baseProjects, query, status, type, priority, participant, deptId, tasks, employees]);

  const handleMoveProject = (id, newStatus) => {
    const project = projects.find(p => p.id === id);
    if (!project || project.status === newStatus) return;
    if (!canChangeProjectStatus(ur, project, newStatus)) {
      showToast('У вас нет прав на изменение статуса этого проекта.', 'error');
      return;
    }
    store.upsertProject({ ...project, status: newStatus });
  };

  const handleCloseProject = async (project) => {
    const ok = await confirm(DIALOGS.closeProject(project.name));
    if (!ok) return;
    store.upsertProject({ ...project, status: 'closed', closedAt: TODAY });
    showToast(TOASTS.projectClosed, 'success');
  };

  const handleCancelProject = async (project) => {
    const ok = await confirm(DIALOGS.cancelProject(project.name));
    if (!ok) return;
    store.upsertProject({ ...project, status: 'cancelled' });
    showToast(TOASTS.projectCancelled, 'success');
  };

  const renderProjectMenu = (project) => buildProjectMenu({
    project, user: ur, openProject,
    onClose: handleCloseProject,
    onCancel: handleCancelProject,
    onCopy: openCopyProject,
    onMakeTemplate: openTemplateFromProject,
  });

  const renderProjectCard = (project) => {
    const list = tasks.filter(t => t.projectId === project.id && !t.archived);
    const plan = list.reduce((s, t) => s + (t.plannedHours || 0), 0);
    const fact = list.reduce((s, t) => s + t.logs.reduce((lsum, l) => lsum + l.hours, 0), 0);
    const uniqueAssignees = [...new Set(list.map(t => t.assigneeId).filter(Boolean))];
    const projectColor = getProjectColor(project);

    return (
      <FloatingMenu items={renderProjectMenu(project)}>
        {({ anchorProps }) => (
          <div {...anchorProps} onClick={() => openProject(project.id)}>
            <div className="kcard-title">{project.name}</div>
            <div className="kcard-proj">
              <span className="pdot" style={{ background: projectColor }} />
              {project.code}
            </div>
            <div className="kcard-meta">
              <span
                className="mut sm ml-8"
                style={{ color: PROJECT_PRIORITIES[project.priority]?.color || '#64748b' }}
              >
                {project.priority || 'NORM'}
              </span>
              <ProjectProgress project={project} plan={plan} fact={fact} />
            </div>
            <div className="kcard-foot">
              <div className="pj-avatars flex-1">
                {uniqueAssignees.slice(0, 4).map(id => {
                  const a = employees.find(e => e.id === id);
                  return a ? <Avatar key={id} employee={a} size="xs" /> : null;
                })}
                {uniqueAssignees.length > 4 && (
                  <span className="mut sm">+{uniqueAssignees.length - 4}</span>
                )}
              </div>
            </div>
          </div>
        )}
      </FloatingMenu>
    );
  };

  const canCreateProject = hasRole(ur, 'admin', 'director', 'kb_chief', 'project_manager');

  return (
    <>
      <div className="toolbar">
        <div className="btn-group">
          <button
            className={`btn ghost sm ${viewMode === 'list' ? 'active' : ''}`}
            onClick={() => setViewMode('list')}
          >
            <Ic d={ICONS.list} size={15} /> Список
          </button>
          <button
            className={`btn ghost sm ${viewMode === 'kanban' ? 'active' : ''}`}
            onClick={() => setViewMode('kanban')}
          >
            <Ic d={ICONS.kanban} size={15} /> Канбан
          </button>
        </div>

        <SearchBox
          value={query}
          onChange={v => setFilter('query', v)}
          placeholder="Поиск..."
          className="filter-search"
        />

        <select className="inp sel sm filter-select" value={status} onChange={e => setFilter('status', e.target.value)}>
          <option value="all">Статус</option>
          {Object.entries(PROJECT_STATUSES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>

        <select className="inp sel sm filter-select" value={type} onChange={e => setFilter('type', e.target.value)}>
          <option value="all">Тип</option>
          {Object.entries(PROJECT_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>

        <select className="inp sel sm filter-select" value={priority} onChange={e => setFilter('priority', e.target.value)}>
          <option value="all">Приоритет</option>
          {Object.entries(PROJECT_PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>

        <select className="inp sel sm filter-select" value={participant} onChange={e => setFilter('participant', e.target.value)}>
          <option value="all">Участник</option>
          {participantOptions.map(emp => (
            <option key={emp.id} value={emp.id}>{emp.last} {emp.first}</option>
          ))}
        </select>

        <select className="inp sel sm filter-select filter-select-dept" value={deptId} onChange={e => setFilter('deptId', e.target.value)}>
          <option value="all">Отдел</option>
          {deptOptions.map(dept => <option key={dept.id} value={dept.id}>{dept.name}</option>)}
        </select>

        {canSeeAll && (
          <label className="dept-pick ml-auto">
            <input
              type="checkbox"
              checked={showOnlyMy}
              onChange={e => setFilter('showOnlyMy', e.target.checked)}
            />
            <span>Проекты с моими задачами</span>
          </label>
        )}

        {canCreateProject && (
          <button className="btn primary" onClick={() => openProject(null)}>
            <Ic d={ICONS.plus} size={15} /> Проект
          </button>
        )}
      </div>

      {viewMode === 'kanban' ? (
        <Kanban
          items={filteredProjects}
          statusOrder={PROJECT_STATUS_ORDER}
          statusMap={PROJECT_STATUS_CONFIG}
          renderCard={renderProjectCard}
          onDrop={handleMoveProject}
          columns={4}
        />
      ) : (
        <Projects
          db={db}
          ur={ur}
          openProject={openProject}
          projects={filteredProjects}
          onCloseProject={handleCloseProject}
          onCancelProject={handleCancelProject}
          openCopyProject={openCopyProject}
          openTemplateFromProject={openTemplateFromProject}
        />
      )}
    </>
  );
}

export default memo(ProjectsView);