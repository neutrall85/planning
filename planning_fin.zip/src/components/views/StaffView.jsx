// src/components/views/StaffView.jsx
import { useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Staff from '../Staff';

function StaffView({
  store, ur, openRoles, openDepts, openVacation,
}) {
  const employees   = useSelector(s => s.employees);
  const departments = useSelector(s => s.departments);
  const kbs         = useSelector(s => s.kbs);
  const vacations   = useSelector(s => s.vacations);
  const tasks       = useSelector(s => s.tasks);

  const db = useMemo(
    () => ({ employees, departments, kbs, vacations, tasks }),
    [employees, departments, kbs, vacations, tasks],
  );

  return (
    <Staff
      store={store}
      db={db}
      ur={ur}
      setDb={store.setDb}
      openRoles={openRoles}
      openDepts={openDepts}
      openVacation={openVacation}
    />
  );
}

export default memo(StaffView);