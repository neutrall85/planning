// src/components/views/RequestsView.jsx
import { useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Requests from '../Requests';

function RequestsView({ ur }) {
  const hoursRequests   = useSelector(s => s.hoursRequests);
  const vacations       = useSelector(s => s.vacations);
  const roleDelegations = useSelector(s => s.roleDelegations);
  const regRequests     = useSelector(s => s.regRequests);
  const tasks           = useSelector(s => s.tasks);
  const projects        = useSelector(s => s.projects);
  const employees       = useSelector(s => s.employees);

  const db = useMemo(
    () => ({
      hoursRequests, vacations, roleDelegations, regRequests,
      tasks, projects, employees,
    }),
    [hoursRequests, vacations, roleDelegations, regRequests, tasks, projects, employees],
  );

  return <Requests db={db} ur={ur} initialTab="hours" />;
}

export default memo(RequestsView);