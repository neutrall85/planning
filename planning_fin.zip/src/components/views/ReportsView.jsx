// src/components/views/ReportsView.jsx
import { useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Reports from '../Reports';

function ReportsView({ ur }) {
  const tasks       = useSelector(s => s.tasks);
  const projects    = useSelector(s => s.projects);
  const employees   = useSelector(s => s.employees);
  const departments = useSelector(s => s.departments);
  const kbs         = useSelector(s => s.kbs);
  const vacations   = useSelector(s => s.vacations);

  const db = useMemo(
    () => ({ tasks, projects, employees, departments, kbs, vacations }),
    [tasks, projects, employees, departments, kbs, vacations],
  );

  return <Reports db={db} ur={ur} />;
}

export default memo(ReportsView);