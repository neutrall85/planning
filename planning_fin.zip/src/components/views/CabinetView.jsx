// src/components/views/CabinetView.jsx
import { useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Cabinet from '../Cabinet';

function CabinetView({
  store, user, openTask, openVacation, openDelegation,
}) {
  const tasks           = useSelector(s => s.tasks);
  const projects        = useSelector(s => s.projects);
  const employees       = useSelector(s => s.employees);
  const departments     = useSelector(s => s.departments);
  const kbs             = useSelector(s => s.kbs);
  const vacations       = useSelector(s => s.vacations);
  const roleDelegations = useSelector(s => s.roleDelegations);

  const data = useMemo(
    () => ({ tasks, projects, employees, departments, kbs, vacations, roleDelegations }),
    [tasks, projects, employees, departments, kbs, vacations, roleDelegations],
  );

  return (
    <Cabinet
      store={store}
      data={data}
      user={user}
      openTask={openTask}
      openVacation={openVacation}
      openDelegation={openDelegation}
    />
  );
}

export default memo(CabinetView);