// src/components/views/JournalView.jsx
import { useMemo, memo } from 'react';
import { useSelector } from '../../context/StoreContext';
import Journal from '../Journal';

function JournalView({ ur }) {
  const audit     = useSelector(s => s.audit);
  const employees = useSelector(s => s.employees);

  const db = useMemo(() => ({ audit, employees }), [audit, employees]);

  return <Journal db={db} />;
}

export default memo(JournalView);