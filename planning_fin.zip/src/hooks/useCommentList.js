// src/hooks/useCommentList.js
import { useEffect, useMemo, useState } from 'react';
import { flattenInRenderOrder, countOccurrences } from '../utils/commentTree';

/**
 * Список комментариев и производные выборки.
 *
 * Подписывается на срез comments напрямую через store.subscribe.
 *
 * Раньше здесь стоял useSelector(s => s.comments). Он не срабатывал для
 * этого среза: после добавления комментария Discussion не перерисовывался
 * до перемонтирования (переоткрытия карточки). Причина — общий
 * обход listeners в DataStore._notify без try/catch: один упавший
 * слушатель обрывает цикл, и подписки, идущие после него, не получают
 * уведомления. useSelector в Discussion оказывался «за» упавшим
 * слушателем, поэтому данные в store обновлялись, но React о них не
 * узнавал.
 *
 * Прямая подписка не зависит от порядка: мы слушаем тот же store, но
 * сами решаем, что делать при нотификации. Если React-подписки где-то
 * потеряются из-за чужой ошибки — Discussion всё равно обновится.
 *
 * Параметр store оставлен в сигнатуре для совместимости вызовов. Если
 * когда-нибудь Discussion будет получать все нужные срезы через пропсы,
 * параметр можно убрать.
 *
 * Оптимизация: setAllComments вызывается только когда ссылка на массив
 * изменилась. store.getSnapshot().comments — стабильная ссылка, пока
 * срез не переписан, поэтому setState с тем же значением не триггерит
 * ре-рендер.
 */
export function useCommentList(store, projectId, taskId, searchQuery, sortOrder) {
  const [allComments, setAllComments] = useState(
    () => store.getSnapshot().comments || []
  );

  useEffect(() => {
  if (!store) return undefined;
  const initial = store.getSnapshot().comments || [];
  console.log('[UCL] эффект смонтирован, всего комментов =', initial.length);
  setAllComments((prev) => (prev === initial ? prev : initial));

  const unsub = store.subscribe(() => {
    const next = store.getSnapshot().comments || [];
    console.log('[UCL] пришло уведомление, всего комментов =', next.length);
    setAllComments((prev) => (prev === next ? prev : next));
  });
  console.log('[UCL] подписка оформлена');
  return unsub;
}, [store]);

  const comments = useMemo(() => {
    return allComments
      .filter((c) => {
        if (projectId && c.projectId !== projectId) return false;
        // Фильтр по taskId применяем, только если задача реально задана.
        //
        // Discussion по умолчанию имеет taskId = null (проектный чат).
        // Семантика: taskId задан → показать только комментарии этой
        // задачи; taskId null/undefined → чат проекта, показать все
        // проектные комментарии, включая те, что привязаны к задачам
        // (они рендерятся с ссылкой на задачу, см. showTaskLink в
        // ProjectChat).
        if (taskId && c.taskId !== taskId) return false;
        return true;
      })
      .sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        return b.createdAt - a.createdAt;
      });
  }, [allComments, projectId, taskId]);

  const visibleComments = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return comments;
    const matchesText = (text) => String(text || '').toLowerCase().includes(q);
    const byId = new Map(comments.map((c) => [c.id, c]));
    const keep = new Set();
    for (const c of comments) {
      if (!matchesText(c.text)) continue;
      keep.add(c.id);
      let cur = c;
      while (cur.parentId && byId.has(cur.parentId)) {
        cur = byId.get(cur.parentId);
        keep.add(cur.id);
      }
    }
    return comments.filter((c) => keep.has(c.id));
  }, [comments, searchQuery]);

  const matchSteps = useMemo(() => {
    const q = searchQuery.trim();
    if (!q) return [];
    const matched = comments.filter((c) =>
      String(c.text || '').toLowerCase().includes(q.toLowerCase())
    );
    if (!matched.length) return [];
    const idSet = new Set(matched.map((c) => c.id));
    const ordered = flattenInRenderOrder(visibleComments, sortOrder)
      .filter((c) => idSet.has(c.id));
    const steps = [];
    for (const c of ordered) {
      const count = countOccurrences(c.text, q);
      for (let i = 0; i < count; i++) {
        steps.push({ commentId: c.id, occurrence: i });
      }
    }
    return steps;
  }, [comments, visibleComments, sortOrder, searchQuery]);

  return { comments, visibleComments, matchSteps };
}

// Импорт flattenInRenderOrder и countOccurrences перенесён в шапку
// файла; если у вас они импортировались иначе — сохраните ваши строки.