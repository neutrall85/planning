// src/repositories/Repository.js
//
// Базовый репозиторий.
//
// Конструктор принимает (collectionOrGetter, setter):
//   - collectionOrGetter — массив или () => массив (геттер из DataStore);
//   - setter             — (nextArray) => void, вызывается после save/delete.
//
// Если setter не передан, работаем в старом in-place режиме (мутация
// массива). Это для обратной совместимости с репозиториями, которые
// ещё не переведены на иммутабельные апдейты.
//
// Иммутабельный путь save/delete критичен: если писать в массив
// in-place, ссылка на срез не меняется и useSyncExternalStore
// не увидит изменения.
export class Repository {
  constructor(collectionOrGetter, setter = null) {
    this._get = typeof collectionOrGetter === 'function'
      ? collectionOrGetter
      : () => collectionOrGetter;
    this._set = setter;
  }

  get _collection() {
    return this._get();
  }

  findAll() {
    return this._collection;
  }

  findById(id) {
    return this._collection.find(item => item.id === id) || null;
  }

  save(item) {
    const collection = this._collection;
    const idx = collection.findIndex(i => i.id === item.id);

    if (this._set) {
      // Иммутабельный путь.
      if (idx >= 0) {
        if (collection[idx] === item) return item;
        const next = collection.slice();
        next[idx] = item;
        this._set(next);
      } else {
        this._set(collection.concat([item]));
      }
      return item;
    }

    // Legacy: без setter — мутируем in-place.
    if (idx >= 0) collection[idx] = item;
    else collection.push(item);
    return item;
  }

  delete(id) {
    const collection = this._collection;
    const idx = collection.findIndex(i => i.id === id);
    if (idx < 0) return false;

    if (this._set) {
      const next = collection.slice(0, idx).concat(collection.slice(idx + 1));
      this._set(next);
    } else {
      collection.splice(idx, 1);
    }
    return true;
  }

  find(predicate) {
    return this._collection.filter(predicate);
  }

  findOne(predicate) {
    return this._collection.find(predicate) || null;
  }
}