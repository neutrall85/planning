// src/hooks/useDataHelpers.js
import { useCallback } from 'react';

/**
 * Хелперы для чтения производных данных из db.
 *
 * Каждая функция мемоизирована через useCallback: её идентичность
 * стабильна между рендерами и меняется только при смене data. Без
 * этого empName и остальные возвращались бы новой ссылкой на каждом
 * рендере, и любой useCallback у потребителей (TaskModal, ProjectModal,
 * ModalRenderer) в списке зависимостей которого стоит empName —
 * пересоздавался бы каждый рендер, обесценивая саму мемоизацию.
 *
 * Гранулярность зависимостей выбрана по фактическому использованию:
 *
 *   empName            → data.employees
 *   primaryDept        → data.departments
 *   getTaskSpent       → ни одного поля data (работает только с task.logs)
 *   getProjectStats    → data.tasks (+ getTaskSpent)
 *   getEmployeeLoad    → data.tasks
 *   vacOverlap         → data.vacations
 *
 * `data` — снимок стора из StoreContext. Он получает новую идентичность
 * на каждый _notify(); это правильная гранулярность для потребителей:
 * данные изменились → хелперы пересоздались; данные те же → ссылки
 * сохранились.
 *
 * getTaskSpent объявлен первым потребителем независимо от data и потому
 * стабилен в течение всей жизни компонента (пустой список зависимостей).
 */
export const useDataHelpers = (data) => {
  const empName = useCallback((id) => {
    if (!data || !data.employees) return '-';
    const e = data.employees.find(x => x.id === id);
    return e ? `${e.last} ${e.first}` : '-';
  }, [data]);

  const primaryDept = useCallback((emp) => {
    if (!emp || !data || !data.departments) return null;
    const p = emp.departments?.find(x => x.primary) || emp.departments?.[0];
    return p ? data.departments.find(d => d.id === p.deptId) : null;
  }, [data]);

  const getTaskSpent = useCallback((task) => {
    if (!task || !task.logs || !Array.isArray(task.logs)) return 0;
    return task.logs.reduce((s, l) => s + (l.hours || 0), 0);
  }, []);

  const getProjectStats = useCallback((projectId) => {
    if (!data || !data.tasks) return { plan: 0, fact: 0, count: 0 };
    const tasks = data.tasks.filter(t => t.projectId === projectId && !t.archived);
    const plan = tasks.reduce((s, t) => s + (t.plannedHours || 0), 0);
    const fact = tasks.reduce((s, t) => s + getTaskSpent(t), 0);
    return { plan, fact, count: tasks.length };
  }, [data, getTaskSpent]);

  const getEmployeeLoad = useCallback((empId) => {
    if (!data || !data.tasks) return { plan: 0, cnt: 0 };
    const active = data.tasks.filter(
      t => !t.archived && t.assigneeId === empId && !['closed', 'cancelled'].includes(t.status)
    );
    return { plan: active.reduce((s, t) => s + (t.plannedHours || 0), 0), cnt: active.length };
  }, [data]);

  const vacOverlap = useCallback((empId, from, to) => {
    if (!data || !data.vacations || !from || !to) return null;
    return data.vacations.find(
      v => v.empId === empId && v.status === 'approved' && v.start <= to && v.end >= from
    ) || null;
  }, [data]);

  return { empName, primaryDept, getTaskSpent, getProjectStats, getEmployeeLoad, vacOverlap };
};