import { useCallback, useRef, useState } from 'react';

export function useModals({ store, data, user }) {
  const [modal, setModal] = useState(null);

  // Счётчик монтирований модалок. MainLayout использует его как key у
  // ModalRenderer: при каждом открытии модалка монтируется с нуля, поэтому
  // внутреннее состояние useForm инициализируется новыми initialValues.
  const seqRef = useRef(0);

  const open = (state) => {
    seqRef.current += 1;
    setModal({ ...state, _seq: seqRef.current });
  };

  /**
   * Открыть карточку задачи.
   *
   * returnToEmployeeTasksId — id сотрудника, к списку задач которого
   * нужно вернуться при закрытии карточки. Используется, когда TaskModal
   * открыта из «Задач сотрудника» (WorkloadView → EmployeeTasksModal).
   * При закрытии ModalRenderer снова вызовет openEmployeeTasks с этим id.
   * Симметрично существующим returnToProjectId / returnToTaskId.
   */
  const openTask = (
    taskId = null,
    initialTab = 'form',
    parentTaskId = null,
    initialProjectId = null,
    returnToProjectId = null,
    returnToProjectTab = 'info',
    returnToTaskId = null,
    returnToTaskTab = 'subtasks',
    returnToEmployeeTasksId = null,
  ) =>
    open({
      type: 'task',
      taskId,
      initialTab,
      parentTaskId,
      initialProjectId,
      returnToProjectId,
      returnToProjectTab,
      returnToTaskId,
      returnToTaskTab,
      returnToEmployeeTasksId,
    });

  const openProject = (
    projectId = null,
    initialTab = 'info',
    returnToProjectId = null,
    returnToProjectTab = 'info'
  ) =>
    open({
      type: 'project',
      projectId,
      initialTab,
      returnToProjectId,
      returnToProjectTab,
    });

  const openHoursReq = (kind, targetId) => open({ type: 'hours', kind, targetId });
  const openRoles = (empId) => open({ type: 'roles', empId });
  const openDepts = (empId) => open({ type: 'depts', empId });
  const openVacation = (vacationId = null, forEmpId = null) =>
    open({ type: 'vacation', vacationId, forEmpId });
  const openDelegation = () => open({ type: 'delegation' });
  const openVacNow = () => open({ type: 'vacnow' });
  const openYearCalendar = () => open({ type: 'yearCalendar' });

  /**
   * Список задач сотрудника. Открывается из WorkloadView при клике на
   * строку. Не путать с openTask: это обзорный список, а не редактируемая
   * сущность — своей формы у него нет.
   */
  const openEmployeeTasks = (empId) => open({ type: 'employeeTasks', empId });

  // Копирование = «шаблон из живой сущности»: тот же конвейер черновиков
  // (collectTaskPayloads → pendingTemplate* → instantiateTemplate*), что и
  // при сохранении в шаблон. Никаких новых путей создания задач/подзадач.
  const openCopyTask = (sourceTaskId) =>
    open({
      type: 'task',
      taskId: null,
      copyFromId: sourceTaskId,
      initialTab: 'form',
      parentTaskId: null,
      initialProjectId: null,
      returnToProjectId: null,
      returnToProjectTab: 'info',
      returnToTaskId: sourceTaskId,
      returnToTaskTab: 'form',
    });

  const openCopyProject = (sourceProjectId) =>
    open({
      type: 'project',
      projectId: null,
      copyFromId: sourceProjectId,
      initialTab: 'info',
      returnToProjectId: sourceProjectId,
      returnToProjectTab: 'info',
    });

  // Сохранить задачу как шаблон. Открывает TemplateModal в режиме
  // создания — ту же модалку, что и кнопка «В шаблон» в карточке задачи.
  // Отдельный тип модалки, а не прямая передача TemplateModal из вьюхи:
  // TemplateModal использует useNestedModalEscape и useStore, что делает
  // его полноценной модалкой приложения, а не локальным попапом.
  const openTemplateFromTask = (taskId) =>
    open({ type: 'templateFromTask', taskId });

  // Симметрично openTemplateFromTask, для проекта.
  const openTemplateFromProject = (projectId) =>
    open({ type: 'templateFromProject', projectId });

  /**
   * Запомнить активную вкладку модалки, чтобы URL её отражал.
   * Компонент модалки не перемонтируется (key=_seq не меняется),
   * поэтому локальный activeTab в TaskModal / ProjectModal остаётся
   * актуальным; сюда попадает лишь «какая вкладка сейчас открыта».
   */
  const setModalTab = useCallback((tab) => {
    setModal((prev) => (prev ? { ...prev, initialTab: tab } : prev));
  }, []);

  const closeModal = () => setModal(null);

  return {
    modal,
    openTask,
    openProject,
    openHoursReq,
    openRoles,
    openDepts,
    openVacation,
    openDelegation,
    openVacNow,
    openYearCalendar,
    openEmployeeTasks,
    openCopyTask,
    openCopyProject,
    openTemplateFromTask,
    openTemplateFromProject,
    closeModal,
    setModalTab,
  };
}