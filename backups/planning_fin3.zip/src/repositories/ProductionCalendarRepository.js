// src/repositories/ProductionCalendarRepository.js
//
// Репозиторий производственного календаря.
//
// Не наследует Repository: базовый класс построен вокруг id, а здесь ключ —
// год. Наследование дало бы «тихий» findById(), всегда возвращающий null,
// и save(), создающий дубликаты, — классическое нарушение LSP. Проще явно
// объявить нужные методы, чем притворяться обычным репозиторием.
export class ProductionCalendarRepository {
  constructor(years) {
    this._collection = years;
  }

  findAll() {
    return this._collection;
  }

  findByYear(year) {
    return this._collection.find(e => e.year === year) || null;
  }

  saveByYear(entry) {
    const idx = this._collection.findIndex(e => e.year === entry.year);
    if (idx >= 0) {
      this._collection[idx] = entry;
    } else {
      this._collection.push(entry);
    }
    return entry;
  }

  deleteByYear(year) {
    const idx = this._collection.findIndex(e => e.year === year);
    if (idx >= 0) {
      this._collection.splice(idx, 1);
      return true;
    }
    return false;
  }
}