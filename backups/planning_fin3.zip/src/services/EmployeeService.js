// src/services/EmployeeService.js
import { uid } from '../utils/date';
import { ROLES } from '../utils/constants';
import {
  auditLabel,
  auditDetails,
  auditDelta,
  auditToggle,
  auditSet,
  auditMark,
} from '../utils/auditHelpers';

export class EmployeeService {
  constructor(employeeRepo, auditService, notifyCallback) {
    this._employeeRepo = employeeRepo;
    this._audit = auditService;
    this._notify = notifyCallback;
  }

  getAll() {
    return this._employeeRepo.findAll();
  }

  upsertEmployee(emp, currentUserId) {
    const existing = this._employeeRepo.findById(emp.id);
    if (existing) {
      const changes = this._describeChanges(existing, emp);
      // Пустой дифф — реальных изменений нет. Запись в аудит не пишем:
      // иначе Save без правок даст пустую строку «Изменение сотрудника».
      if (Object.keys(changes).length > 0) {
        this._audit.addAudit(
          'Изменение сотрудника',
          auditDetails('Сотрудник', `${emp.last} ${emp.first}`, changes),
          'employee',
          emp.id,
          currentUserId,
        );
      }
    } else {
      this._audit.addAudit('Создание сотрудника', `${emp.last} ${emp.first}`, 'employee', emp.id, currentUserId);
    }
    this._employeeRepo.save(emp);
    this._notify();
  }

  _describeChanges(existing, next) {
    const changes = {};

    auditToggle(changes, 'Статус', existing.fired, next.fired, 'Уволен', 'Восстановлен');

    const rolesAdded = (next.roles || []).filter(r => !(existing.roles || []).includes(r));
    const rolesRemoved = (existing.roles || []).filter(r => !(next.roles || []).includes(r));
    if (rolesAdded.length) changes['Добавлены роли'] = rolesAdded.map(r => auditLabel(ROLES, r)).join(', ');
    if (rolesRemoved.length) changes['Убраны роли'] = rolesRemoved.map(r => auditLabel(ROLES, r)).join(', ');

    auditSet(changes, 'Подразделения', existing.departments, next.departments, (d) => d.deptId);
    auditSet(changes, 'КБ', existing.kbIds, next.kbIds);
    auditSet(changes, 'Руководимые отделы', existing.headDeptIds, next.headDeptIds);

    auditDelta(changes, 'Должность', existing.position, next.position);
    auditDelta(changes, 'E-mail', existing.email, next.email);
    auditDelta(changes, 'Телефон', existing.phone, next.phone);
    auditDelta(changes, 'Внутренний номер', existing.extension, next.extension);

    auditMark(changes, 'Пароль', existing.pass, next.pass, 'изменён');

    return changes;
  }

  getEmployeeName(id) {
    const e = this._employeeRepo.findById(id);
    return e ? `${e.last} ${e.first}` : '-';
  }

  findByEmail(email) {
    return this._employeeRepo.findByEmail(email);
  }

  registerEmployee({ first, last, email, pass, position = 'Сотрудник' }, actorId = 'system') {
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!normalizedEmail) throw new Error('E-mail обязателен');
    if (this._employeeRepo.findByEmail(normalizedEmail)) {
      throw new Error('Сотрудник с таким e-mail уже существует');
    }

    const emp = {
      id: 'e_' + uid(),
      last: String(last || '').trim(),
      first: String(first || '').trim(),
      email: normalizedEmail,
      pass,
      position,
      departments: [],
      roles: ['executor'],
      kbIds: [],
      headDeptIds: [],
      phone: '',
      extension: '',
      tab: String(1000 + Math.floor(Math.random() * 8999)),
      notif: { deadlineEmail: true, overdueDigest: false, commentSub: true },
      failed: 0,
      lockUntil: 0,
      fired: false,
      photo: null,
      passwordHistory: [],
    };

    this._employeeRepo.save(emp);
    this._audit.addAudit('Регистрация сотрудника', `${emp.last} ${emp.first}`, 'employee', emp.id, actorId);
    this._notify();
    return emp;
  }
}