import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { useAuth, useStore, useHashRoute } from '../hooks';
import {
  hasRole,
  canExport,
  computeScope,
  taskVisible,
  projectVisible,
} from '../utils/permissions';
import { ICONS, Ic } from './Icons';
import { initials } from '../utils/date';
import NotifPanel from './NotifPanel';
import { useModals } from '../hooks/useModals';
import ModalRenderer from './ModalRenderer';
import * as Views from './views';
import Calendar from './Calendar';
import Gantt from './Gantt';
import { useToast } from '../context/ToastContext';
import { ROUTE, DEFAULT_TAB, buildRoute } from '../utils/routes';

export default function MainLayout({ store, data, user }) {
  const { logout } = useStore();
  const { showToast } = useToast();
  const [view, setView] = useState('tasks');
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef(null);

  const {
    modal,
    openTask,
    openProject,
    openHoursReq,
    openRoles,
    openDepts,
    openVacation,
    openDelegation,
    openVacNow,
    openYearCalendar,
    openEmployeeTasks,
    openCopyTask,
    openCopyProject,
    openTemplateFromTask,
    openTemplateFromProject,
    closeModal,
    setModalTab,
  } = useModals({ store, data, user });

  const { route, navigate } = useHashRoute();

  const scope = useMemo(() => computeScope(user, data), [user, data]);

  // Правка производственного календаря живёт во вкладке личного кабинета
  // (см. Cabinet) и доступна только суперадминистратору. В сайдбаре её нет.
  const navItems = [
    { id: 'tasks', label: 'Задачи', icon: ICONS.tasks },
    { id: 'gantt', label: 'Диаграмма Ганта', icon: ICONS.gantt },
    { id: 'calendar', label: 'Календарь', icon: ICONS.cal },
    { id: 'projects', label: 'Проекты', icon: ICONS.folder },
    { id: 'templates', label: 'Шаблоны', icon: ICONS.bookmark },
    { id: 'staff', label: 'Персонал', icon: ICONS.users },
    { id: 'workload', label: 'Загрузка сотрудников', icon: ICONS.users },
    ...(canExport(user) || hasRole(user, 'kb_chief', 'head', 'project_lead', 'hr')
      ? [{ id: 'reports', label: 'Отчёты', icon: ICONS.chart }]
      : []),
    { id: 'archive', label: 'Архив', icon: ICONS.archive },
    { id: 'requests', label: 'Запросы и заявки', icon: ICONS.inbox },
    ...(hasRole(user, 'admin', 'director') ? [{ id: 'journal', label: 'Журнал аудита', icon: ICONS.book }] : []),
  ];

  const myNotifs = data.notifications.filter((n) => n.userId === user.id);
  const unread = myNotifs.filter((n) => !n.read).length;

  const handleNotificationNavigate = (notification) => {
    const { targetType, targetId } = notification;
    if (!targetType || !targetId) return;
    store.markNotificationRead(notification.id);
    switch (targetType) {
      case 'task': openTask(targetId, 'chat'); break;
      case 'project': openProject(targetId); break;
      case 'hours': setView('requests'); break;
      case 'vacation': openVacation(targetId); break;
      case 'delegation': setView('requests'); break;
      case 'registration': setView('requests'); break;
      default: break;
    }
    setNotifOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (notifOpen && notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    };
    const handleEsc = (e) => {
      if (e.key === 'Escape' && notifOpen) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [notifOpen]);

  /**
   * Что вообще выразимо в URL — отдельно от того, когда это записывать.
   * Возвращаем СТРОКУ, а не объект: сравнение строк в deps эффекта идёт
   * по значению, поэтому churn объекта modal (новая ссылка на тот же
   * смысл) не запускает эффект заново. Это устраняет петлю
   * «state → URL → state», которая возникала, когда deps были объектом:
   * объект-дескриптор менял идентичность каждый рендер, useEffect
   * перезапускался, navigate → setState → ре-рендер → снова.
   *
   *   - открытая существующая задача → '#/task/<id>/<tab>'
   *   - открытый существующий проект → '#/project/<id>/<tab>'
   *   - служебные модалки            → '' (URL не трогаем)
   *   - всё остальное                → '#/view/<view>'
   *
   * buildRoute сам почистит некорректные id/вкладки (белые списки в
   * utils/routes.js) и вернёт '' для невалидного ввода — тогда эффект
   * ниже просто не вызовет navigate.
   */
  const desiredHash = useMemo(() => {
    if (modal?.type === 'task' && modal.taskId) {
      return buildRoute({
        kind: ROUTE.TASK,
        id: modal.taskId,
        tab: modal.initialTab || DEFAULT_TAB[ROUTE.TASK],
      });
    }
    if (modal?.type === 'project' && modal.projectId) {
      return buildRoute({
        kind: ROUTE.PROJECT,
        id: modal.projectId,
        tab: modal.initialTab || DEFAULT_TAB[ROUTE.PROJECT],
      });
    }
    if (modal) return '';
    return buildRoute({ kind: ROUTE.VIEW, id: view });
  }, [modal, view]);

  // Свежий view для denyAccess. Нужен ref, а не замыкание: denyAccess
  // вызывается из эффекта, у которого route в deps — view там может
  // быть устаревшим, если между двумя правками URL он успел смениться.
  const viewRef = useRef(view);
  useEffect(() => { viewRef.current = view; }, [view]);

  /**
   * Ссылка ведёт на сущность, к которой у пользователя нет доступа.
   * Показываем тост, закрываем модалку и уводим URL на дефолтный view —
   * иначе плохая ссылка осталась бы в адресной строке, и обновление
   * страницы показывало бы то же самое без объяснений.
   *
   * Формулировка единая для «объекта нет» и «нет прав». Разделять их —
   * значит сообщать пользователю, существует ли недоступная сущность;
   * для внутреннего инструмента это лишняя утечка.
   *
   * Идентичность стабильна: viewRef.current читается в момент вызова,
   * а не при создании функции.
   */
  const denyAccess = useCallback(() => {
    showToast('Доступ запрещён', 'error');
    closeModal();
    const fallback = buildRoute({ kind: ROUTE.VIEW, id: viewRef.current });
    if (fallback) navigate(fallback);
  }, [showToast, closeModal, navigate]);

  // (1) state → URL. Первый рендер пропускаем: URL уже пришёл с сервера,
  //     его нужно прочитать, а не перезаписывать дефолтом.
  //
  //     Зависимость — строка desiredHash, а не объект-дескриптор:
  //     сравнение по значению гарантирует, что эффект перезапускается
  //     ровно тогда, когда URL должен реально измениться. Сам navigate
  //     тоже идемпотентен (проверяет window.location.hash === hash) —
  //     двойная защита от петли.
  const firstRouteWriteRef = useRef(true);
  useEffect(() => {
    if (firstRouteWriteRef.current) {
      firstRouteWriteRef.current = false;
      return;
    }
    if (desiredHash) navigate(desiredHash);
  }, [desiredHash, navigate]);

  // (2) URL → state. Гарды сравнивают маршрут с текущим состоянием —
  //     на «своём» эхо-переходе (мы сами обновили hash) ничего не делают,
  //     поэтому петли React → URL → React не возникает.
  //
  //     Перед открытием сущности проверяем её видимость для текущего
  //     пользователя: taskVisible / projectVisible. Это единственное
  //     место, где права применяются к URL, — компоненты модалок про
  //     права ничего не знают и получают уже отфильтрованную сущность.
  useEffect(() => {
    if (!route) return;

    if (route.kind === ROUTE.VIEW) {
      if (!navItems.some((n) => n.id === route.id)) return;
      if (view !== route.id) setView(route.id);
      if (modal) closeModal();
      return;
    }

    if (route.kind === ROUTE.TASK) {
      const task = data.tasks.find((t) => t.id === route.id);
      if (!task || !taskVisible(user, scope, task, data)) {
        denyAccess();
        return;
      }
      if (modal?.type === 'task' && modal.taskId === route.id && modal.initialTab === route.tab) return;
      openTask(route.id, route.tab);
      return;
    }

    if (route.kind === ROUTE.PROJECT) {
      const project = data.projects.find((p) => p.id === route.id);
      if (!project || !projectVisible(scope, project)) {
        denyAccess();
        return;
      }
      if (modal?.type === 'project' && modal.projectId === route.id && modal.initialTab === route.tab) return;
      openProject(route.id, route.tab);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route]);

  // (3) Права отозваны, пока модалка открыта. Первый прогон после
  //     открытия ничего не делает (видимость только что проверена в
  //     эффекте (2)), а при изменении data — перепроверяет и закрывает
  //     модалку с тем же сообщением.
  useEffect(() => {
    if (!modal) return;

    if (modal.type === 'task' && modal.taskId) {
      const task = data.tasks.find((t) => t.id === modal.taskId);
      if (!task || !taskVisible(user, scope, task, data)) {
        denyAccess();
      }
      return;
    }

    if (modal.type === 'project' && modal.projectId) {
      const project = data.projects.find((p) => p.id === modal.projectId);
      if (!project || !projectVisible(scope, project)) {
        denyAccess();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modal, data, scope, user]);

  const renderView = () => {
    // commonProps — то, что реально используется всеми (или почти всеми)
    // вью. Всё узкое (openEmployeeTasks только для WorkloadView) —
    // передаётся явно в конкретный case.
    const commonProps = { db: data, ur: user, openTask, openProject, store };
    switch (view) {
      case 'tasks':
        return (
          <Views.TasksView
            {...commonProps}
            openCopyTask={openCopyTask}
            openTemplateFromTask={openTemplateFromTask}
          />
        );
      case 'gantt': return <Gantt {...commonProps} />;
      case 'calendar':
        return (
          <Calendar
            {...commonProps}
            openCopyTask={openCopyTask}
            openTemplateFromTask={openTemplateFromTask}
          />
        );
      case 'projects':
        return (
          <Views.ProjectsView
            {...commonProps}
            openCopyProject={openCopyProject}
            openTemplateFromProject={openTemplateFromProject}
          />
        );
      case 'templates': return <Views.TemplatesView />;
      case 'cabinet':
        return (
          <Views.CabinetView
            store={store}
            data={data}
            user={user}
            openTask={openTask}
            openVacation={openVacation}
            openDelegation={openDelegation}
          />
        );
      case 'staff':
        return (
          <Views.StaffView
            store={store}
            db={data}
            ur={user}
            setDb={store.setDb}
            openRoles={openRoles}
            openDepts={openDepts}
            openVacation={openVacation}
          />
        );
      case 'reports': return <Views.ReportsView db={data} ur={user} />;
      case 'workload': return <Views.WorkloadView {...commonProps} openEmployeeTasks={openEmployeeTasks} />;
      case 'archive':
        return (
          <Views.ArchiveView
            db={data}
            ur={user}
            openTask={openTask}
            openProject={openProject}
            setArchiveMonths={store.setArchiveMonths}
            store={store}
          />
        );
      case 'requests':
        return (
          <Views.RequestsView
            db={data}
            setDb={store.setDb}
            ur={user}
            addAudit={store.addAudit}
            notifyVacationDecision={store.notifyVacationDecision}
            notifyRoleDelegationDecision={store.notifyRoleDelegationDecision}
            notifyHoursRequestDecision={store.notifyHoursRequestDecision}
          />
        );
      case 'journal': return <Views.JournalView db={data} ur={user} />;
      default: return null;
    }
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="logo">
          <div className="logo-mark">АП</div>
          <div>
            <div className="logo-name">АвиаГоризонт</div>
            <div className="logo-sub">планирование и учёт времени</div>
          </div>
        </div>
        <div className="user-card cursor-pointer mb-4" onClick={() => setView('cabinet')}>
          <div className="avatar">
            {user.photo ? (
              <img src={user.photo} alt="Аватар" className="user-card-photo" />
            ) : initials(user.first, user.last)}
          </div>
          <div className="user-meta">
            <div className="user-name">{user.last} {user.first}</div>
            <div className="user-roles">{user.roles.join(' · ')}</div>
          </div>
          <button
            className="icon-btn dark"
            onClick={(e) => { e.stopPropagation(); logout(); }}
            title="Выйти"
          >
            <Ic d={ICONS.out} size={16} />
          </button>
        </div>
        <nav className="nav">
          {navItems.map((n) => (
            <button
              key={n.id}
              className={`nav-item${view === n.id ? ' on' : ''}`}
              onClick={() => setView(n.id)}
            >
              <Ic d={n.icon} /> <span className="nav-lbl">{n.label}</span>
            </button>
          ))}
        </nav>
        <div className="side-foot">
          <div className="env-badge">
            <Ic d={ICONS.shield} size={14} /> Демо · заглушка Java/PostgreSQL
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <h1 className="page-title">
              {navItems.find((n) => n.id === view)?.label || 'Личный кабинет'}
            </h1>
            <div className="page-sub">
              {new Date().toLocaleDateString('ru-RU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              {' '}· вы вошли как {user.last} {user.first}
            </div>
          </div>
          <div className="top-tools">
            <button className="btn ghost" onClick={openVacNow}>
              <Ic d={ICONS.beach} size={15} /> Сотрудники в отпусках
            </button>
            <button className="btn ghost" onClick={openYearCalendar}>
              <Ic d={ICONS.cal} size={15} /> Производственный календарь
            </button>
            <div className="bell-wrap" ref={notifRef}>
              <button
                className={`icon-btn bell${unread ? ' has' : ''}`}
                onClick={() => setNotifOpen((v) => !v)}
              >
                <Ic d={ICONS.bell} size={17} />
                {unread > 0 && <span className="bell-count">{unread}</span>}
              </button>
              {notifOpen && (
                <NotifPanel
                  list={myNotifs}
                  currentUserId={user.id}
                  markAllRead={store.markAllNotificationsRead}
                  onNavigate={handleNotificationNavigate}
                  onClose={() => setNotifOpen(false)}
                />
              )}
            </div>
          </div>
        </header>

        <div className="content">{renderView()}</div>
      </main>

      {modal && (
        <ModalRenderer
          key={modal._seq}
          modal={modal}
          onClose={closeModal}
          db={data}
          ur={user}
          store={store}
          openTask={openTask}
          openProject={openProject}
          openHoursReq={openHoursReq}
          openRoles={openRoles}
          openDepts={openDepts}
          openVacation={openVacation}
          openDelegation={openDelegation}
          openEmployeeTasks={openEmployeeTasks}
          openCopyTask={openCopyTask}
          openCopyProject={openCopyProject}
          onTabChange={setModalTab}
          toast={showToast}
        />
      )}
    </div>
  );
}