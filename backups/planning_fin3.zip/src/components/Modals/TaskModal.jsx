// src/components/Modals/TaskModal.jsx
import { useState, useMemo, useCallback, useEffect, useLayoutEffect, useRef } from 'react';
import { ModalShell } from '../ModalShell';
import { Tabs } from '../Tabs';
import { FileManager } from '../FileManager';
import { TaskTable } from '../TaskTable';
import { FormField } from '../FormField';
import Discussion from '../Discussion';
import NoteEditorModal from './NoteEditorModal';
import { useForm } from '../../hooks/useForm';
import { useDataHelpers, useStableModalHeight, useControlledTab } from '../../hooks';
import { useConfirm } from '../../context/ConfirmContext';
import { TASK_STATUSES, TASK_STATUS_ORDER, PRIORITIES, DEPENDENCY_TYPES, DIALOGS, TOASTS } from '../../utils/constants';
import { TODAY, iso, addDays, uid, fmtDMY, fmtD, fmtDT } from '../../utils/date';
import {
  canEditTaskFields,
  canChangeTaskStatus,
  canCreateTask,
  computeScope,
} from '../../utils/permissions';
import { isArchived } from '../../utils/entityState';
import { prepareAttachments } from '../../utils/fileUpload';
import { createFolder } from '../../utils/fileTree';
import { Ic, ICONS } from '../Icons';
import { TemplateSelect, TemplateActions } from '../Templates';
import { applyTemplatePayload } from '../../utils/templateSchemas';
import { collectTaskPayloads } from '../../utils/templateNesting';
import { applyHourlyMode, hoursBetween } from '../../utils/hourlyTask';

/**
 * Убирает поле notes из задачи перед подачей в useForm.
 * По образцу stripAccess в ProjectModal: поле, которое редактируется
 * отдельным путём (не через форму задачи), не должно попадать в
 * initialValues. Иначе isDirty будет срабатывать на изменения заметки,
 * а Save формы — перезатирать свежие notes старыми.
 */
const stripNotes = (task) => {
  if (!task) return task;
  const { notes, ...rest } = task;
  return rest;
};

/**
 * Список полей формы задачи, участвующих в проверке isDirty.
 * Определён на уровне модуля — стабильная ссылка, useMemo не пересоздаётся.
 *
 * Поля, сохраняемые отдельными методами (файлы, папки, логи, заметки,
 * фактическое время), в список не входят: они не открывают кнопку
 * «Сохранить» и не попадают в её isDirty-проверку. Плюс сюда не входят
 * служебные поля, которые заполняет сервис (id, createdAt, creatorId,
 * history, actualHours, parentTaskId в части случаев).
 */
const FORM_FIELDS = Object.freeze([
  'title', 'desc', 'projectId', 'assigneeId', 'priority', 'plannedHours',
  'start', 'deadline', 'status', 'isHourly', 'startTime', 'endTime',
  'isSummary', 'dependencyId', 'dependencyType',
]);

/**
 * Прогресс-бар учёта времени. Ширина заливки — через CSS-переменную,
 * выставленную императивно. В JSX ни одного style={{}}.
 */
function TaskProgress({ value, max }) {
  const ref = useRef(null);
  const pct = Math.min(100, max > 0 ? (value / max) * 100 : 0);

  useLayoutEffect(() => {
    ref.current?.style.setProperty('--tm-progress-fill', `${pct}%`);
  }, [pct]);

  return (
    <div className="tm-progress">
      <div ref={ref} className="tm-progress-fill" />
    </div>
  );
}

export const TaskModal = ({
  db, ur, taskId, initialTab = 'form', parentTaskId, initialProjectId, returnToProjectId,
  returnToTaskId,
  returnToEmployeeTasksId,
  copyFromId,
  onClose, onSave, onDelete, onHoursReq, store,
  openTask, toast, onCopy,
  onTabChange,
}) => {
  const { empName, getTaskSpent, vacOverlap } = useDataHelpers(db);
  const { confirm } = useConfirm();
  const existing = taskId ? db.tasks.find(t => t.id === taskId) : null;
  const copySource = copyFromId ? db.tasks.find(t => t.id === copyFromId) : null;
  const isCopy = !existing && !!copySource;
  const isNew = !existing;
  const readOnly = !!(existing && isArchived(existing));
  const canEditFields = !readOnly && (existing ? canEditTaskFields(ur, existing, db) : canCreateTask(ur));
  const canChangeStatus = !readOnly && existing && canChangeTaskStatus(ur, existing, null, db);
  const isAssignee = existing && existing.assigneeId === ur.id;
  const isAuthor = existing && existing.creatorId === ur.id;
  const canLog = !readOnly && (existing ? isAssignee : true) && !existing?.isSummary && !existing?.isHourly;

  const canCreateFromTask = canCreateTask(ur);

  const isProjectLocked = !!(initialProjectId || parentTaskId);

  const effectiveProjectId = useMemo(() => {
    if (initialProjectId) return initialProjectId;
    if (parentTaskId) {
      const parent = db.tasks.find(t => t.id === parentTaskId);
      if (parent) return parent.projectId;
    }
    return '';
  }, [initialProjectId, parentTaskId, db.tasks]);

  const initialValues = applyHourlyMode(
    existing
      ? {
          ...stripNotes(existing),
          isHourly:  existing.isHourly  ?? false,
          startTime: existing.startTime || '09:00',
          endTime:   existing.endTime   || '18:00',
        }
      : isCopy
        ? {
            ...stripNotes(copySource),
            id: 't_' + uid(),
            assigneeId: null,
            status: 'new',
            parentTaskId: null,
            isSummary: false,
            isHourly: copySource.isHourly ?? false,
            startTime: copySource.startTime || '09:00',
            endTime: copySource.endTime || '18:00',
            logs: [],
            history: [
              { ts: Date.now(), who: ur.id, text: `Скопирована из «${copySource.title}»` },
            ],
            delegatedFrom: null,
            archived: false,
            archivedAt: null,
            closedAt: null,
            creatorId: ur.id,
            dependencyId: null,
            files: [],
            folders: [],
          }
        : {
            id: 't_' + uid(),
            title: '',
            desc: '',
            projectId: effectiveProjectId,
            assigneeId: null,
            priority: 'mid',
            plannedHours: 8,
            start: TODAY,
            deadline: iso(addDays(new Date(), 14)),
            status: 'new',
            isHourly:  false,
            startTime: '09:00',
            endTime:   '18:00',
            logs: [],
            history: [],
            delegatedFrom: null,
            archived: false,
            archivedAt: null,
            closedAt: null,
            creatorId: ur.id,
            dependencyId: null,
            dependencyType: 'FS',
            files: [],
            folders: [],
            isSummary: false,
            parentTaskId: parentTaskId || null,
          }
  );

  const validate = useCallback((values) => {
    const errors = {};
    if (!values.title?.trim()) errors.title = 'Название обязательно';
    if (isProjectLocked) {
      if (!values.projectId) errors.projectId = 'Проект не определён';
    } else {
      if (!values.projectId || values.projectId === '') errors.projectId = 'Выберите проект';
    }
    if (!values.assigneeId || values.assigneeId === '') errors.assigneeId = 'Выберите исполнителя';
    if (!values.start) errors.start = 'Дата начала обязательна';
    const project = db.projects.find(p => p.id === values.projectId);
    const isAdminProj = project && project.ptype === 'admin';
    if (!isAdminProj) {
      const planned = parseFloat(values.plannedHours);
      if (isNaN(planned) || planned <= 0) errors.plannedHours = 'Плановые часы обязательны (число > 0)';
      if (!values.deadline) errors.deadline = 'Срок исполнения обязателен';
    }
    if (values.isHourly) {
      if (!values.startTime) errors.startTime = 'Укажите время начала';
      if (!values.endTime)   errors.endTime   = 'Укажите время окончания';
      if (values.startTime && values.endTime
          && hoursBetween(values.startTime, values.endTime) === null) {
        errors.endTime = 'Время окончания должно быть позже времени начала';
      }
    }
    if (!values.priority) errors.priority = 'Приоритет обязателен';
    if (!values.status) errors.status = 'Статус обязателен';
    return errors;
  }, [db, isProjectLocked]);

  const {
    values, handleChange, handleSubmit, errors, touched,
    setValues, setTouched, setFieldValue, isValid, isDirty,
  } = useForm(initialValues, validate, { fields: FORM_FIELDS });

  const updateValues = useCallback((patch) => {
    setValues(prev => applyHourlyMode({ ...prev, ...patch }));
    setTouched(prev => {
      const next = { ...prev };
      Object.keys(patch).forEach(key => { next[key] = true; });
      return next;
    });
  }, [setValues, setTouched]);

  const [appliedTemplateName, setAppliedTemplateName] = useState(null);

  const [pendingTemplateSubtasks, setPendingTemplateSubtasks] = useState(() =>
    isCopy ? collectTaskPayloads(db.tasks, copySource.id) : []
  );

  const [activeTab, handleTabChange] = useControlledTab(initialTab, onTabChange);

  const [editingNote, setEditingNote] = useState(null);

  const bodyRef = useStableModalHeight(activeTab);

  useEffect(() => {
    if (isNew && parentTaskId && !values.projectId) {
      const parent = db.tasks.find(t => t.id === parentTaskId);
      if (parent && parent.projectId) {
        setFieldValue('projectId', parent.projectId);
      }
    }
  }, [parentTaskId, db.tasks, isNew, values.projectId, setFieldValue]);

  const project = db.projects.find(p => p.id === values.projectId);
  const isAdminProject = project && project.ptype === 'admin';
  const subtasks = useMemo(() => db.tasks.filter(t => t.parentTaskId === values.id), [db.tasks, values.id]);

  const rawNotes = existing?.notes?.[ur.id];
  const notesList = Array.isArray(rawNotes) ? rawNotes : [];

  const openNewNote = () => setEditingNote({ title: '', text: '' });
  const openExistingNote = (note) => setEditingNote({ ...note });
  const closeNoteEditor = () => setEditingNote(null);

  const handleSaveNote = useCallback((noteData) => {
    try {
      store.upsertTaskNote(existing.id, noteData);
      setEditingNote(null);
      toast('Заметка сохранена', 'success');
    } catch (err) {
      toast(err.message || 'Не удалось сохранить заметку', 'error');
    }
  }, [existing, store, toast]);

  const handleDeleteNote = useCallback((noteId) => {
    try {
      store.deleteTaskNote(existing.id, noteId);
      setEditingNote(null);
      toast('Заметка удалена', 'info');
    } catch (err) {
      toast(err.message || 'Не удалось удалить заметку', 'error');
    }
  }, [existing, store, toast]);

  const draftSubtasks = useMemo(() => {
    if (!isNew || pendingTemplateSubtasks.length === 0) return [];
    return pendingTemplateSubtasks.map((node, idx) => ({
      id: `draft_${idx}`,
      _draft: true,
      title: node.title || 'Без названия',
      assigneeId: null,
      status: 'new',
      plannedHours: node.plannedHours ?? null,
      priority: node.priority || 'mid',
      deadline: null,
      logs: [],
      projectId: values.projectId,
    }));
  }, [isNew, pendingTemplateSubtasks, values.projectId]);

  const displayedSubtasks = useMemo(
    () => [...draftSubtasks, ...subtasks],
    [draftSubtasks, subtasks]
  );

  const isSummaryChecked = values.isSummary || subtasks.length > 0 || draftSubtasks.length > 0;
  const isSummaryDisabled = !canEditFields || subtasks.length > 0;

  const saveHandler = useCallback(async (vals) => {
    const proj = db.projects.find(p => p.id === vals.projectId);
    const isAdminProj = proj && proj.ptype === 'admin';
    if (!vals.title.trim()) { toast('Укажите название', 'error'); return; }
    if (!vals.projectId) { toast('Выберите проект', 'error'); return; }
    if (!vals.assigneeId) { toast('Выберите исполнителя', 'error'); return; }
    if (!vals.start) { toast('Укажите дату начала', 'error'); return; }
    if (!vals.priority) { toast('Выберите приоритет', 'error'); return; }
    if (!vals.status) { toast('Выберите статус', 'error'); return; }
    if (!isAdminProj) {
      const planned = parseFloat(vals.plannedHours);
      if (isNaN(planned) || planned <= 0) { toast('Плановые часы обязательны (число > 0)', 'error'); return; }
      if (!vals.deadline) { toast('Срок исполнения обязателен', 'error'); return; }
    }
    if (vals.isHourly) {
      if (!vals.startTime || !vals.endTime) {
        toast('Укажите время начала и окончания', 'error');
        return;
      }
      if (hoursBetween(vals.startTime, vals.endTime) === null) {
        toast('Время окончания должно быть позже времени начала', 'error');
        return;
      }
    }
    if (proj && proj.budget != null && !proj.archived && !isAdminProj) {
      const currentPlanSum = db.tasks.filter(t => t.projectId === proj.id && t.id !== vals.id).reduce((s, t) => s + (t.plannedHours || 0), 0);
      if (currentPlanSum + (parseFloat(vals.plannedHours) || 0) > proj.budget) {
        toast(`Превышение бюджета проекта! Бюджет: ${proj.budget} ч, текущая сумма: ${currentPlanSum} ч`, 'error');
        return;
      }
    }
    const vacWarn = vals.assigneeId && vals.deadline ? vacOverlap(vals.assigneeId, vals.start || vals.deadline, vals.deadline) : null;
    if (vacWarn) {
      const ok = await confirm(DIALOGS.vacationOverlap(fmtDMY(vacWarn.start), fmtDMY(vacWarn.end)));
      if (!ok) return;
    }

    if (subtasks.length > 0 || draftSubtasks.length > 0) {
      vals.isSummary = true;
    }

    const taskToSave = applyHourlyMode({
      ...vals,
      notes: existing?.notes,
      plannedHours: vals.plannedHours === '' ? null : parseFloat(vals.plannedHours),
      closedAt: vals.status === 'closed' && (!existing || existing.status !== 'closed') ? TODAY : existing?.closedAt || null,
      history: [
        ...(vals.history || []),
        ...(existing && existing.status !== vals.status ? [{ ts: Date.now(), who: ur.id, text: `Статус: ${TASK_STATUSES[existing.status].label} → ${TASK_STATUSES[vals.status].label}` }] : [])
      ],
      creatorId: existing?.creatorId || ur.id,
    });

    if (taskToSave.assigneeId && taskToSave.deadline && taskToSave.plannedHours > 0) {
      const overload = store.checkAssigneeOverload(
        taskToSave,
        taskToSave.start,
        taskToSave.deadline,
      );
      if (overload) {
        const ok = await confirm(DIALOGS.workloadOverload(
          empName(taskToSave.assigneeId),
          overload.planTotal,
          overload.capacity,
          overload.overload,
        ));
        if (!ok) return;
      }
    }

    onSave(taskToSave, isNew, { templateSubtasks: pendingTemplateSubtasks });
  }, [existing, isNew, db, vacOverlap, toast, onSave, ur, subtasks, draftSubtasks, pendingTemplateSubtasks, confirm, store, empName]);

  const deleteHandler = useCallback(async () => {
    const ok = await confirm(DIALOGS.deleteTask(existing.title));
    if (!ok) return;
    onDelete(existing.id);
  }, [existing, onDelete, confirm]);

  const hasSubtasks = subtasks.length > 0 || values.isSummary || draftSubtasks.length > 0;

  const tabs = [
    { id: 'form', label: 'Данные' },
    ...(!values.isHourly ? [{ id: 'time', label: `Учёт времени (${getTaskSpent(values)}/${values.plannedHours ?? '—'})` }] : []),
    ...(hasSubtasks ? [{ id: 'subtasks', label: `Подзадачи (${displayedSubtasks.length})` }] : []),
    ...(existing ? [
      { id: 'chat', label: `Обсуждение (${store.getComments({ taskId: values.id }).length})` },
      { id: 'files', label: `Вложения (${values.files?.length || 0})` },
      { id: 'hist', label: 'История' }
    ] : []),
    ...(isAssignee && !readOnly ? [{ id: 'notes', label: `Заметки (${notesList.length})` }] : []),
  ];

  useEffect(() => {
    if (activeTab === 'time' && values.isHourly) handleTabChange('form');
  }, [activeTab, values.isHourly, handleTabChange]);

  const tabIdsSignature = tabs.map((t) => t.id).join(',');
  useEffect(() => {
    const ids = tabIdsSignature.split(',');
    if (!ids.includes(activeTab)) handleTabChange(ids[0] || 'form');
  }, [tabIdsSignature, activeTab, handleTabChange]);

  const applyTemplate = useCallback((template) => {
    if (!template) {
      setAppliedTemplateName(null);
      setPendingTemplateSubtasks([]);
      return;
    }

    const patch = applyTemplatePayload('task', template.payload);
    const {
      subtasks: nestedSubtasks,
      projectId: templateProjectId,
      ...taskFields
    } = patch;

    Object.keys(taskFields).forEach(field => setFieldValue(field, taskFields[field]));

    const cleanSubtasks = Array.isArray(nestedSubtasks) ? nestedSubtasks : [];
    setPendingTemplateSubtasks(cleanSubtasks);
    setAppliedTemplateName(template.name);

    if (cleanSubtasks.length > 0) {
      setFieldValue('isSummary', true);
    }

    if (!templateProjectId) return;

    if (isProjectLocked) {
      if (templateProjectId !== effectiveProjectId) {
        toast('Проект из шаблона не применён: задача создаётся в фиксированном проекте', 'info');
      }
      return;
    }

    const projectEntry = db.projects.find(p => p.id === templateProjectId);
    const accessible = projectEntry && projectEntry.status === 'active' && !projectEntry.archived;
    if (!accessible) {
      toast('Проект из шаблона недоступен — выберите проект вручную', 'warning');
      return;
    }

    setFieldValue('projectId', templateProjectId);
  }, [setFieldValue, isProjectLocked, effectiveProjectId, db.projects, toast]);

  const projectOptions = useMemo(() => {
    const scope = computeScope(ur, db);
    let list = scope.all ? db.projects : db.projects.filter(p => scope.projIds.has(p.id));
    const filtered = list.filter(p => p.status === 'active' && !p.archived);
    const options = [
      { value: '', label: '— Выберите проект —' },
      ...filtered.map(p => ({ value: p.id, label: `${p.code} — ${p.name}${p.ptype === 'admin' ? ' (административный)' : ''}` }))
    ];
    if (isProjectLocked && effectiveProjectId) {
      const exists = options.some(opt => opt.value === effectiveProjectId);
      if (!exists) {
        const proj = db.projects.find(p => p.id === effectiveProjectId);
        if (proj) {
          options.push({ value: proj.id, label: `${proj.code} — ${proj.name}${proj.ptype === 'admin' ? ' (административный)' : ''}` });
        }
      }
    }
    return options;
  }, [db, ur, isProjectLocked, effectiveProjectId]);

  const assigneeOptionsList = useMemo(() => {
    const scope = computeScope(ur, db);
    let list = scope.all ? db.employees : db.employees.filter(e => scope.empIds.has(e.id) || e.id === ur.id);
    const filtered = list.filter(e => !e.fired);
    return [
      { value: '', label: '— Выберите исполнителя —' },
      ...filtered.map(e => ({ value: e.id, label: `${e.last} ${e.first}` }))
    ];
  }, [db, ur]);

  const priorityOptions = Object.entries(PRIORITIES).map(([k, v]) => ({ value: k, label: v.label }));
  const statusOptions = TASK_STATUS_ORDER.filter(s => {
    if (isAssignee && !canChangeStatus) return ['new', 'inwork', 'review'].includes(s);
    return true;
  }).map(s => ({ value: s, label: TASK_STATUSES[s].label }));

  const dependencyOptions = useMemo(() => {
    const tasks = db.tasks
      .filter(t => t.id !== values.id && t.projectId === values.projectId && t.status !== 'closed' && t.status !== 'cancelled')
      .map(t => ({ value: t.id, label: t.title }));
    return [{ value: '', label: '—' }, ...tasks];
  }, [db.tasks, values.id, values.projectId]);

  const dependencyTypeOptions = Object.entries(DEPENDENCY_TYPES).map(([k, v]) => ({ value: k, label: `${v.label} — ${v.desc}` }));

  const candidates = useMemo(() => {
    const ids = new Set(
      db.tasks
        .filter(t => t.projectId === values.projectId)
        .map(t => t.assigneeId)
        .filter(Boolean)
    );
    const pj = db.projects.find(p => p.id === values.projectId);
    if (pj && pj.managerId) ids.add(pj.managerId);
    return [...ids].map(id => db.employees.find(e => e.id === id)).filter(Boolean);
  }, [db, values.projectId]);

  /**
   * Побочные действия (файлы, папки, часы) сохраняются через patchTask —
   * точечно, без всей формы. Локальное состояние формы обновляется
   * через setFieldValue, чтобы UI сразу увидел изменение.
   */
  const handleFileUpload = useCallback(async (files, folderId = null) => {
    const result = await prepareAttachments(files, values.files, folderId, ur.id);

    if (result.accepted > 0) {
      setFieldValue('files', result.nextFiles);
      if (existing) store.patchTask(existing.id, { files: result.nextFiles });
      toast(
        result.accepted === 1 ? TOASTS.fileUploaded : TOASTS.filesUploaded(result.accepted),
        'success'
      );
    }
    if (result.rejected > 0) {
      toast(TOASTS.filesRejected(result.errors.join('; ')), 'warning');
    }
  }, [values.files, existing, store, setFieldValue, toast, ur.id]);

  const handleFileDelete = useCallback(async (fileId) => {
    const ok = await confirm(DIALOGS.deleteFile);
    if (!ok) return;
    const updatedFiles = (values.files || []).filter(f => f.id !== fileId);
    setFieldValue('files', updatedFiles);
    if (existing) store.patchTask(existing.id, { files: updatedFiles });
    toast(TOASTS.fileDeleted, 'info');
  }, [values.files, existing, store, setFieldValue, toast, confirm]);

  const handleCreateFolder = useCallback((name, parentId) => {
    const newFolder = createFolder(name, parentId, ur.id);
    const updatedFolders = [...(values.folders || []), newFolder];
    setFieldValue('folders', updatedFolders);
    if (existing) store.patchTask(existing.id, { folders: updatedFolders });
  }, [values.folders, existing, store, setFieldValue, ur.id]);

  const handleDeleteFolder = useCallback((folderId) => {
    const updatedFolders = (values.folders || []).filter(f => f.id !== folderId);
    setFieldValue('folders', updatedFolders);
    if (existing) store.patchTask(existing.id, { folders: updatedFolders });
  }, [values.folders, existing, store, setFieldValue]);

  const [logHours, setLogHours] = useState('');
  const [logNote, setLogNote] = useState('');
  const [logDate, setLogDate] = useState(TODAY);

  const addLog = useCallback(() => {
    const h = parseFloat(logHours);
    if (!h || h <= 0) { toast('Введите корректное количество часов', 'error'); return; }
    const sp = getTaskSpent(values);
    if (values.plannedHours && sp + h > values.plannedHours) {
      toast(`Нельзя внести больше плановых: доступно ещё ${Math.max(0, values.plannedHours - sp)} часов`, 'error');
      return;
    }
    const newLog = { id: uid(), userId: ur.id, date: logDate, hours: h, note: logNote.trim() };
    const newLogs = [...values.logs, newLog];
    // Сохраняем только logs: не тащим за собой несохранённые правки формы.
    if (existing) store.patchTask(existing.id, { logs: newLogs });
    setFieldValue('logs', newLogs);
    setLogHours('');
    setLogNote('');
    toast('Часы учтены', 'success');
  }, [logHours, logNote, logDate, values, existing, store, ur, toast, setFieldValue, getTaskSpent]);

  const showBackButton = returnToProjectId || returnToTaskId || returnToEmployeeTasksId;

  const saveDisabled = !(canEditFields || (existing && canChangeStatus)) || (isNew ? !isValid : !isValid || !isDirty);

  const modalTitle = readOnly
    ? 'Архивная задача — только чтение'
    : existing
      ? 'Карточка задачи'
      : isCopy
        ? `Копирование задачи: ${copySource.title}`
        : 'Новая задача';

  const footer = (
    <div className="modal-foot">
      {!readOnly && existing && (canEditFields || isAuthor) && (
        <button className="btn danger" onClick={deleteHandler}>
          <Ic d={ICONS.trash} size={14} /> Удалить
        </button>
      )}

      {existing && onCopy && canCreateFromTask && (
        <button
          type="button"
          className="btn ghost sm"
          onClick={() => onCopy(existing.id)}
          title="Создать новую задачу на основе этой"
        >
          <Ic d={ICONS.copy} size={13} /> Копировать
        </button>
      )}

      {canCreateFromTask && (
        <TemplateActions
          kind="task"
          source={values}
          nested={existing ? collectTaskPayloads(db.tasks, existing.id) : []}
          toast={toast}
          disabled={!values.title?.trim()}
        />
      )}

      <div className="spacer" />
      <button className="btn ghost" onClick={onClose}>Отмена</button>
      <button className="btn primary" onClick={handleSubmit(saveHandler)} disabled={saveDisabled}>
        {existing ? 'Сохранить' : 'Создать задачу'}
      </button>
    </div>
  );

  return (
    <>
      <ModalShell
        title={modalTitle}
        onClose={onClose}
        width={800}
        className="modal-task"
        showSave={false}
        footer={footer}
        bodyRef={bodyRef}
        showBack={!!showBackButton}
      >
        {readOnly && (
          <div className="info-box">
            {existing.archivedAt
              ? `Задача в архиве с ${fmtDMY(existing.archivedAt)}. Редактирование запрещено.`
              : `Задача ${existing.status === 'cancelled' ? 'отменена' : 'закрыта'}. Редактирование запрещено.`}
          </div>
        )}

        <Tabs tabs={tabs} active={activeTab} onChange={handleTabChange} className="tabs-nowrap" />

        {activeTab === 'form' && (
          <div className="project-info-fields">
            {isNew && !isCopy && (
              <TemplateSelect kind="task" onApply={applyTemplate} />
            )}

            {isNew && appliedTemplateName && (
              <div className="info-box">
                Применён шаблон: <b>{appliedTemplateName}</b>
              </div>
            )}

            <FormField
              label="Название"
              required
              value={values.title}
              onChange={(v) => handleChange('title', v)}
              error={touched.title && errors.title}
              disabled={!canEditFields}
              inline
            />

            <div className="field-row">
              <label className="field-label"></label>
              <div className="flex-1 flex gap-4">
                <label className="checkbox-inline">
                  <input
                    type="checkbox"
                    checked={isSummaryChecked}
                    onChange={(e) => handleChange('isSummary', e.target.checked)}
                    disabled={isSummaryDisabled}
                  />
                  Суммарная задача
                </label>
                <label className="checkbox-inline">
                  <input
                    type="checkbox"
                    checked={values.isHourly}
                    onChange={(e) => updateValues({ isHourly: e.target.checked })}
                    disabled={!canEditFields}
                  />
                  Часовая задача
                </label>
              </div>
            </div>

            <FormField
              label="Описание"
              type="textarea"
              rows={2}
              value={values.desc}
              onChange={(v) => handleChange('desc', v)}
              disabled={!canEditFields}
              inline
            />

            <FormField
              label="Проект"
              required
              type="select"
              options={projectOptions}
              value={values.projectId ?? ''}
              onChange={(v) => handleChange('projectId', v)}
              error={touched.projectId && errors.projectId}
              disabled={!canEditFields || isProjectLocked}
              inline
            />

            <div className="fields-row">
              <FormField
                label="Исполнитель"
                required
                type="select"
                options={assigneeOptionsList}
                value={values.assigneeId ?? ''}
                onChange={(v) => handleChange('assigneeId', v)}
                error={touched.assigneeId && errors.assigneeId}
                disabled={!canEditFields}
                inline
              />

              <div className="field-with-action">
                <FormField
                  label="Плановые часы"
                  required={!isAdminProject}
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={values.plannedHours ?? ''}
                  onChange={(v) => handleChange('plannedHours', v)}
                  error={touched.plannedHours && errors.plannedHours}
                  disabled={!canEditFields || values.isHourly}
                  inline
                />
                {!readOnly && onHoursReq && existing && isAssignee && !values.isHourly && (
                  <button
                    type="button"
                    className="btn request-hours field-action"
                    onClick={() => onHoursReq('task', values.id)}
                  >
                    <Ic d={ICONS.clock} size={14} /> Запросить изменение часов
                  </button>
                )}
              </div>
            </div>

            <div className="fields-row">
              <FormField
                label="Приоритет"
                required
                type="select"
                options={priorityOptions}
                value={values.priority ?? ''}
                onChange={(v) => handleChange('priority', v)}
                error={touched.priority && errors.priority}
                disabled={!canEditFields}
                inline
              />
              <FormField
                label="Статус"
                required
                type="select"
                options={statusOptions}
                value={values.status ?? ''}
                onChange={(v) => handleChange('status', v)}
                error={touched.status && errors.status}
                disabled={!canChangeStatus && !isAuthor && !isAssignee}
                inline
              />
            </div>

            <div className="fields-row">
              <FormField
                label="Начало"
                required
                type="date"
                value={values.start}
                onChange={(v) => updateValues({ start: v })}
                error={touched.start && errors.start}
                disabled={!canEditFields}
                inline
              />
              <FormField
                label="Срок исполнения"
                required={!isAdminProject}
                type="date"
                value={values.deadline}
                onChange={(v) => handleChange('deadline', v)}
                error={touched.deadline && errors.deadline}
                disabled={!canEditFields || isAdminProject || values.isHourly}
                inline
              />
            </div>

            {values.isHourly && (
              <div className="fields-row">
                <FormField
                  label="Время начала"
                  required
                  type="time"
                  value={values.startTime}
                  onChange={(v) => updateValues({ startTime: v })}
                  error={touched.startTime && errors.startTime}
                  disabled={!canEditFields}
                  inline
                />
                <FormField
                  label="Время окончания"
                  required
                  type="time"
                  value={values.endTime}
                  onChange={(v) => updateValues({ endTime: v })}
                  error={touched.endTime && errors.endTime}
                  disabled={!canEditFields}
                  inline
                />
              </div>
            )}

            <FormField
              label="Зависит от задачи"
              type="select"
              options={dependencyOptions}
              value={values.dependencyId ?? ''}
              onChange={(v) => handleChange('dependencyId', v)}
              disabled={!canEditFields}
              inline
            />
            <FormField
              label="Тип зависимости"
              type="select"
              options={dependencyTypeOptions}
              value={values.dependencyType ?? ''}
              onChange={(v) => handleChange('dependencyType', v)}
              disabled={!canEditFields || !values.dependencyId}
              inline
            />
          </div>
        )}

        {activeTab === 'time' && !values.isHourly && (
          <div className="tm-block">
            <TaskProgress
              value={getTaskSpent(values)}
              max={values.plannedHours || 0}
            />
            {values.logs.map(l => (
              <div key={l.id} className="tm-log">
                <span className="tm-log-name">{empName(l.userId)}</span>
                <span className="mut">{fmtD(l.date)}</span>
                <span className="tm-log-note">{l.note}</span>
                <b className="tm-log-h">{l.hours} ч</b>
              </div>
            ))}
            {canLog && (
              <div className="tm-add">
                <input className="inp tm-add-date" type="date" value={logDate} onChange={(e) => setLogDate(e.target.value)} max={TODAY} />
                <input className="inp tm-add-hours" type="number" min="0.5" step="0.5" placeholder="часы" value={logHours} onChange={(e) => setLogHours(e.target.value)} />
                <input className="inp tm-add-note" placeholder="комментарий" value={logNote} onChange={(e) => setLogNote(e.target.value)} />
                <button className="btn ghost" onClick={addLog}><Ic d={ICONS.clock} size={14} /> Внести часы</button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'subtasks' && hasSubtasks && (
          <div className="tm-block">
            <div className="subtask-header">
              <div className="rep-panel-title">Подзадачи</div>
              {existing && (
                <button
                  className="btn primary sm"
                  onClick={() => {
                    onClose();
                    setTimeout(() => openTask(null, 'form', values.id, null, null, null, values.id), 50);
                  }}
                  disabled={readOnly}
                >
                  <Ic d={ICONS.plus} size={14} /> Создать подзадачу
                </button>
              )}
            </div>
            <TaskTable
              tasks={displayedSubtasks}
              onRowClick={(id) => {
                onClose();
                setTimeout(() => openTask(id, 'form', null, null, null, null, values.id), 50);
              }}
              columns={['title', 'assignee', 'status', 'planned', 'fact', 'deadline']}
              db={db}
              getTaskSpent={getTaskSpent}
              empName={empName}
            />
          </div>
        )}

        {activeTab === 'chat' && (
          <Discussion
            store={store}
            filter={{ projectId: values.projectId, taskId: values.id }}
            currentUser={ur}
            candidates={candidates}
            readOnly={readOnly}
            toast={toast}
            employees={db.employees}
          />
        )}

        {activeTab === 'files' && existing && (
          <FileManager
            files={values.files}
            folders={values.folders}
            onUpload={handleFileUpload}
            onDelete={handleFileDelete}
            onCreateFolder={handleCreateFolder}
            onDeleteFolder={handleDeleteFolder}
            canUpload={!readOnly && (canEditFields || isAssignee || isAuthor)}
            canDelete={!readOnly && (canEditFields || isAssignee || isAuthor)}
            employeeName={empName}
          />
        )}

        {activeTab === 'hist' && existing && (
          <div className="tm-logs tm-logs-hist">
            {[...values.history].reverse().map((h, i) => (
              <div key={i} className="tm-log">
                <span className="tm-log-name">{h.who === 'system' ? 'Система' : empName(h.who)}</span>
                <span className="mut sm">{fmtDT(h.ts)}</span>
                <span className="tm-log-note">{h.text}</span>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'notes' && isAssignee && !readOnly && existing && (
          <div className="tm-block">
            <div className="subtask-header">
              <div className="rep-panel-title">Личные заметки</div>
              <button
                type="button"
                className="btn primary sm"
                onClick={openNewNote}
              >
                <Ic d={ICONS.plus} size={13} /> Новая заметка
              </button>
            </div>
            <p className="mut sm mb-2">
              Видны только вам. Сохраняются отдельно от формы задачи.
            </p>
            {notesList.length === 0 ? (
              <div className="mut sm">Заметок пока нет</div>
            ) : (
              <div className="note-grid">
                {notesList.map(n => (
                  <button
                    key={n.id}
                    type="button"
                    className="note-tile"
                    onClick={() => openExistingNote(n)}
                  >
                    <div className="note-tile-title">{n.title || 'Без названия'}</div>
                    <div className="note-tile-preview">{n.text || 'Пустая заметка'}</div>
                    <div className="note-tile-date">{fmtDT(n.updatedAt)}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </ModalShell>

      {editingNote && (
        <NoteEditorModal
          note={editingNote}
          onSave={handleSaveNote}
          onDelete={handleDeleteNote}
          onClose={closeNoteEditor}
        />
      )}
    </>
  );
};