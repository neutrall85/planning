// src/components/Staff.jsx
import React, { useState, useMemo, useCallback } from "react";
import { ROLES, VACATION_TYPES, DIALOGS, TOASTS } from "../utils/constants";
import { TODAY, fmtDMY, uid } from "../utils/date";
import {
  canEditDepartments,
  canEditRoles,
  canManageAllVacations,
  canFireEmployee,
} from "../utils/permissions";
import { Ic, ICONS } from "./Icons";
import { useDataHelpers, useFilters } from "../hooks";
import { useToast } from "../context/ToastContext";
import { useConfirm } from "../context/ConfirmContext";
import { EditEmployeeModal } from "./Modals/EditEmployeeModal";
import { CreateEmployeeModal } from "./Modals/CreateEmployeeModal";
import Avatar from "./Avatar";
import FloatingMenu from "./FloatingMenu";
import { SearchBox } from "./SearchBox";
import { getPrimaryDeptName } from "../utils/helpers";

const INITIAL_FILTERS = Object.freeze({
  query: '',
});

/**
 * Совпадает ли сотрудник поисковой строке.
 *
 * Ищем по трём полям: ФИО (одной строкой), должность, названия отделов
 * (в т.ч. дополнительных). Именно эти данные видит пользователь в строке
 * сотрудника — совпадение в них ожидаемо, а не в служебных полях вроде
 * id или телефона.
 */
const matchesQuery = (emp, q, db) => {
  if (!q) return true;
  const needle = q.toLowerCase();
  if (`${emp.last} ${emp.first}`.toLowerCase().includes(needle)) return true;
  if ((emp.position || '').toLowerCase().includes(needle)) return true;
  const deptNames = (emp.departments || [])
    .map(d => db.departments.find(x => x.id === d.deptId)?.name || '')
    .join(' ')
    .toLowerCase();
  return deptNames.includes(needle);
};

const EmployeeRow = React.memo(({
  employee,
  isFired,
  db,
  ur,
  openDepts,
  openRoles,
  setDb,
  canFire,
  getEmployeeLoad,
  openEditEmployee,
}) => {
  const l = getEmployeeLoad(employee.id);
  const norm = 160;
  const pct = Math.min(100, Math.round((l.plan / norm) * 100));
  const vacNow = db.vacations.find(v => v.empId === employee.id && v.status === 'approved' && v.start <= TODAY && TODAY <= v.end);

  const handleFireToggle = useCallback(() => {
    const updated = { ...employee, fired: !employee.fired };
    setDb((s) => ({
      ...s,
      employees: s.employees.map(emp => emp.id === employee.id ? updated : emp),
      audit: [{ id: uid(), ts: Date.now(), userId: ur.id, action: employee.fired ? 'Восстановление сотрудника' : 'Увольнение сотрудника', details: `${employee.last} ${employee.first}` }, ...s.audit]
    }));
  }, [employee, setDb, ur]);

  const displayPosition = employee.position || 'Сотрудник';

  // Меню собирается из тех же прав, что и раньше управляли видимостью
  // отдельных кнопок. Divider вставляется только между группами «действия
  // над сотрудником» и «увольнение/восстановление» — и только если обе
  // группы непустые.
  const buildEmployeeMenu = () => {
    const items = [];

    if (canEditDepartments(ur)) {
      items.push({
        id: 'edit',
        label: 'Редактировать',
        icon: ICONS.edit,
        onClick: () => openEditEmployee(employee.id),
      });
      if (!isFired) {
        items.push({
          id: 'depts',
          label: 'Подразделения',
          icon: ICONS.users,
          onClick: () => openDepts(employee.id),
        });
      }
    }

    if (canEditRoles(ur) && !isFired) {
      items.push({
        id: 'roles',
        label: 'Роли',
        icon: ICONS.shield,
        onClick: () => openRoles(employee.id),
      });
    }

    if (canFire) {
      if (items.length) items.push({ type: 'divider' });
      items.push({
        id: 'fire',
        label: isFired ? 'Восстановить' : 'Уволить',
        icon: isFired ? ICONS.restore : ICONS.x,
        danger: !isFired,
        onClick: handleFireToggle,
      });
    }

    return items;
  };

  const menuItems = buildEmployeeMenu();

  return (
    <div className="st-row">
      <Avatar employee={employee} size="sm" />
      <div className="st-name">
        <div className="st-fio">
          {employee.last} {employee.first}
          {isFired && <span className="vac-badge fired">Уволен</span>}
          {vacNow && <span className="vac-badge">в отпуске до {fmtDMY(vacNow.end)}</span>}
        </div>
        <div className="st-pos">
          {displayPosition}
        </div>
      </div>
      <div className="st-roles">
        {employee.roles.map(r => (
          <span key={r} className="role-chip" style={{ background: ROLES[r].color + '1e', color: ROLES[r].color }}>{ROLES[r].short}</span>
        ))}
      </div>
      {!isFired && (
        <div className="st-load">
          <div className="st-load-bar"><div className={`st-load-fill${l.plan > norm ? ' over' : ''}`} style={{ width: pct + '%' }} /></div>
          <span className={`st-load-txt${l.plan > norm ? ' over' : ''}`}>{l.plan} ч · {Math.round((l.plan / norm) * 100)}%</span>
        </div>
      )}
      <div className="st-nums"><b>{isFired ? '-' : l.cnt}</b><span>задач</span></div>

      {menuItems.length > 0 && (
        <FloatingMenu items={menuItems}>
          {({ buttonProps }) => (
            <button
              {...buttonProps}
              className="icon-btn"
              title="Действия"
              aria-label={`Действия с ${employee.last} ${employee.first}`}
            >
              <Ic d={ICONS.more} size={16} />
            </button>
          )}
        </FloatingMenu>
      )}
    </div>
  );
});

export default function Staff({ store, db, setDb, ur, openRoles, openDepts, openVacation }) {
  const { getEmployeeLoad, empName } = useDataHelpers(db);
  const { showToast } = useToast();
  const { prompt } = useConfirm();
  const [showFired, setShowFired] = useState(false);
  const [editEmployeeId, setEditEmployeeId] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { filters, setFilter } = useFilters(INITIAL_FILTERS);
  const { query } = filters;

  // Фильтр применяется к «сырым» спискам — все производные структуры
  // (дерево отделов, КБ-секции, руководство, уволенные, отпуска) строятся
  // от отфильтрованного массива. В дереве автоматически пропадают
  // пустые отделы и КБ: у них уже есть guard «если членов нет — не
  // показывать».
  const filteredActiveEmployees = useMemo(
    () => db.employees.filter(e => !e.fired && matchesQuery(e, query, db)),
    [db, query]
  );

  const filteredFiredEmployees = useMemo(
    () => db.employees.filter(e => e.fired && matchesQuery(e, query, db)),
    [db, query]
  );

  const noDeptEmployees = useMemo(() => {
    return filteredActiveEmployees
      .filter(e => e.departments.length === 0 && !e.roles.includes('kb_chief'))
      .sort((a, b) => {
        if (a.roles.includes('director') && !b.roles.includes('director')) return -1;
        if (!a.roles.includes('director') && b.roles.includes('director')) return 1;
        return a.last.localeCompare(b.last);
      });
  }, [filteredActiveEmployees]);

  const deptMap = useMemo(() => {
    const map = new Map();
    db.departments.forEach(d => {
      const members = filteredActiveEmployees.filter(e => e.departments.some(x => x.deptId === d.id));
      if (members.length) map.set(d.id, members);
    });
    return map;
  }, [db.departments, filteredActiveEmployees]);

  const kbSections = useMemo(() => {
    return db.kbs.map(k => {
      const deptsInKb = db.departments.filter(d => d.kbId === k.id);
      const members = filteredActiveEmployees.filter(e => e.departments.some(d => deptsInKb.some(x => x.id === d.deptId)));
      const chiefs = filteredActiveEmployees.filter(e => e.roles.includes('kb_chief') && (e.kbIds || []).includes(k.id));
      if (members.length === 0 && deptsInKb.length === 0 && chiefs.length === 0) return null;
      return { kb: k, deptsInKb, members, chiefs };
    }).filter(Boolean);
  }, [db.kbs, db.departments, filteredActiveEmployees]);

  const deptsWithoutKb = useMemo(() => db.departments.filter(d => d.kbId === null), [db.departments]);

  const allVacs = useMemo(() => {
    const list = db.vacations
      .filter(v => {
        if (!query) return true;
        const emp = db.employees.find(e => e.id === v.empId);
        return emp && matchesQuery(emp, query, db);
      })
      .sort((a, b) => (a.start < b.start ? 1 : -1));
    return list;
  }, [db.vacations, db.employees, db, query]);

  const canFire = canFireEmployee(ur);

  const openEditEmployee = useCallback((id) => setEditEmployeeId(id), []);
  const closeEditEmployee = useCallback(() => setEditEmployeeId(null), []);

  const handleCreateKb = useCallback(async () => {
    const name = await prompt(DIALOGS.createKb);
    if (!name) return;
    setDb((s) => ({
      ...s,
      kbs: [...s.kbs, { id: 'kb_' + Math.random().toString(36).slice(2, 6), name, full: name }],
    }));
    showToast(TOASTS.kbCreated(name), 'success');
  }, [prompt, setDb, showToast]);

  const handleCreateDept = useCallback(async () => {
    const name = await prompt(DIALOGS.createDept);
    if (!name) return;
    setDb((s) => ({
      ...s,
      departments: [...s.departments, { id: 'd_' + Math.random().toString(36).slice(2, 6), name, kbId: null }],
    }));
    showToast(TOASTS.deptCreated(name), 'success');
  }, [prompt, setDb, showToast]);

  const renderDepartment = useCallback((deptId) => {
    const members = deptMap.get(deptId) || [];
    if (!members.length) return null;
    const dept = db.departments.find(d => d.id === deptId);
    if (!dept) return null;
    const headNames = db.employees
      .filter(e => (e.headDeptIds || []).includes(deptId) && !e.fired)
      .map(e => `${e.last} ${e.first[0]}.`)
      .join(', ');
    return (
      <div className="st-dept" key={deptId}>
        <div className="st-dept-head">
          <span className="st-dept-name">{dept.name}</span>
          <span className="mut">руководитель: {headNames || '-'}</span>
          <span className="kcount">{members.length}</span>
        </div>
        {members.map(e => (
          <EmployeeRow
            key={e.id}
            employee={e}
            isFired={false}
            db={db}
            ur={ur}
            openDepts={openDepts}
            openRoles={openRoles}
            setDb={setDb}
            canFire={canFire}
            getEmployeeLoad={getEmployeeLoad}
            openEditEmployee={openEditEmployee}
          />
        ))}
      </div>
    );
  }, [deptMap, db, ur, openDepts, openRoles, setDb, canFire, getEmployeeLoad, openEditEmployee]);

  return (
    <div className="staff">
      <div className="sec-head">
        <div className="sec-note">Привязку сотрудников к отделам меняют только HR-менеджер, суперадминистратор и генеральный директор. Загрузка — по плановым часам открытых задач, норма 160 ч/мес.</div>
        <div className="sec-actions">
          <SearchBox
            value={query}
            onChange={(v) => setFilter('query', v)}
            placeholder="Поиск по ФИО, должности, отделу…"
            className="staff-search"
          />
          {canEditRoles(ur) && (
            <>
              <button className="btn ghost sm" onClick={handleCreateKb}>
                <Ic d={ICONS.plus} size={13} /> КБ
              </button>
              <button className="btn ghost sm" onClick={handleCreateDept}>
                <Ic d={ICONS.plus} size={13} /> Отдел
              </button>
              {canEditDepartments(ur) && (
                <button className="btn primary sm" onClick={() => setShowCreateModal(true)}>
                  <Ic d={ICONS.plus} size={13} /> Добавить сотрудника
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {showCreateModal && (
        <CreateEmployeeModal
          store={store}
          db={db}
          setDb={setDb}
          ur={ur}
          onClose={() => setShowCreateModal(false)}
          toast={(msg, type) => showToast(msg, type || 'error')}
          audit={(action, details) => setDb(prev => ({ ...prev, audit: [{ id: uid(), ts: Date.now(), userId: ur.id, action, details }, ...prev.audit] }))}
        />
      )}

      {editEmployeeId && (
        <EditEmployeeModal
          store={store}
          db={db}
          setDb={setDb}
          employeeId={editEmployeeId}
          onClose={closeEditEmployee}
          toast={(msg, type) => showToast(msg, type || 'error')}
          audit={(action, details) => setDb(prev => ({ ...prev, audit: [{ id: uid(), ts: Date.now(), userId: ur.id, action, details }, ...prev.audit] }))}
          ur={ur}
        />
      )}

      {query && filteredActiveEmployees.length === 0 && filteredFiredEmployees.length === 0 && (
        <div className="empty-note p-4">Сотрудников по заданным условиям не найдено</div>
      )}

      {noDeptEmployees.length > 0 && (
        <div className="st-section">
          <div className="st-sec-head">
            <div className="st-sec-title">Руководство</div>
          </div>
          {noDeptEmployees.map(e => (
            <EmployeeRow
              key={e.id}
              employee={e}
              isFired={false}
              db={db}
              ur={ur}
              openDepts={openDepts}
              openRoles={openRoles}
              setDb={setDb}
              canFire={canFire}
              getEmployeeLoad={getEmployeeLoad}
              openEditEmployee={openEditEmployee}
            />
          ))}
        </div>
      )}

      {kbSections.map(({ kb, deptsInKb, chiefs }) => (
        <div className="st-section" key={kb.id}>
          <div className="st-sec-head">
            <div className="st-sec-title">{kb.name}</div>
          </div>
          {chiefs.length > 0 && (
            <div className="st-dept" style={{ borderTop: '1px solid var(--line)' }}>
              {chiefs.map(e => (
                <EmployeeRow
                  key={e.id}
                  employee={e}
                  isFired={false}
                  db={db}
                  ur={ur}
                  openDepts={openDepts}
                  openRoles={openRoles}
                  setDb={setDb}
                  canFire={canFire}
                  getEmployeeLoad={getEmployeeLoad}
                  openEditEmployee={openEditEmployee}
                />
              ))}
            </div>
          )}
          {deptsInKb.map(d => renderDepartment(d.id))}
        </div>
      ))}

      {deptsWithoutKb.length > 0 && (
        <div className="st-section">
          <div className="st-sec-head">
            <div className="st-sec-title">Отделы и сотрудники вне КБ</div>
            <div className="st-sec-sub">Подразделения прямого подчинения</div>
          </div>
          {deptsWithoutKb.map(d => renderDepartment(d.id))}
        </div>
      )}

      {canManageAllVacations(ur) && allVacs.length > 0 && (
        <div className="st-section">
          <div className="st-sec-head">
            <div className="st-sec-title">Все отпуска</div>
            <button className="btn primary sm" onClick={() => openVacation(null, null)}>
              <Ic d={ICONS.plus} size={13} /> Отпуск сотруднику
            </button>
          </div>
          <div className="p-3">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Сотрудник</th>
                  <th>Отдел</th>
                  <th>Период</th>
                  <th>Тип</th>
                  <th>Делегирование</th>
                  <th>Статус</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {allVacs.map(v => {
                  const e = db.employees.find(x => x.id === v.empId);
                  if (e && e.fired) return null;
                  return (
                    <tr key={v.id}>
                      <td><b>{empName(v.empId)}</b></td>
                      <td>{getPrimaryDeptName(e, db)}</td>
                      <td>{fmtDMY(v.start)} - {fmtDMY(v.end)}</td>
                      <td>{VACATION_TYPES[v.type]}</td>
                      <td>{v.delegation.enabled ? `→ ${empName(v.delegation.subId)}` : '-'}</td>
                      <td><span className={`st-chip ${v.status}`}>
                        {{ pending: 'На утверждении', approved: 'Утверждён', rejected: 'Отклонён' }[v.status]}
                      </span></td>
                      <td>
                        <button className="icon-btn" onClick={() => openVacation(v.id, null)}><Ic d={ICONS.edit} size={14} /></button>
                        <button className="icon-btn danger" onClick={() => { setDb((s) => ({ ...s, vacations: s.vacations.filter(x => x.id !== v.id) })); }}><Ic d={ICONS.trash} size={14} /></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {filteredFiredEmployees.length > 0 && canFire && (
        <div className="st-section">
          <div className="st-sec-head">
            <div className="st-sec-title">Архив сотрудников (уволенные)</div>
            <button className="btn ghost sm" onClick={() => setShowFired(!showFired)}>
              {showFired ? 'Скрыть' : 'Показать'}
            </button>
          </div>
          {showFired && (
            <div className="st-empty-box">
              {filteredFiredEmployees.map(e => (
                <EmployeeRow
                  key={e.id}
                  employee={e}
                  isFired={true}
                  db={db}
                  ur={ur}
                  openDepts={openDepts}
                  openRoles={openRoles}
                  setDb={setDb}
                  canFire={canFire}
                  getEmployeeLoad={getEmployeeLoad}
                  openEditEmployee={openEditEmployee}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}