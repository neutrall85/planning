// src/components/ProjectChat.jsx
import Discussion from './Discussion';

const ProjectChat = ({
  projectId,
  store,
  currentUser,
  toast,
  employees,
  candidates,
  openTask,
  tasks,
  readOnly = false,
}) => {
  const handleTaskClick = (taskId) => {
    openTask(taskId, 'form', null, null, projectId, 'chat');
  };

  return (
    <Discussion
      store={store}
      filter={{ projectId }}
      currentUser={currentUser}
      candidates={candidates || []}
      readOnly={readOnly}
      toast={toast}
      employees={employees}
      onTaskClick={handleTaskClick}
      showTaskLink={true}
      tasks={tasks || []}
    />
  );
};

export default ProjectChat;