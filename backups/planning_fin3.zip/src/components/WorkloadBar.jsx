// src/components/WorkloadBar.jsx
import { useLayoutEffect, useRef } from 'react';

/**
 * Полоса загрузки. Ширина заполнения задаётся CSS-переменной
 * --workload-fill, которую выставляем императивно через style.setProperty.
 * В JSX никаких inline-стилей — разметка чистая, а размерность живёт в CSS.
 *
 * max — верхняя граница шкалы (максимум по колонке); value — значение строки.
 */
export default function WorkloadBar({ value, max, variant = 'plan' }) {
  const ref = useRef(null);
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;

  useLayoutEffect(() => {
    ref.current?.style.setProperty('--workload-fill', `${pct}%`);
  }, [pct]);

  return (
    <div className="workload-bar">
      <div
        ref={ref}
        className={`workload-bar-fill workload-bar-fill--${variant}`}
      />
    </div>
  );
}