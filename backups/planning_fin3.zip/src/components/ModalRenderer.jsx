// src/components/ModalRenderer.jsx
import { useCallback } from 'react';
import {
  TaskModal,
  ProjectModal,
  HoursRequestModal,
  RolesModal,
  DeptsModal,
  VacationModal,
  DelegationModal,
  VacNowModal,
  CreateEmployeeModal,
  EditEmployeeModal,
  YearCalendarModal,
  EmployeeTasksModal,
} from './Modals';
import { TemplateModal } from './Templates';
import { fmtDMY } from '../utils/date';
import { collectTaskPayloads } from '../utils/templateNesting';
import { useDataHelpers } from '../hooks';

export default function ModalRenderer({
  modal,
  onClose,
  db,
  ur,
  store,
  openTask,
  openProject,
  openHoursReq,
  openRoles,
  openDepts,
  openVacation,
  openDelegation,
  openEmployeeTasks,
  openCopyTask,
  openCopyProject,
  onTabChange,
  toast,
}) {
  const { empName } = useDataHelpers(db);

  // Все действия, которые передаются в модалки как пропсы, вынесены
  // из JSX в useCallback: код разметки остаётся плоским, зависимости —
  // явными, а идентичность функций сохраняется между рендерами.
  // Порядок объявления повторяет порядок использования в switch ниже.

  const handleError = useCallback((error) => {
    console.error(error);
    if (toast) toast(error.message || 'Произошла ошибка', 'error');
  }, [toast]);

  const reportTemplateResult = useCallback((label, res) => {
    if (!res) return;
    if (res.failed > 0) {
      toast?.(`${label}: создано ${res.created}, с ошибками ${res.failed}`, 'warning');
    } else if (res.created > 0) {
      toast?.(`${label}: создано ${res.created}`, 'success');
    }
  }, [toast]);

  /**
   * Возврат из карточки задачи. Порядок проверок — от самого «глубокого»
   * контекста к самому общему:
   *   - returnToEmployeeTasksId — задача открыта из списка задач сотрудника;
   *   - returnToTaskId — задача открыта из родительской (подзадачи);
   *   - returnToProjectId — задача открыта из карточки проекта.
   *
   * onClose и open* вызываются синхронно, без setTimeout. React 18 батчит
   * оба setModal в один коммит, промежуточного состояния modal === null
   * не возникает — нет мигания.
   */
  const closeTaskWithReturn = useCallback(() => {
    if (modal.returnToEmployeeTasksId) {
      openEmployeeTasks(modal.returnToEmployeeTasksId);
      return;
    }
    if (modal.returnToTaskId) {
      openTask(modal.returnToTaskId, modal.returnToTaskTab || 'subtasks');
      return;
    }
    if (modal.returnToProjectId) {
      openProject(modal.returnToProjectId, modal.returnToProjectTab || 'info');
      return;
    }
    onClose();
  }, [modal, onClose, openEmployeeTasks, openTask, openProject]);

  const closeProjectWithReturn = useCallback(() => {
    if (modal.returnToProjectId) {
      openProject(modal.returnToProjectId, modal.returnToProjectTab || 'info');
      return;
    }
    onClose();
  }, [modal, onClose, openProject]);

  /**
   * Сохранение задачи. Аудит изменений собирается в TaskService
   * (по _describeChanges) и пишется оттуда для всех ролей — здесь
   * никакой второй записи «административное изменение» не нужно.
   */
  const handleTaskSave = useCallback(async (task, isNew, extras = {}) => {
    try {
      await store.upsertTask(task);

      if (extras.templateSubtasks?.length) {
        const res = store.instantiateTemplateSubtasks(task.id, extras.templateSubtasks);
        reportTemplateResult('Подзадачи из шаблона', res);
      }

      closeTaskWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, reportTemplateResult, closeTaskWithReturn, handleError]);

  /**
   * Удаление задачи. Принимает id — так же, как его передаёт TaskModal.
   * Запись в аудит делает TaskService.deleteTask; дублирующая запись
   * отсюда убрана — иначе в журнале было две строки на одно удаление.
   */
  const handleTaskDelete = useCallback(async (id) => {
    try {
      await store.deleteTask(id);
      closeTaskWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, closeTaskWithReturn, handleError]);

  /**
   * Сохранение проекта. Аудит изменений собирается в ProjectService
   * через _describeChanges — здесь дублирующей записи нет.
   */
  const handleProjectSave = useCallback(async (p, isNew, extras = {}) => {
    try {
      await store.upsertProject(p);

      if (extras.templateTasks?.length) {
        const res = store.instantiateTemplateTasks(p.id, extras.templateTasks);
        reportTemplateResult('Задачи из шаблона', res);
      }

      closeProjectWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, reportTemplateResult, closeProjectWithReturn, handleError]);

  /**
   * Удаление проекта. Принимает id — так же, как его передаёт
   * ProjectModal.deleteHandler (existing.id). Поиск проекта по id —
   * по образцу handleTaskDelete: обработчик не полагается на то, что
   * модалка передаст объект.
   *
   * Раньше сигнатура была (p) и код обращался к p.id / p.name — при
   * вызове со строкой получались undefined, и удаление молча не
   * срабатывало.
   *
   * Запись в аудит — в ProjectService.deleteProject; здесь её нет.
   * Возврат — через closeProjectWithReturn: если карточка открыта
   * поверх другой, пользователь вернётся к ней, а не закроет всё.
   */
  const handleProjectDelete = useCallback(async (id) => {
    try {
      await store.deleteProject(id);
      closeProjectWithReturn();
    } catch (error) {
      handleError(error);
    }
  }, [store, closeProjectWithReturn, handleError]);

  const handleHoursSubmit = useCallback(async (r) => {
    try {
      await store.addHoursRequest(r);
      const target = modal.kind === 'task'
        ? db.tasks.find(t => t.id === modal.targetId)
        : db.projects.find(p => p.id === modal.targetId);
      const targetTitle = target ? (modal.kind === 'task' ? target.title : target.name) : '';
      const directorIds = db.employees.filter(e => e.roles.includes('director') && !e.fired).map(e => e.id);
      store.notifyHoursRequestCreated(r, directorIds, targetTitle);
      store.addAudit(
        'Запрос изменения часов',
        { target: targetTitle, oldH: r.oldH, newH: r.newH, reason: r.reason },
        'hoursRequest',
        r.id,
      );
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [modal.kind, modal.targetId, db.tasks, db.projects, db.employees, store, onClose, handleError]);

  const handleVacationSave = useCallback(async (v, isNew) => {
    try {
      await store.upsertVacation(v);
      store.addAudit(
        isNew ? 'Создание отпуска' : 'Изменение отпуска',
        { employee: empName(v.empId), period: `${fmtDMY(v.start)}-${fmtDMY(v.end)}` },
        'vacation',
        v.id,
      );
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [store, empName, onClose, handleError]);

  const handleDelegationSubmit = useCallback(async (rd) => {
    try {
      await store.upsertRoleDelegation(rd);
      store.notifyRoleDelegationCreated(rd);
      store.addAudit(
        'Создание делегирования ролей',
        { from: empName(rd.fromId), to: empName(rd.toId), roles: rd.roles.join(', ') },
        'delegation',
        rd.id,
      );
      onClose();
    } catch (error) {
      handleError(error);
    }
  }, [store, empName, onClose, handleError]);

  if (!modal) return null;

  switch (modal.type) {
    case 'task': {
      return (
        <TaskModal
          db={db}
          ur={ur}
          taskId={modal.taskId}
          copyFromId={modal.copyFromId}
          initialTab={modal.initialTab || 'form'}
          parentTaskId={modal.parentTaskId}
          initialProjectId={modal.initialProjectId}
          returnToProjectId={modal.returnToProjectId}
          returnToTaskId={modal.returnToTaskId}
          returnToEmployeeTasksId={modal.returnToEmployeeTasksId}
          onClose={closeTaskWithReturn}
          onCopy={openCopyTask}
          onTabChange={onTabChange}
          onSave={handleTaskSave}
          onDelete={handleTaskDelete}
          onHoursReq={openHoursReq}
          store={store}
          openTask={openTask}
          toast={toast}
        />
      );
    }

    case 'project': {
      return (
        <ProjectModal
          db={db}
          ur={ur}
          projectId={modal.projectId}
          copyFromId={modal.copyFromId}
          returnToProjectId={modal.returnToProjectId}
          initialTab={modal.initialTab || 'info'}
          onClose={closeProjectWithReturn}
          onCopy={openCopyProject}
          onTabChange={onTabChange}
          onSave={handleProjectSave}
          onDelete={handleProjectDelete}
          store={store}
          openTask={openTask}
          toast={toast}
        />
      );
    }

    case 'hours':
      return (
        <HoursRequestModal
          db={db}
          ur={ur}
          kind={modal.kind}
          targetId={modal.targetId}
          onClose={onClose}
          onSubmit={handleHoursSubmit}
          toast={toast}
        />
      );

    case 'roles':
      return (
        <RolesModal
          store={store}
          empId={modal.empId}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'depts':
      return (
        <DeptsModal
          store={store}
          empId={modal.empId}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'vacation':
      return (
        <VacationModal
          db={db}
          ur={ur}
          vacationId={modal.vacationId}
          forEmpId={modal.forEmpId || null}
          onClose={onClose}
          onSave={handleVacationSave}
          toast={toast}
        />
      );

    case 'delegation':
      return (
        <DelegationModal
          db={db}
          ur={ur}
          onClose={onClose}
          onSubmit={handleDelegationSubmit}
          toast={toast}
        />
      );

    case 'vacnow':
      return <VacNowModal db={db} onClose={onClose} toast={toast} />;

    case 'yearCalendar':
      return <YearCalendarModal store={store} onClose={onClose} />;

    case 'employeeTasks':
      return (
        <EmployeeTasksModal
          db={db}
          employeeId={modal.empId}
          openTask={openTask}
          onClose={onClose}
        />
      );

    // Задача → шаблон. Использует тот же TemplateModal, что и кнопка
    // «В шаблон» в карточке задачи; разница только в источнике —
    // там передаётся values формы, здесь — сохранённый в сторе объект.
    case 'templateFromTask': {
      const task = db.tasks.find((t) => t.id === modal.taskId);
      if (!task) return null;
      return (
        <TemplateModal
          mode="create"
          kind="task"
          source={task}
          nested={collectTaskPayloads(db.tasks, task.id)}
          onClose={onClose}
          toast={toast}
        />
      );
    }

    // Симметрично для проекта: тот же TemplateModal, тот же конвейер
    // черновиков, только kind='project' и nested собирается из задач
    // проекта.
    case 'templateFromProject': {
      const project = db.projects.find((p) => p.id === modal.projectId);
      if (!project) return null;
      return (
        <TemplateModal
          mode="create"
          kind="project"
          source={project}
          nested={collectTaskPayloads(
            db.tasks.filter((t) => t.projectId === project.id && !t.archived)
          )}
          onClose={onClose}
          toast={toast}
        />
      );
    }

    case 'createEmployee':
      return (
        <CreateEmployeeModal
          store={store}
          ur={ur}
          onClose={onClose}
          toast={toast}
        />
      );

    case 'editEmployee':
      return (
        <EditEmployeeModal
          store={store}
          ur={ur}
          employeeId={modal.employeeId}
          onClose={onClose}
          toast={toast}
        />
      );

    default:
      return null;
  }
}