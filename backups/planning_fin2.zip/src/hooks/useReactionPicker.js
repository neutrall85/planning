// src/components/discussion/useReactionPicker.js
import { useCallback, useEffect, useRef, useState } from 'react';

const AUTO_DISMISS_MS = 3000;

/**
 * Состояние попапа реакций: открыт/закрыт, закрытие по клику вне
 * контейнера и авто-закрытие по таймауту бездействия.
 *
 * Всё DOM-знание (refs, listeners, таймер) инкапсулировано здесь —
 * карточка комментария не занимается ни таймерами, ни click-outside.
 * Контракт «что такое outside» определяется переданным containerRef:
 * клик вне него закрывает попап.
 *
 * Продление окна бездействия — через keepAlive, который вызывается на
 * активность внутри попапа (наведение, движение мыши). Пока пользователь
 * наводит на эмодзи, попап не закрывается.
 *
 * @param {React.RefObject<HTMLElement>} containerRef — область «внутри»
 * @param {number} [timeout] — мс бездействия до авто-закрытия
 */
export function useReactionPicker(containerRef, timeout = AUTO_DISMISS_MS) {
  const [open, setOpen] = useState(false);
  const timerRef = useRef(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const close = useCallback(() => {
    clearTimer();
    setOpen(false);
  }, [clearTimer]);

  // Авто-закрытие: таймер живёт ровно пока попап открыт. Cleanup снимет
  // его при закрытии или размонтировании — «выстрелить» в мёртвый
  // компонент таймер не может.
  useEffect(() => {
    if (!open) return;
    timerRef.current = setTimeout(() => setOpen(false), timeout);
    return clearTimer;
  }, [open, timeout, clearTimer]);

  // Закрытие по клику вне контейнера. Слушатель ставим только когда
  // попап открыт — вне открытого состояния ему нечего делать.
  useEffect(() => {
    if (!open) return;
    const onOutside = (event) => {
      const el = containerRef.current;
      if (el && !el.contains(event.target)) close();
    };
    document.addEventListener('mousedown', onOutside);
    return () => document.removeEventListener('mousedown', onOutside);
  }, [open, close, containerRef]);

  /**
   * Продлить окно бездействия. Единственный публичный «стук активности»:
   * попап сам решает, что с ним делать (сейчас — перезапустить таймер).
   */
  const keepAlive = useCallback(() => {
    clearTimer();
    timerRef.current = setTimeout(() => setOpen(false), timeout);
  }, [clearTimer, timeout]);

  const toggle = useCallback(() => {
    setOpen((prev) => !prev);
  }, []);

  return { open, toggle, close, keepAlive };
}