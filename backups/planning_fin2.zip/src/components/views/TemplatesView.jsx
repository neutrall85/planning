// src/components/views/TemplatesView.jsx
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useStore } from '../../hooks/useStore';
import { useToast } from '../../context/ToastContext';
import { useConfirm } from '../../context/ConfirmContext';
import Avatar from '../Avatar';
import { Ic, ICONS } from '../Icons';
import { fmtDT } from '../../utils/date';
import { DIALOGS, TOASTS } from '../../utils/constants';
import { TEMPLATE_KINDS } from '../../utils/templateSchemas';
import { countNestedTasks } from '../../utils/templateNesting';
import TemplateModal from '../Templates/TemplateModal';

const KIND_LABELS = {
  task: 'Задача',
  project: 'Проект',
};

const MODES = Object.freeze({
  edit: 'edit',
  view: 'view',
});

export default function TemplatesView() {
  const { store } = useStore();
  const { showToast } = useToast();
  const { confirm } = useConfirm();

  const [templates, setTemplates] = useState(() => store.getAllTemplates());
  const [filterKind, setFilterKind] = useState('all');
  const [modal, setModal] = useState(null);

  useEffect(() => {
    const unsubscribe = store.subscribe(() => setTemplates(store.getAllTemplates()));
    return unsubscribe;
  }, [store]);

  const currentUserId = store.getCurrentUser()?.id || null;

  const visible = useMemo(() => {
    if (filterKind === 'all') return templates;
    return templates.filter(t => t.kind === filterKind);
  }, [templates, filterKind]);

  const openTemplate = useCallback((template) => {
    const isMine = template.ownerId === currentUserId;
    setModal({
      mode: isMine ? MODES.edit : MODES.view,
      template,
    });
  }, [currentUserId]);

  const closeModal = useCallback(() => setModal(null), []);

  const deleteTemplate = useCallback(async (template) => {
    const ok = await confirm(DIALOGS.deleteTemplate(template.name));
    if (!ok) return;
    try {
      store.deleteTemplate(template.id);
      showToast(TOASTS.templateDeleted, 'success');
    } catch (error) {
      showToast(error.message || 'Не удалось удалить шаблон', 'error');
    }
  }, [store, showToast, confirm]);

  const renderRow = (template) => {
    const owner = store.data.employees.find(e => e.id === template.ownerId);
    const isMine = template.ownerId === currentUserId;

    const projectTasksCount = template.kind === 'project' && Array.isArray(template.payload.tasks)
      ? countNestedTasks(template.payload.tasks)
      : 0;
    const taskSubtasksCount = template.kind === 'task' && Array.isArray(template.payload.subtasks)
      ? countNestedTasks(template.payload.subtasks)
      : 0;

    const templateProject = template.kind === 'task' && template.payload.projectId
      ? store.data.projects.find(p => p.id === template.payload.projectId)
      : null;

    return (
      <tr
        key={template.id}
        className="clickable-row"
        onClick={() => openTemplate(template)}
      >
        <td>
          <b>{template.name}</b>
          {projectTasksCount > 0 && (
            <span className="mut sm"> · {projectTasksCount} задач</span>
          )}
          {taskSubtasksCount > 0 && (
            <span className="mut sm"> · {taskSubtasksCount} подзадач</span>
          )}
          {templateProject && (
            <span className="mut sm"> · {templateProject.code}</span>
          )}
        </td>
        <td>
          <span className="st-chip">
            {KIND_LABELS[template.kind] || TEMPLATE_KINDS[template.kind]?.label || template.kind}
          </span>
        </td>
        <td>
          <div className="templates-owner">
            <Avatar employee={owner} size="xs" />
            <span>{owner ? `${owner.last} ${owner.first}` : '-'}</span>
            {isMine && <span className="mut sm">· вы</span>}
          </div>
        </td>
        <td className="mut sm">{fmtDT(template.updatedAt)}</td>
        <td>
          <span className={`st-chip ${template.isShared ? 'approved' : ''}`}>
            {template.isShared ? 'общий' : 'личный'}
          </span>
        </td>
        <td className="templates-actions" onClick={(e) => e.stopPropagation()}>
          <button
            className="icon-btn"
            title={isMine ? 'Редактировать' : 'Просмотр'}
            onClick={() => openTemplate(template)}
          >
            <Ic d={isMine ? ICONS.edit : ICONS.eye} size={14} />
          </button>
          {isMine && (
            <button
              className="icon-btn danger"
              title="Удалить"
              onClick={() => deleteTemplate(template)}
            >
              <Ic d={ICONS.trash} size={14} />
            </button>
          )}
        </td>
      </tr>
    );
  };

  return (
    <div className="rep">
      <div className="rep-panel p-4">
        <div className="rep-panel-title flex justify-between items-center">
          <span>Шаблоны</span>
          <div className="seg sm">
            {[
              { id: 'all', label: 'Все' },
              { id: 'task', label: 'Задачи' },
              { id: 'project', label: 'Проекты' },
            ].map(opt => (
              <button
                key={opt.id}
                type="button"
                className={`seg-btn${filterKind === opt.id ? ' on' : ''}`}
                onClick={() => setFilterKind(opt.id)}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <p className="mut sm mb-3">
          Шаблоны - это сохранённые заготовки полей задачи или проекта.
          Примените шаблон в карточке при создании новой сущности.
          Свои шаблоны можно редактировать полностью, чужие общие - только просматривать.
        </p>

        {visible.length === 0 ? (
          <div className="empty-note p-4">Шаблонов пока нет</div>
        ) : (
          <div className="w-full overflow-x-auto">
            <table className="tbl templates-table">
              <thead>
                <tr>
                  <th className="templates-th-name">Название</th>
                  <th className="templates-th-kind">Тип</th>
                  <th className="templates-th-owner">Создатель</th>
                  <th className="templates-th-updated">Обновлён</th>
                  <th className="templates-th-access">Доступ</th>
                  <th className="templates-th-actions"></th>
                </tr>
              </thead>
              <tbody>
                {visible.map(renderRow)}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <TemplateModal
          mode={modal.mode}
          template={modal.template}
          onClose={closeModal}
          toast={showToast}
        />
      )}
    </div>
  );
}