import { useCallback, useState } from 'react';
import { ModalShell } from '../ModalShell';
import { FormField } from '../FormField';
import { useForm } from '../../hooks/useForm';
import { useAsyncSubmit } from '../../hooks/useAsyncSubmit';
import { useStore } from '../../hooks/useStore';
import { TEMPLATE_KINDS } from '../../utils/templateSchemas';
import { countNestedTasks } from '../../utils/templateNesting';
import { useNestedModalEscape } from './useNestedModalEscape';

const MAX_NAME_LENGTH = 80;

/**
 * Два режима одной модалки:
 *  - создание: передаётся { kind, source, nested? } - payload проходит через whitelist;
 *  - настройки: передаётся { template } - доступны только name и isShared,
 *    payload неизменяем, иначе «эталонная заготовка» теряет смысл.
 */
export default function SaveTemplateModal({
  kind,
  source,
  nested = [],
  template = null,
  onClose,
  toast,
}) {
  const { store } = useStore();
  useNestedModalEscape(onClose);

  const isEdit = !!template;
  const effectiveKind = template?.kind || kind;
  const kindMeta = TEMPLATE_KINDS[effectiveKind];
  const nestedKey = kindMeta?.nestedKey;
  const nestedLabel = kindMeta?.nestedLabel || 'вложенные элементы';
  const nestedTotal = countNestedTasks(nested);
  const hasNested = !isEdit && nestedTotal > 0;

  const [includeNested, setIncludeNested] = useState(hasNested);

  const initialValues = isEdit
    ? { name: template.name || '', isShared: !!template.isShared }
    : { name: '', isShared: false };

  const validate = useCallback((values) => {
    const errors = {};
    const name = String(values.name || '').trim();
    if (!name) errors.name = 'Укажите название';
    else if (name.length > MAX_NAME_LENGTH) errors.name = `Не более ${MAX_NAME_LENGTH} символов`;
    return errors;
  }, []);

  const saveAsync = useCallback(async (values) => {
    if (isEdit) {
      store.updateTemplate(template.id, {
        name: values.name,
        isShared: values.isShared,
      });
    } else {
      const payloadSource = { ...source };
      if (nestedKey) {
        if (includeNested && hasNested) payloadSource[nestedKey] = nested;
        else delete payloadSource[nestedKey];
      }
      store.saveTemplate({
        kind: effectiveKind,
        name: values.name,
        isShared: values.isShared,
        source: payloadSource,
      });
    }
    onClose();
  }, [
    isEdit, template, effectiveKind, source, nested,
    includeNested, hasNested, nestedKey, store, onClose,
  ]);

  const { values, handleChange, handleSubmit, errors, touched } = useForm(initialValues, validate);
  const { submit, isSubmitting } = useAsyncSubmit(saveAsync, (error) => {
    toast(error.message || 'Не удалось сохранить шаблон', 'error');
  });

  const title = isEdit
    ? 'Настройки шаблона'
    : `Сохранить как шаблон ${kindMeta?.label || 'сущности'}`;

  const saveLabel = isEdit ? 'Сохранить' : 'Создать';

  return (
    <ModalShell
      title={title}
      onClose={onClose}
      onSave={handleSubmit(submit)}
      saveLabel={saveLabel}
      width={480}
      saveDisabled={isSubmitting}
    >
      <div className="project-info-fields">
        <FormField
          label="Название шаблона *"
          value={values.name}
          onChange={(v) => handleChange('name', v)}
          error={touched.name && errors.name}
          inline
        />

        {hasNested && (
          <div className="field-row">
            <label className="field-label">{nestedLabel}</label>
            <label className="dept-pick">
              <input
                type="checkbox"
                checked={includeNested}
                onChange={(e) => setIncludeNested(e.target.checked)}
              />
              <span>
                Включить в шаблон: {nestedTotal} {nestedLabel}
              </span>
            </label>
          </div>
        )}

        <div className="field-row">
          <label className="field-label">Общий шаблон</label>
          <label className="dept-pick">
            <input
              type="checkbox"
              checked={values.isShared}
              onChange={(e) => handleChange('isShared', e.target.checked)}
            />
            <span>
              {values.isShared
                ? 'Доступен всем сотрудникам'
                : 'Личный - видите только вы'}
            </span>
          </label>
        </div>
      </div>
    </ModalShell>
  );
}