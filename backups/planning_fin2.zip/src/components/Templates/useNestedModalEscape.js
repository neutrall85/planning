import { useEffect } from 'react';

/**
 * Позволяет вложенной модалке обрабатывать Escape первой.
 * Modal.jsx подписан на window в фазе всплытия; перехват в фазе
 * погружения гарантирует, что Escape закроет только верхнюю модалку.
 */
export function useNestedModalEscape(onEscape) {
  useEffect(() => {
    const handler = (event) => {
      if (event.key !== 'Escape') return;
      event.stopImmediatePropagation();
      onEscape();
    };
    window.addEventListener('keydown', handler, true);
    return () => window.removeEventListener('keydown', handler, true);
  }, [onEscape]);
}