import { FormField } from '../FormField';
import { TEMPLATE_FIELDS_META } from '../../utils/templateSchemas';

const TASK_META = TEMPLATE_FIELDS_META.task;
const MAX_DEPTH = 5;

const createEmptyNode = (singular) => ({
  title: `Новая ${singular}`,
  priority: 'mid',
  plannedHours: 8,
});

/**
 * Рекурсивный редактор узла дерева задач. Используется и для задач
 * шаблона проекта, и для подзадач шаблона задачи - структура payload
 * идентична. Вложенность ограничена CSS-классами по data-depth.
 */
export default function TaskNodeEditor({
  node,
  depth = 1,
  readOnly = false,
  childSingular = 'подзадача',
  onChange,
  onDelete,
}) {
  const children = Array.isArray(node.subtasks) ? node.subtasks : [];
  const safeDepth = Math.min(depth, MAX_DEPTH);

  const updateField = (field, value) => onChange({ ...node, [field]: value });

  const updateChild = (idx, child) => {
    const next = children.map((c, i) => (i === idx ? child : c));
    onChange({ ...node, subtasks: next });
  };

  const deleteChild = (idx) => {
    const next = children.filter((_, i) => i !== idx);
    const copy = { ...node };
    if (next.length) copy.subtasks = next;
    else delete copy.subtasks;
    onChange(copy);
  };

  const addChild = () => {
    onChange({ ...node, subtasks: [...children, createEmptyNode(childSingular)] });
  };

  return (
    <div className="template-tree-node" data-depth={safeDepth}>
      <FormField
        label="Название"
        required
        value={node.title ?? ''}
        onChange={(v) => updateField('title', v)}
        disabled={readOnly}
        inline
      />
      <FormField
        label="Описание"
        type="textarea"
        rows={2}
        value={node.desc ?? ''}
        onChange={(v) => updateField('desc', v)}
        disabled={readOnly}
        inline
      />
      <div className="fields-row">
        <FormField
          label="Приоритет"
          type="select"
          options={TASK_META.priority.options}
          value={node.priority ?? 'mid'}
          onChange={(v) => updateField('priority', v)}
          disabled={readOnly}
          inline
        />
        <FormField
          label="Плановые часы"
          type="number"
          min="0"
          step="0.5"
          value={node.plannedHours ?? ''}
          onChange={(v) => updateField('plannedHours', v)}
          disabled={readOnly}
          inline
        />
      </div>

      {children.map((child, idx) => (
        <TaskNodeEditor
          key={idx}
          node={child}
          depth={safeDepth + 1}
          readOnly={readOnly}
          childSingular={childSingular}
          onChange={(next) => updateChild(idx, next)}
          onDelete={() => deleteChild(idx)}
        />
      ))}

      {!readOnly && (
        <div className="template-tree-actions">
          <button type="button" className="btn ghost sm" onClick={addChild}>
            + {childSingular}
          </button>
          {onDelete && (
            <button type="button" className="btn danger sm" onClick={onDelete}>
              Удалить
            </button>
          )}
        </div>
      )}
    </div>
  );
}