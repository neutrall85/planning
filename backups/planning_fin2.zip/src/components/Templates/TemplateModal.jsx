import { useCallback, useMemo, useState } from 'react';
import { ModalShell } from '../ModalShell';
import { FormField } from '../FormField';
import { useForm } from '../../hooks/useForm';
import { useAsyncSubmit } from '../../hooks/useAsyncSubmit';
import { useStore } from '../../hooks/useStore';
import {
  TEMPLATE_KINDS,
  TEMPLATE_FIELDS_META,
  TEMPLATE_KIND_LABELS,
} from '../../utils/templateSchemas';
import { countNestedTasks } from '../../utils/templateNesting';
import { useNestedModalEscape } from './useNestedModalEscape';
import TaskNodeEditor from './TaskNodeEditor';

const MAX_NAME_LENGTH = 80;

const MODES = Object.freeze({
  create: 'create',
  edit: 'edit',
  view: 'view',
});

const createEmptyNestedNode = (singular) => ({
  title: `Новая ${singular}`,
  priority: 'mid',
  plannedHours: 8,
});

export default function TemplateModal({
  mode = MODES.create,
  kind: propKind,
  source,
  nested = [],
  template = null,
  onClose,
  toast,
}) {
  const { store } = useStore();
  useNestedModalEscape(onClose);

  const isCreate = mode === MODES.create;
  const isEdit = mode === MODES.edit;
  const isView = mode === MODES.view;
  const readOnly = isView;

  const effectiveKind = template?.kind || propKind;
  const kindMeta = TEMPLATE_KINDS[effectiveKind];
  const fieldsMeta = TEMPLATE_FIELDS_META[effectiveKind] || {};
  const nestedKey = kindMeta?.nestedKey;
  const nestedLabel = kindMeta?.nestedLabel || 'вложенные элементы';
  const nestedSingular = kindMeta?.nestedSingular || 'элемент';
  const kindLabel = TEMPLATE_KIND_LABELS[effectiveKind] || 'сущности';

  const initialPayload = useMemo(() => {
    if (isCreate) {
      const base = { ...(source || {}) };
      if (nested.length && nestedKey) base[nestedKey] = nested;
      return base;
    }
    return { ...(template?.payload || {}) };
  }, []);

  const [payload, setPayload] = useState(initialPayload);
  const [includeNested, setIncludeNested] = useState(
    () => Array.isArray(initialPayload[nestedKey]) && initialPayload[nestedKey].length > 0
  );

  const nestedItems = useMemo(
    () => (Array.isArray(payload[nestedKey]) ? payload[nestedKey] : []),
    [payload, nestedKey]
  );

  const initialValues = useMemo(() => ({
    name: template?.name || '',
    isShared: template?.isShared || false,
  }), [template]);

  const validate = useCallback((vals) => {
    const errors = {};
    const name = String(vals.name || '').trim();
    if (!name) errors.name = 'Укажите название';
    else if (name.length > MAX_NAME_LENGTH) errors.name = `Не более ${MAX_NAME_LENGTH} символов`;
    return errors;
  }, []);

  const setPayloadField = useCallback((field, value) => {
    setPayload((prev) => ({ ...prev, [field]: value }));
  }, []);

  const setNested = useCallback((next) => {
    setPayload((prev) => {
      const copy = { ...prev };
      if (next.length) copy[nestedKey] = next;
      else delete copy[nestedKey];
      return copy;
    });
  }, [nestedKey]);

  const saveAsync = useCallback(async (vals) => {
    if (isEdit) {
      store.updateTemplate(template.id, {
        name: vals.name,
        isShared: vals.isShared,
        payload,
      });
    } else if (isCreate) {
      const payloadSource = { ...payload };
      if (nestedKey && !includeNested) delete payloadSource[nestedKey];
      store.saveTemplate({
        kind: effectiveKind,
        name: vals.name,
        isShared: vals.isShared,
        source: payloadSource,
      });
    }
    onClose();
  }, [isEdit, isCreate, template, payload, includeNested, nestedKey, effectiveKind, store, onClose]);

  const { values, handleChange, handleSubmit, errors, touched } = useForm(initialValues, validate);
  const { submit, isSubmitting } = useAsyncSubmit(saveAsync, (error) => {
    toast(error.message || 'Не удалось сохранить шаблон', 'error');
  });

  const title = isView
    ? `Шаблон: ${template?.name || ''}`
    : isEdit
      ? `Редактирование шаблона ${kindLabel}`
      : `Сохранить как шаблон ${kindLabel}`;

  const saveLabel = isEdit ? 'Сохранить' : 'Создать';

  const footer = isView
    ? (
      <div className="modal-foot">
        <div className="spacer" />
        <button className="btn ghost" onClick={onClose}>Закрыть</button>
      </div>
    )
    : null;

  const nestedCount = countNestedTasks(nestedItems);

  const addNestedNode = () => {
    setNested([...nestedItems, createEmptyNestedNode(nestedSingular)]);
  };

  const renderProjectField = () => {
    if (effectiveKind !== 'task') return null;

    const projectId = payload.projectId ?? '';
    const project = projectId
      ? store.data.projects.find(p => p.id === projectId)
      : null;

    if (readOnly) {
      const display = project
        ? `${project.code} - ${project.name}`
        : (projectId ? 'Проект недоступен' : '- не указан -');
      return (
        <div className="field-row">
          <label className="field-label">Проект</label>
          <div className="flex-1">
            <div className="inp" aria-disabled="true">{display}</div>
          </div>
        </div>
      );
    }

    const projectOptions = [
      { value: '', label: '- Не выбран -' },
      ...store.data.projects
        .filter(p => p.status === 'active' && !p.archived)
        .sort((a, b) => a.code.localeCompare(b.code))
        .map(p => ({ value: p.id, label: `${p.code} - ${p.name}` })),
    ];

    return (
      <FormField
        label="Проект"
        type="select"
        options={projectOptions}
        value={projectId}
        onChange={(v) => setPayloadField('projectId', v)}
        inline
      />
    );
  };

  const renderNestedEditor = () => {
    if (!nestedKey) return null;

    if (isView) {
      if (!nestedItems.length) return null;
      return (
        <div className="mt-3">
          <div className="rep-panel-title">{nestedLabel} ({nestedCount})</div>
          {nestedItems.map((node, idx) => (
            <TaskNodeEditor
              key={idx}
              node={node}
              readOnly
              onChange={() => {}}
            />
          ))}
        </div>
      );
    }

    if (isCreate) {
      if (!nestedItems.length) return null;
      return (
        <div className="field-row">
          <label className="field-label">{nestedLabel}</label>
          <label className="dept-pick">
            <input
              type="checkbox"
              checked={includeNested}
              onChange={(e) => setIncludeNested(e.target.checked)}
            />
            <span>Включить в шаблон: {nestedCount} {nestedLabel}</span>
          </label>
        </div>
      );
    }

    return (
      <div className="mt-3">
        <div className="template-tree-header">
          <div className="template-tree-title">{nestedLabel} ({nestedCount})</div>
          <button type="button" className="btn ghost sm" onClick={addNestedNode}>
            + {nestedSingular}
          </button>
        </div>
        {nestedItems.length === 0 && (
          <div className="mut sm">Вложенных элементов нет</div>
        )}
        {nestedItems.map((node, idx) => (
          <TaskNodeEditor
            key={idx}
            node={node}
            readOnly={false}
            onChange={(next) => setNested(nestedItems.map((n, i) => i === idx ? next : n))}
            onDelete={() => setNested(nestedItems.filter((_, i) => i !== idx))}
          />
        ))}
      </div>
    );
  };

  return (
    <ModalShell
      title={title}
      onClose={onClose}
      onSave={isView ? undefined : handleSubmit(submit)}
      saveLabel={saveLabel}
      showSave={!isView}
      saveDisabled={isSubmitting}
      width={620}
      footer={footer}
    >
      <div className="project-info-fields">
        {isView && (
          <div className="info-box">
            Это общий шаблон. Менять его содержимое может только владелец.
          </div>
        )}

        <FormField
          label="Название шаблона *"
          value={values.name}
          onChange={(v) => handleChange('name', v)}
          error={touched.name && errors.name}
          disabled={readOnly}
          inline
        />

        <div className="field-row">
          <label className="field-label">Общий шаблон</label>
          <label className="dept-pick">
            <input
              type="checkbox"
              checked={values.isShared}
              disabled={readOnly}
              onChange={(e) => handleChange('isShared', e.target.checked)}
            />
            <span>
              {values.isShared
                ? 'Доступен всем сотрудникам'
                : 'Личный - видите только вы'}
            </span>
          </label>
        </div>

        {Object.keys(fieldsMeta).length > 0 && (
          <div className="mt-3">
            <div className="rep-panel-title">Параметры</div>
            {renderProjectField()}
            {Object.entries(fieldsMeta).map(([field, meta]) => (
              <FormField
                key={field}
                label={meta.label}
                required={meta.required}
                type={meta.type || 'text'}
                options={meta.options}
                rows={meta.type === 'textarea' ? 2 : undefined}
                value={payload[field] ?? ''}
                onChange={(v) => setPayloadField(field, v)}
                disabled={readOnly}
                inline
              />
            ))}
          </div>
        )}

        {renderNestedEditor()}
      </div>
    </ModalShell>
  );
}