// src/components/discussion/ReactionPicker.jsx
import React from 'react';
import { REACTION_PALETTE } from './constants';

/**
 * Маппинг Unicode-эмодзи на shortcode, которые понимает Emoteer.
 * Полный список shortcode: https://emojibase.dev/
 */
const EMOJI_TO_SHORTCODE = {
  '👍': 'thumbs_up',
  '❤️': 'red_heart',
  '🔥': 'fire',
  '😂': 'face_with_tears_of_joy',
  '😮': 'face_with_open_mouth',
  '😢': 'crying_face',
  '✅': 'check_mark_button',
};

/**
 * Панель выбора реакций на базе Emoteer.
 *
 * Вся логика «сколько попап живёт» — в useReactionPicker у вызывающего.
 * Emoteer-компоненты отвечают за доступность, анимацию и обработку выбора.
 *
 * @param {string|null} activeEmoji — текущая реакция пользователя (Unicode)
 * @param {(emoji: string) => void} onPick — коллбэк выбора (получает Unicode)
 * @param {() => void} onActivity — сигнал «пользователь взаимодействует»
 */
export default function ReactionPicker({ activeEmoji, onPick, onActivity }) {
  /**
   * Emoteer работает с shortcode. На входе мы имеем Unicode-эмодзи,
   * поэтому для проверки «активна ли реакция» переводим shortcode
   * обратно в Unicode через обратный маппинг.
   */
  const activeShortcode = activeEmoji
    ? EMOJI_TO_SHORTCODE[activeEmoji] || null
    : null;

  const handleSelect = (emote) => {
    // emote.shortcode — это строка вида "thumbs_up"
    // Нам нужен Unicode для хранения в данных
    const unicode = Object.entries(EMOJI_TO_SHORTCODE)
      .find(([, sc]) => sc === emote.shortcode)?.[0] || emote.unicode;

    if (unicode) {
      onPick(unicode);
    }
  };

  return (
    <div
      className="reaction-picker"
      onClick={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
      onMouseEnter={onActivity}
      onMouseMove={onActivity}
    >
      <ReactionButton.Root onSelect={handleSelect}>
        {REACTION_PALETTE.map(emoji => {
          const shortcode = EMOJI_TO_SHORTCODE[emoji];
          if (!shortcode) return null;

          return (
            <ReactionButton.Item
              key={emoji}
              emoji={shortcode}
              isActive={activeShortcode === shortcode}
            />
          );
        })}
      </ReactionButton.Root>
    </div>
  );
}