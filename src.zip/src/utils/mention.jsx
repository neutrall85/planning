// src/utils/mention.jsx
import React from 'react';

export function renderMentionText(text) {
  return text.split("@").map((part, i) => {
    if (i === 0) return <span key={i}>{part}</span>;
    const tokens = part.split(/(\s+)/);
    let mention = tokens[0];
    let restStart = 1;
    if (tokens.length > 2 && /^[А-ЯA-ZЁ]/.test(tokens[2])) { mention += " " + tokens[2]; restStart = 3; }
    return <span key={i}><span className="mention">@{mention}</span>{tokens.slice(restStart).join("")}</span>;
  });
}

export function extractMentions(text, employees) {
  const found = [];
  text.split("@").slice(1).forEach((part) => {
    const token = part.trim().split(/[\s,.!?:;]/)[0].toLowerCase();
    if (!token) return;
    const emp = employees.find((e) => e.last.toLowerCase() === token);
    if (emp && !found.includes(emp.id)) found.push(emp.id);
  });
  return found;
}

export function projectParticipants(db, projectId) {
  const ids = new Set(db.tasks.filter((t) => t.projectId === projectId).map((t) => t.assigneeIds || []).flat());
  const p = db.projects.find((x) => x.id === projectId);
  if (p && p.managerId) ids.add(p.managerId);
  return [...ids].map((id) => db.employees.find((e) => e.id === id)).filter(Boolean);
}