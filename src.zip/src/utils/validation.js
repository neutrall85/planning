export const required = (msg = 'Поле обязательно') => ({ required: msg });
export const minLength = (value, msg) => ({ minLength: { value, message: msg } });
export const maxLength = (value, msg) => ({ maxLength: { value, message: msg } });
export const pattern = (regex, msg) => ({ pattern: { value: regex, message: msg } });
export const positiveNumber = (msg = 'Должно быть положительным числом') => ({
  validate: (v) => (!isNaN(v) && +v > 0) || msg,
});
export const minNumber = (min, msg) => ({
  validate: (v) => (!isNaN(v) && +v >= min) || msg,
});
export const maxNumber = (max, msg) => ({
  validate: (v) => (!isNaN(v) && +v <= max) || msg,
});
export const emailFormat = (msg = 'Некорректный e-mail') => ({
  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: msg },
});
export const passwordStrength = (msg = 'Пароль должен содержать минимум 8 символов, заглавную, строчную, цифру и спецсимвол') => ({
  validate: (v) => {
    if (!v) return true;
    const checks = [
      v.length >= 8,
      /[A-ZА-ЯЁ]/.test(v),
      /[a-zа-яё]/.test(v),
      /\d/.test(v),
      /[^A-Za-zА-Яа-яЁё0-9]/.test(v),
    ];
    return checks.every(Boolean) || msg;
  },
});