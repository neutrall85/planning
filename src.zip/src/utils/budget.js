// utils/budget.js
export function checkProjectBudget(project, allTasks, taskToValidate) {
  if (!project) return;
  if (project.budget == null || project.ptype === 'admin' || project.archived) return;
  const others = allTasks.filter(t => t.projectId === project.id && t.id !== taskToValidate.id);
  const sum = others.reduce((s, t) => s + (t.plannedHours || 0), 0);
  const total = sum + (taskToValidate.plannedHours || 0);
  if (total > project.budget) {
    throw new Error(
      `Превышение бюджета проекта! Бюджет: ${project.budget} ч, текущая сумма задач: ${sum} ч, запрошено: ${taskToValidate.plannedHours || 0} ч.`
    );
  }
}