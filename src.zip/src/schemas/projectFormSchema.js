import { PROJECT_STATUSES, PROJECT_TYPES } from '../utils/constants';
import { required } from '../utils/validation';

export const getProjectFormSchema = (db, ur, isAdminType, canEditFields, readOnly) => {
  const disabled = readOnly || !canEditFields;
  return [
    {
      name: 'ptype',
      label: 'Тип проекта',
      type: 'select',
      required: true,
      rules: required('Выберите тип'),
      props: {
        options: Object.entries(PROJECT_TYPES).map(([k, v]) => ({ value: k, label: v })),
        disabled,
      },
    },
    {
      name: 'code',
      label: 'Код',
      type: 'text',
      required: true,
      rules: required('Код обязателен'),
      props: { disabled },
    },
    {
      name: 'name',
      label: 'Название',
      type: 'text',
      required: true,
      rules: required('Название обязательно'),
      props: { disabled },
    },
    {
      name: 'desc',
      label: 'Описание',
      type: 'textarea',
      props: { rows: 2, disabled },
    },
    {
      name: 'customer',
      label: isAdminType ? 'Заказчик' : 'Заказчик *',
      type: 'text',
      required: !isAdminType,
      rules: !isAdminType ? required('Укажите заказчика') : {},
      props: { disabled },
    },
    !isAdminType && {
      name: 'aircraftType',
      label: 'Тип ВС *',
      type: 'select',
      required: true,
      rules: required('Выберите тип ВС'),
      props: {
        options: ['Су-57', 'МиГ-35', 'Ту-160', 'Ил-76', 'Ка-52', 'Другой'].map(v => ({ value: v, label: v })),
        disabled,
      },
    },
    !isAdminType && {
      name: 'projectType',
      label: 'Тип проекта *',
      type: 'select',
      required: true,
      rules: required('Выберите тип проекта'),
      props: {
        options: ['Ремонт', 'Модификация'].map(v => ({ value: v, label: v })),
        disabled,
      },
    },
    {
      name: 'kbId',
      label: 'Подразделение',
      type: 'select',
      props: {
        options: [{ value: '', label: 'Общеорганизационный' }, ...db.kbs.map(k => ({ value: k.id, label: k.name }))],
        disabled,
      },
    },
    {
      name: 'managerId',
      label: isAdminType ? 'Ответственный' : 'Ответственный *',
      type: 'select',
      required: !isAdminType,
      rules: !isAdminType ? required('Выберите ответственного') : {},
      props: {
        options: [{ value: '', label: '— выберите —' }, ...db.employees.map(e => ({ value: e.id, label: `${e.last} ${e.first}` }))],
        disabled,
      },
    },
    {
      name: 'start',
      label: 'Дата начала *',
      type: 'date',
      required: true,
      rules: required('Укажите дату начала'),
      props: { disabled },
    },
    {
      name: 'end',
      label: isAdminType ? 'Дата окончания' : 'Дата окончания *',
      type: 'date',
      required: !isAdminType,
      rules: !isAdminType ? required('Укажите дату окончания') : {},
      props: { disabled },
    },
    {
      name: 'budget',
      label: isAdminType ? 'Бюджет, ч (опционально)' : 'Бюджет, ч *',
      type: 'text',
      required: !isAdminType,
      rules: !isAdminType ? { ...required('Укажите бюджет'), validate: v => +v > 0 || 'Бюджет должен быть положительным' } : {},
      props: { type: 'number', min: 1, disabled, placeholder: isAdminType ? 'необязательно' : '' },
    },
    {
      name: 'status',
      label: 'Статус',
      type: 'select',
      required: true,
      rules: required('Выберите статус'),
      props: {
        options: Object.entries(PROJECT_STATUSES).map(([k, v]) => ({ value: k, label: v.label })),
        disabled: readOnly || !canEditFields,
      },
    },
    isAdminType && {
      name: 'longterm',
      label: 'Долгосрочный',
      type: 'checkbox',
      props: { disabled: !canEditFields || readOnly },
    },
  ].filter(Boolean);
};