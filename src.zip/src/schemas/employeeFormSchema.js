import { ROLES } from '../utils/constants';
import { required, minLength, emailFormat, passwordStrength } from '../utils/validation';

export const getEmployeeFormSchema = (db, isEdit) => {
  const deptOptions = db.departments.map(d => ({ value: d.id, label: d.name }));
  const roleOptions = Object.entries(ROLES).map(([k, v]) => ({ value: k, label: v.label }));
  const kbOptions = db.kbs.map(k => ({ value: k.id, label: k.name }));

  return [
    {
      name: 'last',
      label: 'Фамилия *',
      type: 'text',
      required: true,
      rules: required('Фамилия обязательна'),
      props: { placeholder: 'Иванов' },
    },
    {
      name: 'first',
      label: 'Имя *',
      type: 'text',
      required: true,
      rules: required('Имя обязательно'),
      props: { placeholder: 'Иван' },
    },
    {
      name: 'email',
      label: 'E-mail *',
      type: 'text',
      required: true,
      rules: { ...required('E-mail обязателен'), ...emailFormat('Некорректный e-mail') },
      props: { placeholder: 'ivanov' },
    },
    !isEdit && {
      name: 'pass',
      label: 'Пароль *',
      type: 'text',
      required: true,
      rules: { ...required('Пароль обязателен'), ...passwordStrength() },
      props: { type: 'password', placeholder: 'минимум 8 символов' },
    },
    {
      name: 'position',
      label: 'Должность',
      type: 'text',
      props: { placeholder: 'Инженер-конструктор' },
    },
    {
      name: 'phone',
      label: 'Телефон',
      type: 'text',
      props: { placeholder: '+7 900 000-00-00' },
    },
    {
      name: 'extension',
      label: 'Внутренний номер',
      type: 'text',
      props: { placeholder: '101' },
    },
    {
      name: 'tab',
      label: 'Табельный №',
      type: 'text',
      props: { placeholder: '1001' },
    },
    // Подразделения и роли – сложные кастомные поля, будут рендериться через renderCustomFields
  ];
};