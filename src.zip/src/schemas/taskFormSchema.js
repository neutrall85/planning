import { TASK_STATUSES, PRIORITIES, DEPENDENCY_TYPES } from '../utils/constants';
import { required, positiveNumber } from '../utils/validation';

export const getTaskFormSchema = (db, ur, existing, readOnly, canEditFields, statusOptions, isAdminProj) => {
  const disabled = readOnly || !canEditFields;
  const isEdit = !!existing;

  return [
    {
      name: 'title',
      label: 'Название',
      type: 'text',
      required: true,
      rules: required('Название обязательно'),
      props: { disabled, placeholder: 'Введите название задачи' },
    },
    {
      name: 'desc',
      label: 'Описание',
      type: 'textarea',
      props: { rows: 2, disabled, placeholder: 'Краткое описание' },
    },
    {
      name: 'projectId',
      label: 'Проект',
      type: 'select',
      required: true,
      rules: required('Выберите проект'),
      props: {
        options: db.projects
          .filter(p => p.status === 'active' && !p.archived)
          .map(p => ({ value: p.id, label: `${p.code} — ${p.name}${p.ptype === 'admin' ? ' (административный)' : ''}` })),
        disabled: !canEditFields || readOnly,
      },
    },
    {
      name: 'priority',
      label: 'Приоритет',
      type: 'select',
      required: true,
      rules: required('Выберите приоритет'),
      props: {
        options: Object.entries(PRIORITIES).map(([k, v]) => ({ value: k, label: v.label })),
        disabled,
      },
    },
    {
      name: 'start',
      label: 'Начало работы',
      type: 'date',
      props: { disabled },
    },
    {
      name: 'deadline',
      label: isAdminProj ? 'Дедлайн (опционально)' : 'Дедлайн',
      type: 'date',
      required: !isAdminProj,
      rules: !isAdminProj ? required('Дедлайн обязателен') : {},
      props: { disabled: !canEditFields || readOnly },
    },
    {
      name: 'plannedHours',
      label: isAdminProj ? 'Плановые часы (опционально)' : 'Плановые часы',
      type: 'text',
      required: !isAdminProj,
      rules: !isAdminProj ? { ...positiveNumber('Введите корректное число'), required: 'Плановые часы обязательны' } : {},
      props: { type: 'number', step: '0.5', min: 0.5, disabled: !canEditFields || readOnly },
    },
    {
      name: 'status',
      label: 'Статус',
      type: 'select',
      required: true,
      rules: required('Укажите статус'),
      props: {
        options: statusOptions.map(s => ({ value: s, label: TASK_STATUSES[s].label })),
        disabled: readOnly || !canEditFields,
      },
    },
    {
      name: 'dependencyId',
      label: 'Зависит от задачи',
      type: 'select',
      props: {
        options: [
          { value: '', label: '— нет зависимости —' },
          ...db.tasks
            .filter(t => t.id !== (existing?.id) && t.projectId === (existing?.projectId || '') && t.status !== 'closed' && t.status !== 'cancelled')
            .map(t => ({ value: t.id, label: t.title })),
        ],
        disabled: !canEditFields || readOnly,
      },
    },
    {
      name: 'dependencyType',
      label: 'Тип зависимости',
      type: 'select',
      props: {
        options: Object.entries(DEPENDENCY_TYPES).map(([key, val]) => ({ value: key, label: val.label })),
        disabled: !canEditFields || readOnly || !existing?.dependencyId,
      },
    },
  ];
};