import { VACATION_TYPES } from '../utils/constants';
import { required } from '../utils/validation';

export const getVacationFormSchema = (db, ur, canPick, canManage) => {
  const empOptions = db.employees.map(e => ({ value: e.id, label: `${e.last} ${e.first}` }));
  return [
    canPick && {
      name: 'empId',
      label: 'Сотрудник *',
      type: 'select',
      required: true,
      rules: required('Выберите сотрудника'),
      props: { options: empOptions, disabled: !canManage },
    },
    {
      name: 'start',
      label: 'Дата начала *',
      type: 'date',
      required: true,
      rules: required('Укажите дату начала'),
      props: { disabled: false },
    },
    {
      name: 'end',
      label: 'Дата окончания *',
      type: 'date',
      required: true,
      rules: required('Укажите дату окончания'),
      props: { disabled: false },
    },
    {
      name: 'type',
      label: 'Тип отпуска *',
      type: 'select',
      required: true,
      rules: required('Выберите тип'),
      props: {
        options: Object.entries(VACATION_TYPES).map(([k, v]) => ({ value: k, label: v })),
      },
    },
    {
      name: 'comment',
      label: 'Комментарий',
      type: 'text',
      props: { placeholder: 'Дополнительная информация' },
    },
    canManage && {
      name: 'status',
      label: 'Статус',
      type: 'select',
      required: true,
      rules: required('Укажите статус'),
      props: {
        options: [
          { value: 'pending', label: 'На утверждении' },
          { value: 'approved', label: 'Утверждён' },
          { value: 'rejected', label: 'Отклонён' },
        ],
      },
    },
    {
      name: 'delegation_enabled',
      label: 'Делегировать задачи',
      type: 'checkbox',
      // обрабатывается как кастомное поле в форме
    },
  ].filter(Boolean);
};