// services/VacationService.js
import { EntityService } from './EntityService';
import { TODAY, uid, fmtDMY } from '../utils/date';

export class VacationService extends EntityService {
  getVacation(id) {
    return this.data.vacations.find(v => v.id === id);
  }

  createVacation(vacationData) {
    const newVac = {
      ...vacationData,
      id: vacationData.id || `v_${uid()}`,
    };
    this.store.upsertVacation(newVac);
    this.audit('Создание отпуска', `${this.empName(newVac.empId)} ${fmtDMY(newVac.start)}—${fmtDMY(newVac.end)}`);
    if (newVac.delegation.enabled && newVac.status === 'approved' && newVac.start <= TODAY) {
      this.applyDelegation(newVac.id);
    }
    return newVac;
  }

  updateVacation(vacationId, updates) {
    const oldVac = this.getVacation(vacationId);
    if (!oldVac) throw new Error('Отпуск не найден');
    const merged = { ...oldVac, ...updates };
    this.store.upsertVacation(merged);
    this.audit('Изменение отпуска', `${this.empName(merged.empId)} ${fmtDMY(merged.start)}—${fmtDMY(merged.end)}`);
    if (oldVac.delegation.enabled !== merged.delegation.enabled || oldVac.status !== merged.status) {
      if (merged.delegation.enabled && merged.status === 'approved' && merged.start <= TODAY) {
        this.applyDelegation(merged.id);
      } else {
        this.revertDelegation(merged.id);
      }
    }
    return merged;
  }

  deleteVacation(id) {
    const vac = this.getVacation(id);
    if (!vac) return;
    this.store.deleteVacation(id);
    this.audit('Удаление отпуска', `${this.empName(vac.empId)} ${fmtDMY(vac.start)}—${fmtDMY(vac.end)}`);
    if (vac.delegation.enabled) {
      this.revertDelegation(id);
    }
  }

  applyDelegation(vacationId) {
    const vac = this.getVacation(vacationId);
    if (!vac || !vac.delegation.enabled || vac.status !== 'approved') return;
    const { empId, start, end, delegation } = vac;
    const fromId = empId;
    const toId = delegation.subId;
    const statuses = delegation.statuses.length ? delegation.statuses : ['new', 'inwork', 'review'];

    this.data.tasks.forEach(t => {
      if (t.archived) return;
      if (!t.assigneeIds.includes(fromId)) return;
      if (!statuses.includes(t.status)) return;
      if (t.deadline && t.deadline < start) return;
      const newAssignees = t.assigneeIds.filter(id => id !== fromId);
      if (!newAssignees.includes(toId)) newAssignees.push(toId);
      const updated = { ...t, assigneeIds: newAssignees };
      updated.history = [
        ...updated.history,
        { ts: Date.now(), who: 'system', text: `Задача переназначена с ${this.empName(fromId)} на ${this.empName(toId)} на период отпуска с ${fmtDMY(start)} по ${fmtDMY(end)}` }
      ];
      this.store.upsertTask(updated);
    });

    this.notify(toId, `Вам переданы задачи ${this.empName(fromId)} на время отпуска`, { targetType: 'vacation', targetId: vacationId });
    this.notify(fromId, `Ваши задачи переданы ${this.empName(toId)} на период отпуска`, { targetType: 'vacation', targetId: vacationId });
  }

  revertDelegation(vacationId) {
    const vac = this.getVacation(vacationId);
    if (!vac || !vac.delegation.enabled) return;
    const fromId = vac.empId;
    const toId = vac.delegation.subId;
    this.data.tasks.forEach(t => {
      if (t.archived) return;
      if (!t.assigneeIds.includes(toId)) return;
      const hasDelegation = t.history.some(h => h.text.includes(`переназначена с ${this.empName(fromId)} на ${this.empName(toId)}`));
      if (!hasDelegation) return;
      const newAssignees = t.assigneeIds.filter(id => id !== toId);
      if (!newAssignees.includes(fromId)) newAssignees.push(fromId);
      const updated = { ...t, assigneeIds: newAssignees };
      updated.history = [
        ...updated.history,
        { ts: Date.now(), who: 'system', text: `Задача возвращена ${this.empName(fromId)} по окончании отпуска` }
      ];
      this.store.upsertTask(updated);
    });
    this.notify(fromId, `Задачи возвращены вам по окончании отпуска`, { targetType: 'vacation', targetId: vacationId });
  }
}