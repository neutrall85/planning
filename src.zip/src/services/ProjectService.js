// services/ProjectService.js
import { EntityService } from './EntityService';
import { PROJECT_STATUSES } from '../utils/constants';
import { TODAY, uid } from '../utils/date';

export class ProjectService extends EntityService {
  getProject(id) {
    return this.data.projects.find(p => p.id === id);
  }

  createProject(projectData) {
    const newProject = {
      ...projectData,
      id: projectData.id || `p_${uid()}`,
      history: [
        ...(projectData.history || []),
        { ts: Date.now(), who: this.user.id, text: 'Проект создан' }
      ],
      creatorId: this.user.id,
      archived: false,
      archivedAt: null,
      closedAt: null,
    };
    this.store.upsertProject(newProject);
    this.audit(
      'Создание проекта',
      {
        name: newProject.name,
        code: newProject.code,
        budget: newProject.budget,
        status: newProject.status,
        manager: newProject.managerId ? this.empName(newProject.managerId) : '—',
        customer: newProject.customer || '—',
        aircraftType: newProject.aircraftType || '—',
        projectType: newProject.projectType || '—',
      },
      'project',
      newProject.id
    );
    return newProject;
  }

  updateProject(projectId, updates) {
    const oldProject = this.getProject(projectId);
    if (!oldProject) throw new Error('Проект не найден');

    const merged = { ...oldProject, ...updates };
    const changes = [];

    if (oldProject.name !== merged.name) changes.push(`Название: "${oldProject.name}" → "${merged.name}"`);
    if (oldProject.code !== merged.code) changes.push(`Код: "${oldProject.code}" → "${merged.code}"`);
    if (oldProject.budget !== merged.budget) changes.push(`Бюджет: ${oldProject.budget ?? '—'} → ${merged.budget ?? '—'}`);
    if (oldProject.status !== merged.status) {
      changes.push(`Статус: ${PROJECT_STATUSES[oldProject.status]?.label || oldProject.status} → ${PROJECT_STATUSES[merged.status]?.label || merged.status}`);
      if ((merged.status === 'closed' || merged.status === 'cancelled') && oldProject.status !== merged.status) {
        merged.archived = true;
        merged.archivedAt = TODAY;
        merged.closedAt = TODAY;
        // Архивируем все задачи
        this.data.tasks.forEach(t => {
          if (t.projectId === projectId && !t.archived) {
            const updatedTask = { ...t, archived: true, archivedAt: TODAY };
            if (merged.status === 'closed') updatedTask.status = 'closed';
            else updatedTask.status = 'cancelled';
            this.store.upsertTask(updatedTask);
            if (t.creatorId) {
              this.notify(t.creatorId, `Задача "${t.title}" проекта ${merged.code} архивирована (проект ${merged.status})`, { targetType: 'task', targetId: t.id });
            }
          }
        });
        if (merged.managerId) {
          this.notify(merged.managerId, `Проект "${merged.name}" архивирован`, { targetType: 'project', targetId: projectId });
        }
      }
    }

    this.store.upsertProject(merged);
    if (changes.length) {
      this.audit('Изменение проекта', changes.join('; '), 'project', projectId);
    }
    return merged;
  }

  deleteProject(projectId) {
    const project = this.getProject(projectId);
    if (!project) return;
    this.store.deleteProject(projectId);
    this.audit('Удаление проекта', project.name);
  }

  restoreProject(projectId) {
    const project = this.getProject(projectId);
    if (!project || !project.archived) return;
    const restored = { ...project, archived: false, archivedAt: null };
    this.store.upsertProject(restored);
    this.audit('Восстановление проекта', project.name, 'project', projectId);
    return restored;
  }

  closeProject(projectId) {
    return this.updateProject(projectId, { status: 'closed' });
  }

  cancelProject(projectId) {
    return this.updateProject(projectId, { status: 'cancelled' });
  }
}