// services/TaskService.js
import { EntityService } from './EntityService';
import { TASK_STATUSES } from '../utils/constants';
import { TODAY, uid } from '../utils/date';
import { checkProjectBudget } from '../utils/budget';
import { generateRepeatDates } from '../utils/repeatDates'; // ← изменён импорт

export class TaskService extends EntityService {
  getTask(id) {
    return this.data.tasks.find(t => t.id === id);
  }

  createTask(taskData) {
    const project = this.data.projects.find(p => p.id === taskData.projectId);
    checkProjectBudget(project, this.data.tasks, taskData);

    const newTask = {
      ...taskData,
      id: taskData.id || `t_${uid()}`,
      createdAt: new Date().toISOString(),
      history: [
        ...(taskData.history || []),
        { ts: Date.now(), who: this.user.id, text: 'Задача создана' }
      ],
      creatorId: this.user.id,
    };

    this.store.upsertTask(newTask);

    this.audit(
      'Создание задачи',
      {
        title: newTask.title,
        project: this.data.projects.find(p => p.id === newTask.projectId)?.code || '—',
        plannedHours: newTask.plannedHours,
        assignees: (newTask.assigneeIds || []).map(id => this.empName(id)).join(', '),
        priority: newTask.priority,
        deadline: newTask.deadline || '—',
      },
      'task',
      newTask.id
    );

    (newTask.assigneeIds || []).forEach(id => {
      if (id !== this.user.id) {
        this.notify(id, `Вам назначена задача "${newTask.title}"`, { targetType: 'task', targetId: newTask.id });
      }
    });

    return newTask;
  }

  updateTask(taskId, updates) {
    const oldTask = this.getTask(taskId);
    if (!oldTask) throw new Error('Задача не найдена');

    const mergedTask = { ...oldTask, ...updates };
    const project = this.data.projects.find(p => p.id === mergedTask.projectId);
    checkProjectBudget(project, this.data.tasks, mergedTask);

    const changes = [];
    if (oldTask.title !== mergedTask.title) changes.push(`Название: "${oldTask.title}" → "${mergedTask.title}"`);
    if (oldTask.plannedHours !== mergedTask.plannedHours) changes.push(`Плановые часы: ${oldTask.plannedHours ?? '—'} → ${mergedTask.plannedHours ?? '—'}`);
    if (JSON.stringify(oldTask.assigneeIds) !== JSON.stringify(mergedTask.assigneeIds)) {
      changes.push(`Исполнители: ${oldTask.assigneeIds.map(id => this.empName(id)).join(', ')} → ${mergedTask.assigneeIds.map(id => this.empName(id)).join(', ')}`);
    }
    if (oldTask.status !== mergedTask.status) {
      changes.push(`Статус: ${TASK_STATUSES[oldTask.status].label} → ${TASK_STATUSES[mergedTask.status].label}`);
      mergedTask.history = [
        ...mergedTask.history,
        { ts: Date.now(), who: this.user.id, text: `Статус изменён на ${TASK_STATUSES[mergedTask.status].label}` }
      ];
      if ((mergedTask.status === 'closed' || mergedTask.status === 'cancelled') && oldTask.status !== mergedTask.status) {
        mergedTask.closedAt = TODAY;
        mergedTask.archived = true;
        mergedTask.archivedAt = TODAY;
        const creatorId = mergedTask.creatorId || oldTask.creatorId;
        if (creatorId && creatorId !== this.user.id) {
          this.notify(creatorId, `Задача "${mergedTask.title}" ${mergedTask.status === 'closed' ? 'закрыта' : 'отменена'}`, { targetType: 'task', targetId: taskId });
        }
        const proj = this.data.projects.find(p => p.id === mergedTask.projectId);
        if (proj?.managerId && proj.managerId !== creatorId && proj.managerId !== this.user.id) {
          this.notify(proj.managerId, `Задача "${mergedTask.title}" проекта ${proj.code} ${mergedTask.status === 'closed' ? 'закрыта' : 'отменена'}`, { targetType: 'task', targetId: taskId });
        }
      }
    }

    if (mergedTask.dependencyId) {
      const depTask = this.data.tasks.find(t => t.id === mergedTask.dependencyId);
      if (depTask) {
        const dates = this._recalculateDates(mergedTask, depTask);
        mergedTask.start = dates.start;
        mergedTask.deadline = dates.deadline;
      }
    }

    this.store.upsertTask(mergedTask);

    if (changes.length) {
      this.audit('Изменение задачи', changes.join('; '), 'task', taskId);
    }

    return mergedTask;
  }

  deleteTask(taskId) {
    const task = this.getTask(taskId);
    if (!task) return;
    this.store.deleteTask(taskId);
    this.audit('Удаление задачи', task.title);
  }

  _recalculateDates(task, depTask) {
    const { addDays, parseISO, iso } = require('../utils/date');
    let start = task.start;
    let deadline = task.deadline;
    switch (task.dependencyType || 'FS') {
      case 'SS':
        start = depTask.start;
        if (task.deadline && depTask.start) {
          const diff = Math.round((new Date(task.deadline) - new Date(task.start || new Date())) / (1000 * 60 * 60 * 24));
          deadline = iso(addDays(parseISO(depTask.start), diff));
        }
        break;
      case 'FF':
        if (depTask.deadline) {
          deadline = depTask.deadline;
          if (task.start && task.deadline) {
            const duration = Math.round((new Date(task.deadline) - new Date(task.start)) / (1000 * 60 * 60 * 24));
            start = iso(addDays(parseISO(depTask.deadline), -duration));
          }
        }
        break;
      case 'SF':
        if (depTask.start) {
          deadline = depTask.start;
          if (task.start && task.deadline) {
            const duration = Math.round((new Date(task.deadline) - new Date(task.start)) / (1000 * 60 * 60 * 24));
            start = iso(addDays(parseISO(depTask.start), -duration));
          }
        }
        break;
      default: // FS
        if (depTask.deadline) {
          start = depTask.deadline;
          if (task.deadline) {
            const diff = Math.round((new Date(task.deadline) - new Date(task.start || new Date())) / (1000 * 60 * 60 * 24));
            deadline = iso(addDays(parseISO(depTask.deadline), diff));
          }
        }
        break;
    }
    return { start, deadline };
  }

  createRepeatingTasks(taskData, repeatConfig, maxCount = 50) {
    const dates = generateRepeatDates(taskData.start, taskData.deadline, repeatConfig, taskData.repeatEndValue, maxCount);
    const results = [];
    dates.forEach((d, index) => {
      const copy = { ...taskData, start: d.start, deadline: d.deadline };
      if (index === 0) {
        if (taskData.id) {
          results.push(this.updateTask(taskData.id, copy));
        } else {
          results.push(this.createTask(copy));
        }
      } else {
        const newTask = { ...copy, id: `t_${uid()}` };
        results.push(this.createTask(newTask));
      }
    });
    return results;
  }
}