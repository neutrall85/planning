// services/EntityService.js
export class EntityService {
  constructor(store, currentUser) {
    this.store = store;
    this.user = currentUser;
  }

  get data() {
    return this.store.data;
  }

  empName(id) {
    const e = this.data.employees.find(x => x.id === id);
    return e ? `${e.last} ${e.first}` : '—';
  }

  audit(action, details, targetType = null, targetId = null) {
    this.store.addAudit(action, details, targetType, targetId);
  }

  notify(userId, text, target = null) {
    this.store.addNotification(userId, text, target);
  }
}