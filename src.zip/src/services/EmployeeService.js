// services/EmployeeService.js
import { EntityService } from './EntityService';
import { uid } from '../utils/date';

export class EmployeeService extends EntityService {
  getEmployee(id) {
    return this.data.employees.find(e => e.id === id);
  }

  createEmployee(employeeData) {
    const newEmp = {
      ...employeeData,
      id: employeeData.id || `e_${uid()}`,
      failed: 0,
      lockUntil: 0,
      fired: false,
      passwordHistory: [],
      photo: null,
    };
    this.store.upsertEmployee(newEmp);
    this.audit('Создание сотрудника', `${newEmp.last} ${newEmp.first}`);
    return newEmp;
  }

  updateEmployee(employeeId, updates) {
    const oldEmp = this.getEmployee(employeeId);
    if (!oldEmp) throw new Error('Сотрудник не найден');
    const merged = { ...oldEmp, ...updates };
    if (updates.pass && updates.pass.length >= 8) {
      const history = oldEmp.passwordHistory || [];
      if (history.some(p => p === updates.pass)) {
        throw new Error('Этот пароль уже использовался ранее');
      }
      merged.passwordHistory = [...history.slice(-4), updates.pass];
    }
    this.store.upsertEmployee(merged);
    if (JSON.stringify(oldEmp.departments) !== JSON.stringify(merged.departments)) {
      this.audit('Изменение подразделений', `${merged.last} ${merged.first}`);
    }
    if (JSON.stringify(oldEmp.roles) !== JSON.stringify(merged.roles)) {
      this.audit('Изменение ролей', `${merged.last} ${merged.first}: ${oldEmp.roles.join(', ')} → ${merged.roles.join(', ')}`);
    }
    return merged;
  }

  fireEmployee(employeeId) {
    const emp = this.getEmployee(employeeId);
    if (!emp) return;
    const updated = { ...emp, fired: true };
    this.store.upsertEmployee(updated);
    this.audit('Увольнение сотрудника', `${emp.last} ${emp.first}`);
    return updated;
  }

  restoreEmployee(employeeId) {
    const emp = this.getEmployee(employeeId);
    if (!emp) return;
    const updated = { ...emp, fired: false };
    this.store.upsertEmployee(updated);
    this.audit('Восстановление сотрудника', `${emp.last} ${emp.first}`);
    return updated;
  }
}