import { TODAY } from '../utils/date';

export function useProjectActions(store, data, user, showConfirm, showToast) {
  const closeProject = (project) => {
    showConfirm(`Закрыть проект "${project.name}"? Все задачи проекта будут закрыты.`, () => {
      const updated = { ...project, status: 'closed', archived: true, archivedAt: TODAY, closedAt: TODAY };
      store.upsertProject(updated);
      data.tasks.filter(t => t.projectId === project.id && !t.archived).forEach(t => {
        store.upsertTask({ ...t, status: 'closed', archived: true, archivedAt: TODAY, closedAt: TODAY });
      });
      store.addAudit('Закрытие проекта', project.name, 'project', project.id);
      showToast(`Проект "${project.name}" закрыт`);
    });
  };

  const cancelProject = (project) => {
    showConfirm(`Отменить проект "${project.name}"? Все задачи проекта будут отменены.`, () => {
      const updated = { ...project, status: 'cancelled', archived: true, archivedAt: TODAY };
      store.upsertProject(updated);
      data.tasks.filter(t => t.projectId === project.id && !t.archived).forEach(t => {
        store.upsertTask({ ...t, status: 'cancelled', archived: true, archivedAt: TODAY });
      });
      store.addAudit('Отмена проекта', project.name, 'project', project.id);
      showToast(`Проект "${project.name}" отменён`);
    });
  };

  const restoreProject = (projectId) => {
    const project = data.projects.find(p => p.id === projectId);
    if (!project) return;
    showConfirm(`Восстановить проект "${project.name}"?`, () => {
      const updated = { ...project, archived: false, archivedAt: null };
      store.upsertProject(updated);
      store.addAudit('Восстановление проекта', project.name, 'project', projectId);
      showToast(`Проект "${project.name}" восстановлен`);
    });
  };

  const moveProject = (id, newStatus) => {
    const project = data.projects.find(p => p.id === id);
    if (project && project.status !== newStatus) {
      store.upsertProject({ ...project, status: newStatus });
      showToast(`Статус проекта "${project.name}" изменён на ${newStatus}`);
    }
  };

  return { closeProject, cancelProject, restoreProject, moveProject };
}