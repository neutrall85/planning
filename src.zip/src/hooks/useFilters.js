// hooks/useFilters.js
import { useState } from 'react';

export function useFilters(initial = {}) {
  const [filters, setFilters] = useState(initial);
  
  const setFilter = (key, value) => setFilters(prev => ({ ...prev, [key]: value }));
  const resetFilters = () => setFilters(initial);
  
  return { filters, setFilter, resetFilters };
}