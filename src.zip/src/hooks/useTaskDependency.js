import { addDays, parseISO, iso } from '../utils/date';

export function useTaskDependency() {
  const getDependencyDates = (task, depTask) => {
    if (!depTask) return { start: task.start, deadline: task.deadline };

    let finalStart = task.start;
    let finalDeadline = task.deadline;

    switch (task.dependencyType) {
      case 'SS':
        finalStart = depTask.start;
        if (task.deadline && depTask.start) {
          const diffDays = Math.round((new Date(task.deadline) - new Date(task.start || TODAY)) / (1000 * 60 * 60 * 24));
          finalDeadline = iso(addDays(parseISO(depTask.start), diffDays));
        }
        break;
      case 'FF':
        if (depTask.deadline) {
          finalDeadline = depTask.deadline;
          if (task.start && task.deadline) {
            const duration = Math.round((new Date(task.deadline) - new Date(task.start)) / (1000 * 60 * 60 * 24));
            finalStart = iso(addDays(parseISO(depTask.deadline), -duration));
          }
        }
        break;
      case 'SF':
        if (depTask.start) {
          finalDeadline = depTask.start;
          if (task.start && task.deadline) {
            const duration = Math.round((new Date(task.deadline) - new Date(task.start)) / (1000 * 60 * 60 * 24));
            finalStart = iso(addDays(parseISO(depTask.start), -duration));
          }
        }
        break;
      case 'FS':
      default:
        if (depTask.deadline) {
          finalStart = depTask.deadline;
          if (task.deadline) {
            const diffDays = Math.round((new Date(task.deadline) - new Date(task.start || TODAY)) / (1000 * 60 * 60 * 24));
            finalDeadline = iso(addDays(parseISO(depTask.deadline), diffDays));
          }
        }
        break;
    }
    return { start: finalStart, deadline: finalDeadline };
  };

  return { getDependencyDates };
}