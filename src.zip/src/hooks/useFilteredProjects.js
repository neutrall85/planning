// hooks/useFilteredProjects.js
import { useMemo } from 'react';
import { computeScope } from '../utils/permissions';

export function useFilteredProjects(db, ur, filters = {}) {
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);
  return useMemo(() => {
    let list = scope.all ? db.projects : db.projects.filter(p => scope.projIds.has(p.id));
    const { search, aircraftType, projectType, stage, customer, status, showOnlyMy } = filters;
    if (search && search.trim()) {
      const s = search.trim().toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(s) || p.code.toLowerCase().includes(s) || (p.customer && p.customer.toLowerCase().includes(s)));
    }
    if (aircraftType && aircraftType !== 'all') list = list.filter(p => p.aircraftType === aircraftType);
    if (projectType && projectType !== 'all') list = list.filter(p => p.projectType === projectType);
    if (stage && stage !== 'all') list = list.filter(p => p.stage === stage);
    if (customer && customer !== 'all') list = list.filter(p => p.customer === customer);
    if (status && status !== 'all') list = list.filter(p => p.status === status);
    if (showOnlyMy) {
      const myTaskIds = db.tasks.filter(t => (t.assigneeIds || []).includes(ur.id) && !t.archived).map(t => t.projectId);
      list = list.filter(p => myTaskIds.includes(p.id));
    }
    return list;
  }, [db, ur, scope, filters]);
}