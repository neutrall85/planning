// hooks/useFilteredTasks.js
import { useMemo } from 'react';
import { computeScope, taskVisible } from '../utils/permissions';
import { isTaskActive } from '../utils/date';

export function useFilteredTasks(db, ur, filters = {}) {
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);
  return useMemo(() => {
    let list = db.tasks.filter(t => isTaskActive(t) && taskVisible(ur, scope, t, db));
    const { search, projectId, assigneeId, priority, deptId, showOnlyMy } = filters;
    if (projectId && projectId !== 'all') list = list.filter(t => t.projectId === projectId);
    if (assigneeId && assigneeId !== 'all') list = list.filter(t => (t.assigneeIds || []).includes(assigneeId));
    if (priority && priority !== 'all') list = list.filter(t => t.priority === priority);
    if (deptId && deptId !== 'all') {
      list = list.filter(t => (t.assigneeIds || []).some(id => {
        const emp = db.employees.find(e => e.id === id);
        return emp?.departments.some(d => d.deptId === deptId);
      }));
    }
    if (search && search.trim()) {
      const s = search.trim().toLowerCase();
      list = list.filter(t => t.title.toLowerCase().includes(s) ||
        db.projects.find(p => p.id === t.projectId)?.name?.toLowerCase().includes(s));
    }
    if (showOnlyMy) list = list.filter(t => (t.assigneeIds || []).includes(ur.id));
    return list;
  }, [db, ur, scope, filters]);
}