// hooks/useProjectStats.js
import { useMemo } from 'react';

export function useProjectStats(project, db) {
  return useMemo(() => {
    if (!project || !db) {
      return { tasks: [], plan: 0, fact: 0, usePct: 0, uniqueAssignees: [], manager: null };
    }
    const tasks = (db.tasks || []).filter(t => t.projectId === project.id && !t.archived);
    const plan = tasks.reduce((s, t) => s + (t.plannedHours || 0), 0);
    const fact = tasks.reduce((s, t) => s + (t.logs || []).reduce((lsum, l) => lsum + l.hours, 0), 0);
    const usePct = project.budget ? Math.round((fact / Math.max(1, project.budget)) * 100) : 0;
    const uniqueAssignees = [...new Set(tasks.flatMap(t => t.assigneeIds || []))];
    const manager = project.managerId ? db.employees.find(e => e.id === project.managerId) : null;
    return { tasks, plan, fact, usePct, uniqueAssignees, manager };
  }, [project, db]);
}