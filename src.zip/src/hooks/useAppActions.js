import { useCallback } from 'react';
import { TODAY, fmtDMY } from '../utils/date';
import { TASK_STATUSES, PROJECT_STATUSES } from '../utils/constants';
import { hasRole, canChangeTaskStatus } from '../utils/permissions';

export function useAppActions({ store, data, user, setModal, setView, setRequestsTab, showToast }) {
  const empName = useCallback((id) => {
    const e = data.employees.find(x => x.id === id);
    return e ? `${e.last} ${e.first}` : '—';
  }, [data]);

  const openTask = useCallback((taskId = null, initialTab = 'form', projectId = null) => {
    setModal({ type: 'task', taskId, initialTab, projectId });
  }, [setModal]);

  const openProject = useCallback((projectId = null) => {
    setModal({ type: 'project', projectId });
  }, [setModal]);

  const openHoursReq = useCallback((kind, targetId) => {
    setModal({ type: 'hours', kind, targetId });
  }, [setModal]);

  const openRoles = useCallback((empId) => {
    setModal({ type: 'roles', empId });
  }, [setModal]);

  const openDepts = useCallback((empId) => {
    setModal({ type: 'depts', empId });
  }, [setModal]);

  const openVacation = useCallback((vacationId = null, forEmpId = null) => {
    setModal({ type: 'vacation', vacationId, forEmpId });
  }, [setModal]);

  const openDelegation = useCallback(() => {
    setModal({ type: 'delegation' });
  }, [setModal]);

  const handleMoveTask = useCallback((taskId, newStatus) => {
    const task = data.tasks.find(t => t.id === taskId);
    if (!task) return;
    if ((newStatus === 'closed' || newStatus === 'cancelled') && !canChangeTaskStatus(user, task, newStatus, data)) {
      showToast('У вас нет прав на закрытие или отмену этой задачи.', 'err');
      return;
    }
    const isClosing = (newStatus === 'closed' || newStatus === 'cancelled') && task.status !== newStatus;
    const updatedTask = {
      ...task,
      status: newStatus,
      closedAt: isClosing ? TODAY : task.closedAt,
      archived: isClosing ? true : task.archived,
      archivedAt: isClosing ? TODAY : task.archivedAt,
      history: [...task.history, { ts: Date.now(), who: user.id, text: `Статус → ${TASK_STATUSES[newStatus].label}` }]
    };
    store.upsertTask(updatedTask);
    store.addAudit('Изменение статуса задачи', {
      task: task.title,
      status: `${TASK_STATUSES[task.status].label} → ${TASK_STATUSES[newStatus].label}`
    }, 'task', task.id);
    showToast(`Статус задачи "${task.title}" изменён на ${TASK_STATUSES[newStatus].label}`);

    if (newStatus === 'review') {
      const project = data.projects.find(p => p.id === task.projectId);
      if (project && project.ptype !== 'admin') {
        const creatorId = task.creatorId || task.history?.find(h => h.who !== 'system')?.who || task.history[0]?.who;
        let managerId = project?.managerId;
        if (!managerId) {
          const pmCandidate = data.employees.find(e =>
            e.roles.includes('project_lead') &&
            data.tasks.some(t => t.projectId === task.projectId && (t.assigneeIds || []).includes(e.id))
          );
          if (pmCandidate) managerId = pmCandidate.id;
        }
        if (creatorId && creatorId !== user.id) {
          store.addNotification(creatorId, `Задача "${task.title}" переведена на проверку исполнителем ${user.last} ${user.first}.`, { targetType: 'task', targetId: task.id });
        }
        if (managerId && managerId !== user.id && managerId !== creatorId) {
          store.addNotification(managerId, `Задача "${task.title}" переведена на проверку исполнителем ${user.last} ${user.first}.`, { targetType: 'task', targetId: task.id });
        }
      }
    }
    if (isClosing) {
      const creatorId = task.creatorId;
      if (creatorId && creatorId !== user.id) {
        store.addNotification(creatorId, `Задача "${task.title}" ${newStatus === 'closed' ? 'закрыта' : 'отменена'} пользователем ${user.last} ${user.first}.`, { targetType: 'task', targetId: task.id });
      }
    }
  }, [data, user, store, showToast]);

  const handleNotificationNavigate = useCallback((notification) => {
    const { targetType, targetId } = notification;
    if (!targetType || !targetId) return;
    store.markNotificationRead(notification.id);
    switch (targetType) {
      case 'task': openTask(targetId, 'chat'); break;
      case 'project': openProject(targetId); break;
      case 'hours': setRequestsTab('hours'); setView('requests'); break;
      case 'vacation': openVacation(targetId); break;
      case 'delegation': setRequestsTab('rd'); setView('requests'); break;
      case 'registration': setRequestsTab('reg'); setView('requests'); break;
      default: break;
    }
  }, [store, openTask, openProject, openVacation, setRequestsTab, setView]);

  return {
    openTask,
    openProject,
    openHoursReq,
    openRoles,
    openDepts,
    openVacation,
    openDelegation,
    handleMoveTask,
    handleNotificationNavigate,
    empName,
  };
}