// hooks/useTaskRepeater.js
import { generateRepeatDates } from '../utils/repeatDates';

export function useTaskRepeater() {
  return { generateRepeatDates };
}