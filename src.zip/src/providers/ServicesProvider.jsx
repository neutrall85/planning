// providers/ServicesProvider.jsx
import React, { useMemo } from 'react';
import { ServicesContext } from '../context/ServicesContext';
import { TaskService } from '../services/TaskService';
import { ProjectService } from '../services/ProjectService';
import { VacationService } from '../services/VacationService';
import { EmployeeService } from '../services/EmployeeService';

export const ServicesProvider = ({ store, user, children }) => {
  const services = useMemo(() => ({
    task: new TaskService(store, user),
    project: new ProjectService(store, user),
    vacation: new VacationService(store, user),
    employee: new EmployeeService(store, user),
  }), [store, user]);

  return (
    <ServicesContext.Provider value={services}>
      {children}
    </ServicesContext.Provider>
  );
};