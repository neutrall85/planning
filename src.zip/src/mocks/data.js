// src/mocks/data.js
import { TODAY, iso, addDays, addMonths, uid } from '../utils/date';

const genId = () => uid();

export const demoEmployees = [
  { id: "sergey.adminov", last: "Админов", first: "Сергей", email: "sergey.adminov", pass: "Admin2026!", position: "Администратор системы", departments: [], roles: ["admin"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "101", tab: "1001", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "aleksey.gendirov", last: "Гендиров", first: "Алексей", email: "aleksey.gendirov", pass: "Director2026!", position: "Генеральный директор", departments: [], roles: ["director"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "102", tab: "1002", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "erik.ekonomistov", last: "Экономистов", first: "Эрик", email: "erik.ekonomistov", pass: "Econ2026!", position: "Главный экономист", departments: [], roles: ["economist"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "103", tab: "1003", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "ivan.konstruktorov", last: "Конструкторов", first: "Иван", email: "ivan.konstruktorov", pass: "KbLa2026!", position: "Главный конструктор КБ «ЛА»", departments: [], roles: ["kb_chief", "executor"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "104", tab: "1004", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "olga.personalova", last: "Персоналова", first: "Ольга", email: "olga.personalova", pass: "Hr2026!", position: "Руководитель отдела управления персоналом", departments: [], roles: ["hr", "head", "executor"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "106", tab: "1006", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "mikhail.otdelov", last: "Отделов", first: "Михаил", email: "mikhail.otdelov", pass: "Head2026!", position: "Начальник отдела аэродинамики", departments: [], roles: ["head", "executor", "project_lead"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "107", tab: "1007", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "nikolay.managerov", last: "Менеджеров", first: "Николай", email: "nikolay.managerov", pass: "Pm2026!", position: "Менеджер проектов", departments: [], roles: ["project_manager", "executor"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "117", tab: "1017", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "kirill.proektov", last: "Проектов", first: "Кирилл", email: "kirill.proektov", pass: "Pm2026!", position: "Ответственный по проекту", departments: [], roles: ["project_lead", "executor"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "116", tab: "1016", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null },
  { id: "isaev", last: "Исаев", first: "Роман", email: "isaev", pass: "Exec2026!", position: "Инженер-аэродинамик", departments: [], roles: ["executor"], kbIds: [], headDeptIds: [], phone: "+7 900 000-00-00", extension: "118", tab: "1018", notif: { deadlineEmail: true, overdueDigest: false, commentSub: true }, failed: 0, lockUntil: 0, fired: false, passwordHistory: [], photo: null }
];

const kbList = [
  { id: "kb_la", name: "КБ «ЛА»", full: "Конструкторское бюро летательных аппаратов" },
  { id: "kb_dv", name: "КБ «Двигатели»", full: "Конструкторское бюро двигателей" },
];

const deptList = [
  { id: "dept_aero", name: "Отдел аэродинамики", kbId: "kb_la" },
  { id: "dept_prochnost", name: "Отдел прочности", kbId: "kb_la" },
  { id: "dept_engine", name: "Отдел двигателестроения", kbId: "kb_dv" },
  { id: "dept_hr", name: "Отдел кадров", kbId: null },
  { id: "dept_econ", name: "Экономический отдел", kbId: null },
];

const employeeDepts = {
  "sergey.adminov": [],
  "aleksey.gendirov": [],
  "erik.ekonomistov": [{ deptId: "dept_econ", primary: true }],
  "ivan.konstruktorov": [{ deptId: "dept_aero", primary: true }],
  "olga.personalova": [{ deptId: "dept_hr", primary: true }],
  "mikhail.otdelov": [{ deptId: "dept_aero", primary: true }],
  "nikolay.managerov": [{ deptId: "dept_aero", primary: false }],
  "kirill.proektov": [{ deptId: "dept_prochnost", primary: true }],
  "isaev": [{ deptId: "dept_aero", primary: true }],
};

const colors = ["#0ea5e9", "#8b5cf6", "#f43f5e", "#f59e0b", "#10b981", "#ec4899"];

const projects = [
  {
    id: "p_1",
    code: "SU-57-1",
    name: "Модернизация Су-57",
    desc: "Установка нового БРЭО и двигателей",
    kbId: "kb_la",
    managerId: "ivan.konstruktorov",
    start: "2026-01-15",
    end: "2026-12-20",
    status: "active",
    budget: 1200,
    color: colors[0],
    ptype: "prod",
    longterm: false,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "sergey.adminov",
    customer: "Министерство обороны",
    aircraftType: "Су-57",
    projectType: "Модификация",
    stage: "Рабочая документация",
    comments: [],
    history: [{ ts: Date.now() - 10000000, who: "sergey.adminov", text: "Проект создан" }],
    files: [],
  },
  {
    id: "p_2",
    code: "MIG-35-2",
    name: "МиГ-35: улучшение аэродинамики",
    desc: "Переработка крыла и оперения",
    kbId: "kb_la",
    managerId: "kirill.proektov",
    start: "2026-03-01",
    end: "2026-09-30",
    status: "active",
    budget: 800,
    color: colors[1],
    ptype: "prod",
    longterm: false,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "aleksey.gendirov",
    customer: "ВКС РФ",
    aircraftType: "МиГ-35",
    projectType: "Ремонт",
    stage: "Эскизный проект",
    comments: [],
    history: [{ ts: Date.now() - 8000000, who: "aleksey.gendirov", text: "Проект создан" }],
    files: [],
  },
  {
    id: "p_3",
    code: "IL-76-3",
    name: "Модернизация Ил-76",
    desc: "Замена двигателей и авионики",
    kbId: "kb_dv",
    managerId: "mikhail.otdelov",
    start: "2025-11-01",
    end: "2026-08-15",
    status: "active",
    budget: 1500,
    color: colors[2],
    ptype: "prod",
    longterm: false,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "sergey.adminov",
    customer: "МЧС",
    aircraftType: "Ил-76",
    projectType: "Модификация",
    stage: "Изготовление",
    comments: [],
    history: [{ ts: Date.now() - 12000000, who: "sergey.adminov", text: "Проект создан" }],
    files: [],
  },
  {
    id: "p_4",
    code: "KA-52-4",
    name: "Улучшение Ка-52",
    desc: "Установка новой системы наведения",
    kbId: "kb_la",
    managerId: "nikolay.managerov",
    start: "2026-02-10",
    end: "2026-07-30",
    status: "inactive",
    budget: 600,
    color: colors[3],
    ptype: "prod",
    longterm: false,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "aleksey.gendirov",
    customer: "Армия РФ",
    aircraftType: "Ка-52",
    projectType: "Ремонт",
    stage: "Эскизный проект",
    comments: [],
    history: [{ ts: Date.now() - 9000000, who: "aleksey.gendirov", text: "Проект создан" }],
    files: [],
  },
  {
    id: "p_5",
    code: "ADMIN-1",
    name: "Разработка регламента",
    desc: "Создание документации по стандартам",
    kbId: null,
    managerId: "olga.personalova",
    start: "2026-01-01",
    end: null,
    status: "active",
    budget: null,
    color: colors[4],
    ptype: "admin",
    longterm: true,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "sergey.adminov",
    customer: null,
    aircraftType: null,
    projectType: null,
    stage: null,
    comments: [],
    history: [{ ts: Date.now() - 15000000, who: "sergey.adminov", text: "Проект создан" }],
    files: [],
  },
  {
    id: "p_6",
    code: "CLOSED-1",
    name: "Закрытый проект (архив)",
    desc: "Тестовый проект, завершённый",
    kbId: "kb_la",
    managerId: "ivan.konstruktorov",
    start: "2025-01-01",
    end: "2025-12-31",
    status: "closed",
    budget: 300,
    color: colors[5],
    ptype: "prod",
    longterm: false,
    archived: true,
    archivedAt: "2026-01-10",
    closedAt: "2025-12-31",
    creatorId: "sergey.adminov",
    customer: "Тестовый",
    aircraftType: "Су-57",
    projectType: "Модификация",
    stage: "Сдача",
    comments: [],
    history: [{ ts: Date.now() - 20000000, who: "sergey.adminov", text: "Проект создан" }],
    files: [],
  },
];

const taskTitles = [
  "Разработка чертежей крыла",
  "Расчёт аэродинамики",
  "Изготовление прототипа",
  "Испытания на стенде",
  "Подготовка документации",
  "Закупка материалов",
  "Монтаж оборудования",
  "Настройка ПО",
  "Проведение лётных испытаний",
  "Согласование с заказчиком",
  "Обучение персонала",
  "Проверка качества",
  "Корректировка конструкторской документации",
  "Модернизация двигателя",
  "Разработка системы управления",
  "Интеграция БРЭО",
  "Проверка герметичности",
  "Сборка финальной версии",
  "Подготовка отчёта",
  "Заключительная проверка",
];

const taskStatuses = ["new", "inwork", "review", "closed", "cancelled"];
const priorities = ["low", "mid", "high", "crit"];

const tasks = [];
let taskIdCounter = 1;

projects.forEach((proj, idx) => {
  const numTasks = Math.floor(Math.random() * 4) + 3;
  const assignableEmployees = proj.managerId ? [proj.managerId] : [];
  demoEmployees.forEach(e => {
    if (e.roles.includes("executor") || e.roles.includes("project_lead")) {
      assignableEmployees.push(e.id);
    }
  });
  const uniqueAssignees = [...new Set(assignableEmployees)];

  const projStart = new Date(proj.start);
  const projEnd = proj.end ? new Date(proj.end) : new Date(proj.start);
  const totalDays = Math.max(1, Math.round((projEnd - projStart) / (1000*60*60*24)));

  for (let i = 0; i < numTasks; i++) {
    const offset = Math.floor(Math.random() * totalDays);
    const startDate = new Date(projStart);
    startDate.setDate(startDate.getDate() + offset);
    const durDays = Math.floor(Math.random() * 30) + 10;
    const deadlineDate = new Date(startDate);
    deadlineDate.setDate(deadlineDate.getDate() + durDays);
    if (proj.end && deadlineDate > projEnd) {
      deadlineDate.setTime(projEnd.getTime());
    }
    const startIso = iso(startDate);
    const deadlineIso = iso(deadlineDate);
    const statuses = ['new', 'inwork', 'review'];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const assigneeCount = Math.min(Math.floor(Math.random() * 3) + 1, uniqueAssignees.length);
    const shuffled = [...uniqueAssignees].sort(() => Math.random() - 0.5);
    const assigneeIds = shuffled.slice(0, assigneeCount);
    if (i % 2 === 0 && !assigneeIds.includes('isaev')) {
      assigneeIds.push('isaev');
    }
    if (i === 0 && !assigneeIds.includes('isaev')) {
      assigneeIds.push('isaev');
    }

    const task = {
      id: "t_" + (taskIdCounter++),
      title: taskTitles[Math.floor(Math.random() * taskTitles.length)] + (Math.random() > 0.5 ? ` (${proj.code})` : ""),
      desc: `Описание задачи по проекту ${proj.name}`,
      projectId: proj.id,
      assigneeIds: assigneeIds,
      priority: priorities[Math.floor(Math.random() * priorities.length)],
      plannedHours: Math.floor(Math.random() * 40) + 10,
      start: startIso,
      deadline: deadlineIso,
      status: status,
      logs: [],
      comments: [],
      history: [],
      delegatedFrom: null,
      archived: false,
      archivedAt: null,
      closedAt: null,
      creatorId: proj.creatorId,
      dependencyId: null,
      dependencyType: "FS",
    };
    const logCount = Math.floor(Math.random() * 3);
    for (let l = 0; l < logCount; l++) {
      const logDate = iso(addDays(new Date(task.start), Math.floor(Math.random() * 20) + 1));
      if (logDate <= task.deadline) {
        task.logs.push({
          id: genId(),
          userId: task.assigneeIds[Math.floor(Math.random() * task.assigneeIds.length)],
          date: logDate,
          hours: Math.floor(Math.random() * 8) + 1,
          note: "Работа над задачей",
        });
      }
    }
    task.history.push({ ts: Date.now() - 1000000 * (Math.random() * 10), who: task.creatorId, text: "Задача создана" });
    tasks.push(task);
  }
});

// Добавляем гарантированные задачи в августе 2026 для исполнителя isaev
const augustTasks = [
  {
    id: "t_aug_1",
    title: "Разработка чертежей крыла (август)",
    desc: "Актуальная задача на август",
    projectId: "p_1",
    assigneeIds: ["isaev", "mikhail.otdelov"],
    priority: "high",
    plannedHours: 24,
    start: "2026-08-01",
    deadline: "2026-08-20",
    status: "inwork",
    logs: [{ id: genId(), userId: "isaev", date: "2026-08-03", hours: 4, note: "Начало работы" }],
    comments: [],
    history: [{ ts: Date.now(), who: "isaev", text: "Задача создана" }],
    delegatedFrom: null,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "isaev",
    dependencyId: null,
    dependencyType: "FS",
  },
  {
    id: "t_aug_2",
    title: "Расчёт аэродинамики (август)",
    desc: "Актуальная задача на август",
    projectId: "p_2",
    assigneeIds: ["isaev", "nikolay.managerov"],
    priority: "mid",
    plannedHours: 16,
    start: "2026-08-05",
    deadline: "2026-08-25",
    status: "new",
    logs: [],
    comments: [],
    history: [{ ts: Date.now(), who: "isaev", text: "Задача создана" }],
    delegatedFrom: null,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "isaev",
    dependencyId: null,
    dependencyType: "FS",
  },
  {
    id: "t_aug_3",
    title: "Испытания на стенде (август)",
    desc: "Актуальная задача на август",
    projectId: "p_3",
    assigneeIds: ["isaev"],
    priority: "crit",
    plannedHours: 40,
    start: "2026-08-10",
    deadline: "2026-08-30",
    status: "review",
    logs: [{ id: genId(), userId: "isaev", date: "2026-08-12", hours: 6, note: "Подготовка" }],
    comments: [],
    history: [{ ts: Date.now(), who: "isaev", text: "Задача создана" }],
    delegatedFrom: null,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: "isaev",
    dependencyId: null,
    dependencyType: "FS",
  }
];
tasks.push(...augustTasks);

const vacations = [];
const vacationTypes = ["annual", "admin", "sick", "other"];
demoEmployees.forEach((emp, idx) => {
  if (Math.random() > 0.3) {
    const start = iso(addDays(new Date(), Math.floor(Math.random() * 30) - 15));
    const end = iso(addDays(new Date(start), Math.floor(Math.random() * 10) + 3));
    const statuses = ["pending", "approved", "rejected"];
    const status = statuses[Math.floor(Math.random() * 3)];
    vacations.push({
      id: "v_" + (idx + 1),
      empId: emp.id,
      start: start,
      end: end,
      type: vacationTypes[Math.floor(Math.random() * vacationTypes.length)],
      comment: "Отпуск",
      status: status,
      delegation: {
        enabled: Math.random() > 0.5,
        subId: demoEmployees[Math.floor(Math.random() * demoEmployees.length)].id,
        statuses: ["new", "inwork", "review"],
        state: null,
      },
    });
  }
});

const hoursRequests = [];
for (let i = 0; i < 5; i++) {
  const task = tasks[Math.floor(Math.random() * tasks.length)];
  if (!task) continue;
  hoursRequests.push({
    id: "hr_" + i,
    kind: "task",
    targetId: task.id,
    oldH: task.plannedHours,
    newH: task.plannedHours + Math.floor(Math.random() * 20) + 5,
    reason: "Необходимо увеличить объём работ",
    reqId: demoEmployees[Math.floor(Math.random() * demoEmployees.length)].id,
    status: ["pending", "approved", "rejected"][Math.floor(Math.random() * 3)],
    ts: Date.now(),
  });
}

const roleDelegations = [];
for (let i = 0; i < 3; i++) {
  const from = demoEmployees[Math.floor(Math.random() * demoEmployees.length)];
  let to = demoEmployees[Math.floor(Math.random() * demoEmployees.length)];
  while (to.id === from.id) to = demoEmployees[Math.floor(Math.random() * demoEmployees.length)];
  roleDelegations.push({
    id: "rd_" + i,
    fromId: from.id,
    toId: to.id,
    roles: from.roles.filter(r => !["admin", "director", "executor"].includes(r)),
    start: TODAY,
    end: iso(addDays(new Date(), 14)),
    reason: "Временная передача полномочий",
    status: ["pending", "active", "rejected"][Math.floor(Math.random() * 3)],
  });
}

const regRequests = [
  {
    id: "reg_1",
    last: "Новый",
    first: "Сотрудник",
    email: "new.user",
    pass: "NewPass2026!",
    position: "Инженер",
    status: "pending",
  },
  {
    id: "reg_2",
    last: "Тестов",
    first: "Тест",
    email: "test.user",
    pass: "TestPass2026!",
    position: "Техник",
    status: "pending",
  },
];

const notifications = [];
for (let i = 0; i < 15; i++) {
  const user = demoEmployees[Math.floor(Math.random() * demoEmployees.length)];
  notifications.push({
    id: "n_" + i,
    userId: user.id,
    text: `Уведомление №${i+1}: событие по задаче или проекту`,
    ts: Date.now() - 1000000 * (Math.random() * 30),
    read: Math.random() > 0.5,
    targetType: ["task", "project", "hours", "vacation"][Math.floor(Math.random() * 4)],
    targetId: Math.random() > 0.5 ? tasks[Math.floor(Math.random() * tasks.length)]?.id : null,
  });
}

const audit = [];
for (let i = 0; i < 20; i++) {
  const user = demoEmployees[Math.floor(Math.random() * demoEmployees.length)];
  const actions = ["Создание задачи", "Изменение задачи", "Изменение статуса задачи", "Создание проекта", "Изменение проекта", "Удаление задачи", "Архивация проекта"];
  audit.push({
    id: "a_" + i,
    ts: Date.now() - 1000000 * (Math.random() * 30),
    userId: user.id,
    action: actions[Math.floor(Math.random() * actions.length)],
    details: `Детали действия ${i+1}`,
    targetType: null,
    targetId: null,
  });
}

export const mockData = {
  settings: { archiveMonths: 6 },
  kbs: kbList,
  departments: deptList,
  employees: demoEmployees.map(emp => {
    const depts = employeeDepts[emp.id] || [];
    return { ...emp, departments: depts };
  }),
  projects: projects,
  tasks: tasks,
  vacations: vacations,
  hoursRequests: hoursRequests,
  roleDelegations: roleDelegations,
  regRequests: regRequests,
  notifications: notifications,
  audit: audit,
};