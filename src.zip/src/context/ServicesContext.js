// context/ServicesContext.js
import { createContext, useContext } from 'react';

export const ServicesContext = createContext(null);

export const useServices = () => {
  const ctx = useContext(ServicesContext);
  if (!ctx) throw new Error('useServices must be used within ServicesProvider');
  return ctx;
};