// context/ConfirmContext.jsx
import { createContext, useContext, useState } from 'react';

const ConfirmContext = createContext(null);

export const ConfirmProvider = ({ children }) => {
  const [config, setConfig] = useState(null);

  const showConfirm = (message, onConfirm = null, onCancel = null) => {
    return new Promise((resolve) => {
      setConfig({
        message,
        onConfirm: () => {
          setConfig(null);
          resolve(true);
          if (onConfirm) onConfirm();
        },
        onCancel: () => {
          setConfig(null);
          resolve(false);
          if (onCancel) onCancel();
        },
      });
    });
  };

  return (
    <ConfirmContext.Provider value={{ showConfirm }}>
      {children}
      {config && (
        <div
          className="overlay"
          style={{ zIndex: 9999 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) config.onCancel();
          }}
        >
          <div className="modal" style={{ maxWidth: 420 }}>
            <div className="modal-head">
              <h3>Подтверждение</h3>
              <button className="icon-btn" onClick={config.onCancel}>
                <span>×</span>
              </button>
            </div>
            <div className="modal-body">
              <p>{config.message}</p>
            </div>
            <div
              className="modal-foot"
              style={{ justifyContent: 'flex-end', padding: '12px 20px' }}
            >
              <button className="btn ghost" onClick={config.onCancel}>
                Отмена
              </button>
              <button className="btn primary" onClick={config.onConfirm}>
                Подтвердить
              </button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  );
};

export const useConfirm = () => {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error('useConfirm must be used within ConfirmProvider');
  return ctx;
};