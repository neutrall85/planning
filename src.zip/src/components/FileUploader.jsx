// components/FileUploader.jsx
import React from 'react';
import { Ic, ICONS } from './Icons';
import { uid, fmtDMY } from '../utils/date';
import { useConfirm } from '../context/ConfirmContext';
import { useToast } from '../context/ToastContext';

export const FileUploader = ({
  files = [],
  onFilesChange,
  canUpload = true,
  canDelete = true,
  db,
  currentUser,
  label = 'Выбрать файл',
  showSize = true,
}) => {
  const { showConfirm } = useConfirm();
  const { showToast } = useToast();

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const fileData = ev.target.result;
      const newFile = {
        id: uid(),
        name: file.name,
        size: file.size,
        url: fileData,
        uploadedBy: currentUser.id,
        uploadedAt: new Date().toISOString(),
      };
      const updatedFiles = [...files, newFile];
      onFilesChange(updatedFiles);
      showToast('Файл загружен');
      e.target.value = '';
    };
    reader.readAsDataURL(file);
  };

  const handleDelete = (fileId) => {
    showConfirm('Удалить файл?', () => {
      const updatedFiles = files.filter(f => f.id !== fileId);
      onFilesChange(updatedFiles);
      showToast('Файл удалён');
    });
  };

  const formatSize = (bytes) => {
    if (bytes < 1024) return bytes + ' Б';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' КБ';
    return (bytes / 1048576).toFixed(1) + ' МБ';
  };

  return (
    <div className="tm-block" style={{ marginTop: 0 }}>
      <div className="rep-panel-title">Файлы</div>
      {canUpload && (
        <div style={{ marginBottom: '12px' }}>
          <label className="btn ghost sm" style={{ cursor: 'pointer' }}>
            <Ic d={ICONS.upload} size={13} /> {label}
            <input type="file" onChange={handleFileUpload} style={{ display: 'none' }} />
          </label>
          {showSize && <span className="mut sm" style={{ marginLeft: '8px' }}>(без ограничения размера)</span>}
        </div>
      )}
      {(!files || files.length === 0) && (
        <div className="mut sm">Файлы не загружены</div>
      )}
      {files && files.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {files.map(file => {
            const uploader = db?.employees?.find(e => e.id === file.uploadedBy);
            const fileSize = formatSize(file.size);
            const canDeleteFile = canDelete && (uploader?.id === currentUser.id || currentUser.roles.includes('admin'));
            return (
              <div key={file.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', background: '#f8fafc', padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--line)' }}>
                <Ic d={ICONS.file} size={24} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{file.name}</div>
                  <div className="mut sm">{fileSize} · загрузил {uploader ? `${uploader.last} ${uploader.first}` : '—'} {file.uploadedAt ? fmtDMY(file.uploadedAt) : ''}</div>
                </div>
                <a href={file.url} download={file.name} target="_blank" rel="noopener noreferrer" className="btn ghost sm">Скачать</a>
                {canDeleteFile && (
                  <button className="icon-btn danger" onClick={() => handleDelete(file.id)} title="Удалить файл">
                    <Ic d={ICONS.trash} size={14} />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};