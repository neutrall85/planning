import React from 'react';

export default function ViewToggle({ view, setView, views = ['kanban', 'list'], labels = ['Канбан', 'Список'] }) {
  return (
    <div className="seg sm" style={{ flex: '0 0 auto' }}>
      {views.map((v, idx) => (
        <button
          key={v}
          className={`seg-btn ${view === v ? 'on' : ''}`}
          onClick={() => setView(v)}
        >
          {labels[idx]}
        </button>
      ))}
    </div>
  );
}