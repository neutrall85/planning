import { fmtDT } from '../../utils/date';

export default function TaskHistoryTab({ history, empName }) {
  return (
    <div className="tm-logs" style={{ maxHeight: 260 }}>
      {[...history].reverse().map((h, i) => (
        <div key={i} className="tm-log">
          <span className="tm-log-name">{h.who === "system" ? "Система" : empName(h.who)}</span>
          <span className="mut sm">{fmtDT(h.ts)}</span>
          <span className="tm-log-note">{h.text}</span>
        </div>
      ))}
    </div>
  );
}