// components/TaskKanban.jsx
import React from 'react';
import KanbanBoard from '../KanbanBoard';
import { TASK_STATUSES, TASK_STATUS_ORDER, PRIORITIES } from '../../utils/constants';
import { TODAY, fmtD, daysDiff, initials } from '../../utils/date';
import { canChangeTaskStatus } from '../../utils/permissions';
import { Ic, ICONS } from '../Icons';

export default function TaskKanban({ tasks, db, ur, openTask, onMove }) {
  const renderCard = (task) => {
    const p = db.projects.find((x) => x.id === task.projectId);
    const assignees = (task.assigneeIds || []).map((id) => db.employees.find((e) => e.id === id)).filter(Boolean);
    const sp = (task.logs || []).reduce((s, l) => s + l.hours, 0);
    const overdue = task.deadline && !['closed', 'cancelled'].includes(task.status) && task.deadline < TODAY;
    const soon = task.deadline && !overdue && !['closed', 'cancelled'].includes(task.status) && daysDiff(TODAY, task.deadline) <= 3;

    return (
      <>
        <div className="kcard-prio" style={{ background: PRIORITIES[task.priority].color }} />
        <div className="kcard-title">{task.title}</div>
        <div className="kcard-proj">
          <span className="pdot" style={{ background: p?.color }} />
          {p?.code}
        </div>
        <div className="kcard-meta">
          {assignees.length > 0 && (
            <span className="kassignee">
              {assignees.slice(0, 2).map((a) => (
                <span key={a.id} className="avatar xs" style={{ marginRight: -4 }}>
                  {a.photo ? (
                    <img src={a.photo} alt="Аватар" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                  ) : (
                    initials(a.first, a.last)
                  )}
                </span>
              ))}
              {assignees.length > 2 && <span className="mut sm">+{assignees.length - 2}</span>}
            </span>
          )}
          <span className="khours">
            <Ic d={ICONS.clock} size={13} /> {sp}/{task.plannedHours ?? '—'} ч
          </span>
        </div>
        <div className="kcard-foot">
          <span className={'kdl' + (overdue ? ' late' : soon ? ' soon' : '')}>
            {task.deadline
              ? overdue
                ? `просрочено ${-daysDiff(TODAY, task.deadline)} дн`
                : `до ${fmtD(task.deadline)}`
              : 'без дедлайна'}
          </span>
        </div>
      </>
    );
  };

  const canDragTask = (task) => !['closed', 'cancelled'].includes(task.status) && canChangeTaskStatus(ur, task, task.status, db);

  return (
    <KanbanBoard
      items={tasks}
      statusOrder={TASK_STATUS_ORDER}
      statusConfig={TASK_STATUSES}
      renderCard={renderCard}
      onDrop={onMove}
      onCardClick={openTask}
      renderFilters={null}
      db={db}
      ur={ur}
      canDrag={canDragTask}
      emptyText="Нет задач"
    />
  );
}