// components/TasksView.jsx
import React, { useMemo } from 'react';
import TaskKanban from './TaskKanban';
import TaskList from './TaskList';
import TaskFilters from './TaskFilters';
import { useFilters } from '../../hooks/useFilters';
import { useFilteredTasks } from '../../hooks/useFilteredTasks';
import { computeScope, canCreateTask, hasRole } from '../../utils/permissions';

export default function TasksView({ db, ur, openTask, onMove, onNew }) {
  const { filters, setFilter } = useFilters({
    view: 'kanban',
    search: '',
    projectId: 'all',
    assigneeId: 'all',
    priority: 'all',
    deptId: 'all',
    showOnlyMy: false,
  });

  const tasks = useFilteredTasks(db, ur, filters);
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);

  const projects = useMemo(() => 
    db.projects.filter(p => !p.archived && (scope.all || scope.projIds.has(p.id))),
    [db.projects, scope]
  );

  const assignees = useMemo(() => {
    const ids = new Set(tasks.flatMap(t => t.assigneeIds || []));
    return db.employees.filter(e => ids.has(e.id)).sort((a,b) => a.last.localeCompare(b.last));
  }, [tasks, db.employees]);

  const canSeeAll = hasRole(ur, 'admin', 'director', 'economist', 'kb_chief', 'head', 'project_lead', 'project_manager');
  const isOnlyExecutor = ur.roles.length === 1 && ur.roles[0] === 'executor';

  return (
    <div>
      <TaskFilters
        view={filters.view}
        setView={(v) => setFilter('view', v)}
        search={filters.search}
        setSearch={(v) => setFilter('search', v)}
        projectId={filters.projectId}
        setProjectId={(v) => setFilter('projectId', v)}
        assigneeId={filters.assigneeId}
        setAssigneeId={(v) => setFilter('assigneeId', v)}
        priority={filters.priority}
        setPriority={(v) => setFilter('priority', v)}
        deptId={filters.deptId}
        setDeptId={(v) => setFilter('deptId', v)}
        showOnlyMy={filters.showOnlyMy}
        setShowOnlyMy={(v) => setFilter('showOnlyMy', v)}
        projects={projects}
        assignees={assignees}
        departments={db.departments}
        isOnlyExecutor={isOnlyExecutor}
        canSeeAll={canSeeAll}
        canCreateTask={canCreateTask(ur)}
        onNew={onNew}
      />
      {filters.view === 'kanban' ? (
        <TaskKanban tasks={tasks} db={db} ur={ur} openTask={openTask} onMove={onMove} />
      ) : (
        <TaskList tasks={tasks} db={db} ur={ur} openTask={openTask} />
      )}
    </div>
  );
}