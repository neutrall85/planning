// components/task/TaskModal.jsx
import React, { useState, useMemo } from 'react';
import { Modal } from '../Modal';
import { FileUploader } from '../FileUploader';
import { FormRenderer } from '../forms/FormRenderer';
import { AssigneeList } from '../forms/AssigneeList';
import { RepeatConfig } from '../forms/RepeatConfig';
import { getTaskFormSchema } from '../../schemas/taskFormSchema';
import TaskTimeTab from './TaskTimeTab';
import TaskHistoryTab from './TaskHistoryTab';
import Discussion from '../Discussion';
import { useTaskRepeater } from '../../hooks/useTaskRepeater';
import { useTaskDependency } from '../../hooks/useTaskDependency';
import { canCreateTask, canEditTaskFields, hasRole, assigneeOptions, computeScope, canChangeTaskStatus } from '../../utils/permissions';
import { TASK_STATUS_ORDER, TASK_STATUSES } from '../../utils/constants';
import { TODAY, uid, fmtDMY } from '../../utils/date';
import { useDataHelpers } from '../../hooks';
import { Ic, ICONS } from '../Icons';
import { projectParticipants } from '../../utils/mention';
import { useToast } from '../../context/ToastContext';
import { useConfirm } from '../../context/ConfirmContext';
import { useServices } from '../../context/ServicesContext';

export const TaskModal = ({
  db,
  ur,
  taskId,
  initialTab = 'form',
  presetProjectId = null,
  spent,
  planSum,
  onClose,
  onSave,
  onDelete,
  onHoursReq,
  patchTask,
  notify,
  store,
}) => {
  const services = useServices();
  const { showToast } = useToast();
  const { showConfirm } = useConfirm();
  const { empName, getTaskSpent, vacOverlap, primaryDept } = useDataHelpers(db);
  const existing = taskId ? services.task.getTask(taskId) : null;
  const readOnly = !!(existing && existing.archived);
  const canEditFields = !readOnly && (existing ? canEditTaskFields(ur, existing, db) : canCreateTask(ur));
  const canChangeStatus = !readOnly && existing && canChangeTaskStatus(ur, existing, null, db);
  const isAuthor = existing && existing.creatorId === ur.id;
  const isReview = existing && existing.status === 'review';
  const scope = computeScope(ur, db) || { all: false, empIds: new Set(), projIds: new Set() };
  const projs = (scope.all ? db.projects : db.projects.filter(p => scope.projIds.has(p.id))).filter(p => p.status === "active" && !p.archived);
  const asOpts = assigneeOptions(ur, db);

  const [tab, setTab] = useState(initialTab);
  const [confirmVac, setConfirmVac] = useState(null);

  const { generateRepeatDates } = useTaskRepeater();
  const { getDependencyDates } = useTaskDependency();

  const defaultValues = existing ? {
    ...existing,
    assigneeIds: [...new Set(existing.assigneeIds || [])],
  } : {
    id: "t_" + uid(),
    title: "",
    desc: "",
    projectId: presetProjectId || "",
    assigneeIds: [],
    priority: "mid",
    plannedHours: 8,
    start: TODAY,
    deadline: null,
    status: "new",
    logs: [],
    comments: [],
    files: [],
    history: [],
    delegatedFrom: null,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: ur.id,
    dependencyId: null,
    dependencyType: 'FS',
    repeatType: 'none',
    repeatInterval: 1,
    repeatDays: [],
    repeatEndType: 'date',
    repeatEndValue: '',
  };

  const proj = db.projects.find(p => p.id === defaultValues.projectId);
  const isAdminProj = proj && proj.ptype === "admin";
  const sp = defaultValues.logs.reduce((s, l) => s + l.hours, 0);
  const remainProj = proj && proj.budget != null && !proj.archived ? proj.budget - (planSum(proj.id) - (existing ? (existing.plannedHours || 0) : 0)) : null;
  const vacWarn = !readOnly && defaultValues.assigneeIds && defaultValues.assigneeIds.length > 0 && defaultValues.deadline ? defaultValues.assigneeIds.some(id => vacOverlap(id, defaultValues.start || defaultValues.deadline, defaultValues.deadline)) : null;
  const isExec = existing && (existing.assigneeIds || []).includes(ur.id);
  const canLog = !readOnly && ((existing ? isExec : defaultValues.assigneeIds?.includes(ur.id)) || hasRole(ur, "admin"));

  const statusOptions = useMemo(() => {
    if (isExec && !canChangeTaskStatus(ur, defaultValues, 'closed', db) && !canChangeTaskStatus(ur, defaultValues, 'cancelled', db)) {
      return TASK_STATUS_ORDER.filter(s => ['new', 'inwork', 'review'].includes(s));
    }
    return TASK_STATUS_ORDER;
  }, [isExec, defaultValues, ur, db]);

  const ensureExecutorRole = (empId) => {
    const emp = db.employees.find(e => e.id === empId);
    if (emp && !emp.roles.includes('executor')) {
      const updated = { ...emp, roles: [...emp.roles, 'executor'] };
      store.upsertEmployee(updated);
    }
  };

  const onSubmit = (data) => {
    if (!data.title.trim()) {
      showToast("Укажите название задачи", "err");
      return;
    }
    if (!data.projectId) {
      showToast("Задача обязательно назначается в рамках проекта", "err");
      return;
    }
    if (!data.assigneeIds || data.assigneeIds.length === 0) {
      showToast("Выберите хотя бы одного исполнителя", "err");
      return;
    }
    if (!isAdminProj) {
      if (!data.plannedHours || +data.plannedHours <= 0) {
        showToast("Для производственного проекта плановые часы обязательны", "err");
        return;
      }
      if (!data.deadline) {
        showToast("Для производственного проекта дедлайн обязателен", "err");
        return;
      }
    }
    const projForBudget = db.projects.find(p => p.id === data.projectId);
    if (projForBudget && projForBudget.budget != null && !projForBudget.archived && !isAdminProj) {
      const currentPlanSum = planSum(projForBudget.id);
      const newTotal = currentPlanSum + (+data.plannedHours || 0);
      if (newTotal > projForBudget.budget) {
        showToast(`Превышение бюджета проекта! Бюджет: ${projForBudget.budget} ч, текущая сумма задач: ${currentPlanSum} ч, запрошено: ${data.plannedHours || 0} ч. Уменьшите плановые часы.`, "err");
        return;
      }
    }
    if (data.repeatType !== 'none') {
      if (data.repeatType === 'weekly_days' && (!data.repeatDays || data.repeatDays.length === 0)) {
        showToast("Выберите хотя бы один день недели", "err");
        return;
      }
      if (data.repeatEndType === 'date' && !data.repeatEndValue) {
        showToast("Укажите дату окончания повторения", "err");
        return;
      }
      if (data.repeatEndType === 'count' && (!data.repeatEndValue || parseInt(data.repeatEndValue, 10) <= 0)) {
        showToast("Укажите количество повторений", "err");
        return;
      }
      if (data.repeatEndType === 'date' && data.repeatEndValue && data.repeatEndValue <= data.start) {
        showToast("Дата окончания должна быть позже даты начала", "err");
        return;
      }
    }
    if (data.assigneeIds && data.assigneeIds.length > 0) {
      data.assigneeIds.forEach(id => ensureExecutorRole(id));
    }
    if (vacWarn) { setConfirmVac(vacWarn); return; }
    doSave(data);
  };

  const doSave = (formData) => {
    const history = [...(formData.history || [])];
    const statusToSave = formData.status;
    if (existing && existing.status !== statusToSave) {
      history.push({ ts: Date.now(), who: ur.id, text: `Статус: ${TASK_STATUSES[existing.status].label} → ${TASK_STATUSES[statusToSave].label}` });
    }

    let depDates = { start: formData.start, deadline: formData.deadline };
    if (formData.dependencyId) {
      const depTask = db.tasks.find(t => t.id === formData.dependencyId);
      if (depTask) {
        depDates = getDependencyDates(formData, depTask);
      }
    }

    const newClosed = statusToSave === "closed" && (!existing || existing.status !== "closed");
    const taskToSave = {
      ...formData,
      start: depDates.start,
      deadline: depDates.deadline,
      status: statusToSave,
      plannedHours: formData.plannedHours === "" || formData.plannedHours == null ? null : +formData.plannedHours,
      closedAt: newClosed ? TODAY : (existing ? existing.closedAt : null),
      history,
      creatorId: existing ? existing.creatorId : ur.id,
    };
    delete taskToSave.repeatType;
    delete taskToSave.repeatInterval;
    delete taskToSave.repeatDays;
    delete taskToSave.repeatEndType;
    delete taskToSave.repeatEndValue;

    try {
      if (!existing && formData.repeatType !== 'none') {
        const repeatConfig = {
          type: formData.repeatType,
          interval: parseInt(formData.repeatInterval, 10) || 1,
          days: formData.repeatDays.map(Number),
          endType: formData.repeatEndType,
          endValue: formData.repeatEndValue,
        };
        const results = services.task.createRepeatingTasks(taskToSave, repeatConfig, 50);
        onSave(results[0], true);
        onClose();
      } else {
        let saved;
        if (existing) {
          saved = services.task.updateTask(taskToSave.id, taskToSave);
        } else {
          saved = services.task.createTask(taskToSave);
        }
        onSave(saved, !existing);
      }
    } catch (error) {
      showToast(error.message, 'err');
    }
  };

  const handleAccept = () => { if (isAuthor && isReview) doSave({ ...defaultValues, status: 'closed' }); };
  const handleRework = () => { if (isAuthor && isReview) doSave({ ...defaultValues, status: 'inwork' }); };

  const handleDelete = () => {
    showConfirm(`Удалить задачу "${defaultValues.title}"?`, () => {
      services.task.deleteTask(defaultValues.id);
      onDelete(defaultValues.id);
      showToast('Задача удалена');
    });
  };

  const canManageFiles = !readOnly && (
    !existing ||
    (existing.assigneeIds || []).includes(ur.id) ||
    canEditFields
  );

  const handleFilesChange = (updatedFiles) => {
    const newTask = { ...defaultValues, files: updatedFiles };
    patchTask(newTask);
  };

  const assigneeOptionsList = asOpts.map((e) => {
    const primary = e.departments?.find(d => d.primary);
    let deptName = '';
    if (primary) {
      const dept = db.departments.find(d => d.id === primary.deptId);
      deptName = dept?.name || '';
    }
    return {
      value: e.id,
      label: `${e.last} ${e.first}`,
      dept: deptName,
    };
  });

  const renderCustomFields = ({ control, disabled }) => {
    return (
      <>
        <AssigneeList
          name="assigneeIds"
          control={control}
          options={assigneeOptionsList}
          disabled={disabled}
          label="Исполнители *"
        />
        {!existing && !readOnly && (
          <RepeatConfig control={control} disabled={disabled} />
        )}
      </>
    );
  };

  const schema = getTaskFormSchema(db, ur, existing, readOnly, canEditFields, statusOptions, isAdminProj);

  return (
    <Modal title={(readOnly ? "Архивная задача — только чтение" : existing ? "Карточка задачи" : "Новая задача")} onClose={onClose} width={720}>
      {readOnly && <div className="info-box">Задача в архиве с {fmtDMY(existing.archivedAt)}. Редактирование, изменение статусов и комментирование запрещены.</div>}
      <div className="tabs sm">
        <button className={`tab${tab === 'form' ? ' on' : ''}`} onClick={() => setTab('form')}>Данные</button>
        {existing && (
          <button className={`tab${tab === 'time' ? ' on' : ''}`} onClick={() => setTab('time')}>Учёт времени ({sp}/{defaultValues.plannedHours ?? "—"})</button>
        )}
        <button className={`tab${tab === 'discussion' ? ' on' : ''}`} onClick={() => setTab('discussion')}>Обсуждение ({defaultValues.comments?.length || 0})</button>
        <button className={`tab${tab === 'files' ? ' on' : ''}`} onClick={() => setTab('files')}>Файлы ({defaultValues.files?.length || 0})</button>
        {existing && <button className={`tab${tab === 'hist' ? ' on' : ''}`} onClick={() => setTab('hist')}>История</button>}
      </div>

      {tab === 'form' && (
        <FormRenderer
          schema={schema}
          defaultValues={defaultValues}
          onSubmit={onSubmit}
          onCancel={onClose}
          disabled={readOnly}
          renderCustomFields={renderCustomFields}
          submitLabel={existing ? 'Сохранить' : 'Создать задачу'}
          hideDefaultActions={readOnly || !(canEditFields || isExec)}
          renderActions={({ disabled }) => (
            <>
              {existing && canEditFields && !readOnly && (
                <button type="button" className="btn danger" onClick={handleDelete}>
                  <Ic d={ICONS.trash} size={14} /> Удалить
                </button>
              )}
              {readOnly && <span className="mut sm">Режим только для чтения</span>}
            </>
          )}
        />
      )}

      {tab === 'time' && existing && (
        <>
          <TaskTimeTab
            f={defaultValues}
            setF={(fn) => {
              const updated = fn(defaultValues);
              patchTask(updated);
            }}
            sp={sp}
            canLog={canLog}
            readOnly={readOnly}
            empName={empName}
            isExec={isExec}
            toast={showToast}
            ur={ur}
          />
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </>
      )}

      {tab === 'discussion' && (
        <>
          <div style={{ marginTop: 8 }}>
            {!existing ? (
              <div className="info-box">Сохраните задачу, чтобы начать обсуждение.</div>
            ) : (
              <Discussion
                comments={defaultValues.comments}
                onAddComment={(newComment, parentId, updatedComments) => {
                  if (updatedComments) {
                    const newTask = { ...defaultValues, comments: updatedComments };
                    patchTask(newTask);
                    return;
                  }
                  const newComments = [...defaultValues.comments, newComment];
                  const newTask = { ...defaultValues, comments: newComments };
                  patchTask(newTask);
                  showToast("Комментарий добавлен");
                }}
                candidates={existing ? projectParticipants(db, defaultValues.projectId).filter(e => e.id !== ur.id) : []}
                currentUser={ur}
                db={db}
                readOnly={readOnly || !existing}
                toast={showToast}
                projectId={defaultValues.projectId}
              />
            )}
          </div>
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </>
      )}

      {tab === 'files' && (
        <>
          <FileUploader
            files={defaultValues.files}
            onFilesChange={handleFilesChange}
            canUpload={!readOnly && canManageFiles}
            canDelete={!readOnly && canManageFiles}
            db={db}
            currentUser={ur}
            label="Выбрать файл"
            showSize
          />
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </>
      )}

      {tab === 'hist' && existing && (
        <>
          <TaskHistoryTab history={defaultValues.history} empName={empName} />
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </>
      )}

      {confirmVac && (
        <Modal title="Конфликт с отпуском исполнителя" onClose={() => setConfirmVac(null)} width={460}>
          <p>Один из исполнителей находится в отпуске с {fmtDMY(confirmVac.start)} по {fmtDMY(confirmVac.end)}. Вы уверены, что хотите назначить задачу?</p>
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={() => setConfirmVac(null)}>Отмена</button>
            <button className="btn primary" onClick={() => { setConfirmVac(null); doSave(defaultValues); }}>Назначить</button>
          </div>
        </Modal>
      )}
    </Modal>
  );
};