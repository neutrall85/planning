import React from 'react';
import { Ic, ICONS } from '../Icons';
import { PRIORITIES } from '../../utils/constants';
import ViewToggle from '../ViewToggle';

export default function TaskFilters({
  view,
  setView,
  search,
  setSearch,
  projectId,
  setProjectId,
  assigneeId,
  setAssigneeId,
  priority,
  setPriority,
  deptId,
  setDeptId,
  showOnlyMy,
  setShowOnlyMy,
  projects,
  assignees,
  departments,
  isOnlyExecutor,
  canSeeAll,
  canCreateTask,
  onNew,
}) {
  return (
    <div style={{
      display: 'flex',
      flexWrap: 'nowrap',
      gap: '6px',
      alignItems: 'center',
      overflowX: 'auto',
      paddingBottom: '4px',
      marginBottom: '14px',
      whiteSpace: 'nowrap',
    }}>
      <ViewToggle view={view} setView={setView} />

      <div className="search-box" style={{ flex: '0 0 auto', minWidth: '140px' }}>
        <Ic d={ICONS.search} size={15} />
        <input
          placeholder="Поиск задач…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: '120px' }}
        />
      </div>
      
      <select
        className="inp sel sm"
        value={projectId}
        onChange={(e) => setProjectId(e.target.value)}
        style={{ flex: '0 0 auto', width: '130px' }}
      >
        <option value="all">Все проекты</option>
        {projects.map((p) => (
          <option key={p.id} value={p.id}>{p.code}</option>
        ))}
      </select>

      {!isOnlyExecutor && (
        <select
          className="inp sel sm"
          value={assigneeId}
          onChange={(e) => setAssigneeId(e.target.value)}
          style={{ flex: '0 0 auto', width: '140px' }}
        >
          <option value="all">Все исполнители</option>
          {assignees.map((e) => (
            <option key={e.id} value={e.id}>{e.last} {e.first}</option>
          ))}
        </select>
      )}

      <select
        className="inp sel sm"
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
        style={{ flex: '0 0 auto', width: '140px' }}
      >
        <option value="all">Любой приоритет</option>
        {Object.entries(PRIORITIES).map(([k, v]) => (
          <option key={k} value={k}>{v.label}</option>
        ))}
      </select>

      {!isOnlyExecutor && (
        <select
          className="inp sel sm"
          value={deptId}
          onChange={(e) => setDeptId(e.target.value)}
          style={{ flex: '0 0 auto', width: '150px' }}
        >
          <option value="all">Все подразделения</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
      )}

      {canSeeAll && (
        <label style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <input
            type="checkbox"
            checked={showOnlyMy}
            onChange={(e) => setShowOnlyMy(e.target.checked)}
          />
          <span style={{ fontSize: 13 }}>Только мои</span>
        </label>
      )}

      <div style={{ flex: '1 1 auto', minWidth: '20px' }} />

      {canCreateTask && (
        <button className="btn primary sm" onClick={onNew} style={{ flex: '0 0 auto' }}>
          <Ic d={ICONS.plus} size={15} /> Задача
        </button>
      )}
    </div>
  );
}