// components/TaskList.jsx
import React from 'react';
import { TASK_STATUSES, PRIORITIES } from '../../utils/constants';
import { fmtDMY, initials } from '../../utils/date';

export default function TaskList({ tasks, db, ur, openTask }) {
  return (
    <div>
      <div className="rep-panel" style={{ overflow: 'auto' }}>
        <table className="tbl">
          <thead>
            <tr>
              <th>Задача</th>
              <th>Проект</th>
              <th>Исполнители</th>
              <th>Статус</th>
              <th>Приоритет</th>
              <th>Дедлайн</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task) => {
              const p = db.projects.find((x) => x.id === task.projectId);
              const assignees = (task.assigneeIds || []).map((id) => db.employees.find((e) => e.id === id)).filter(Boolean);
              return (
                <tr key={task.id} style={{ cursor: 'pointer' }} onClick={() => openTask(task.id)}>
                  <td><strong>{task.title}</strong></td>
                  <td>{p?.code || '—'}</td>
                  <td>
                    {assignees.map((a) => (
                      <span key={a.id} className="avatar xs" style={{ marginRight: 4 }} title={`${a.last} ${a.first}`}>
                        {a.photo ? (
                          <img src={a.photo} alt="Аватар" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                        ) : (
                          initials(a.first, a.last)
                        )}
                      </span>
                    ))}
                  </td>
                  <td>
                    <span className="st-chip" style={{ background: TASK_STATUSES[task.status].color + '33', color: TASK_STATUSES[task.status].color }}>
                      {TASK_STATUSES[task.status].label}
                    </span>
                  </td>
                  <td>
                    <span style={{ color: PRIORITIES[task.priority].color }}>{PRIORITIES[task.priority].label}</span>
                  </td>
                  <td>{task.deadline ? fmtDMY(task.deadline) : '—'}</td>
                </tr>
              );
            })}
            {tasks.length === 0 && (
              <tr>
                <td colSpan="6" className="mut" style={{ textAlign: 'center', padding: '20px 0' }}>
                  Нет задач
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}