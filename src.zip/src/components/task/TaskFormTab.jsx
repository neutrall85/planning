// components/task/TaskFormTab.jsx
import React, { useState, useMemo } from 'react';
import { Ic, ICONS } from '../Icons';
import { PRIORITIES, DEPENDENCY_TYPES, TASK_STATUSES } from '../../utils/constants';
import { fmtDMY } from '../../utils/date';
import { useDataHelpers } from '../../hooks';

export default function TaskFormTab({
  f,
  set,
  readOnly,
  canEditFields,
  canChangeStatus,
  canEditPlannedHours,
  projs,
  asOpts,
  db,
  ur,
  existing,
  statusOptions,
  vacWarn,
  remainProj,
  isAuthor,
  isReview,
  onHoursReq,
  handleAccept,
  handleRework,
  toast,
  isExec,
  isPresetProject,
}) {
  const { primaryDept, empName } = useDataHelpers(db);
  const [showAssigneeSelector, setShowAssigneeSelector] = useState(false);
  const [newAssigneeId, setNewAssigneeId] = useState('');

  const project = db.projects.find(p => p.id === f.projectId);
  const isAdminProj = project && project.ptype === "admin";

  const addAssignee = () => {
    if (!newAssigneeId) return;
    if (f.assigneeIds.includes(newAssigneeId)) {
      toast("Этот исполнитель уже добавлен", "err");
      return;
    }
    set('assigneeIds', [...f.assigneeIds, newAssigneeId]);
    setNewAssigneeId('');
    setShowAssigneeSelector(false);
  };

  const removeAssignee = (id) => {
    set('assigneeIds', f.assigneeIds.filter(x => x !== id));
  };

  const availableCandidates = useMemo(() => {
    return asOpts.filter(e => !f.assigneeIds.includes(e.id));
  }, [asOpts, f.assigneeIds]);

  const proj = db.projects.find(p => p.id === f.projectId);

  return (
    <>
      {vacWarn && <div className="warn-box"><Ic d={ICONS.beach} size={15} /> Один из исполнителей находится в отпуске с {fmtDMY(vacWarn.start)} по {fmtDMY(vacWarn.end)}. Даты пересекаются с периодом задачи.</div>}
      {remainProj !== null && remainProj - (+f.plannedHours || 0) < 0 && <div className="warn-box">Внимание: задача превысит остаток бюджета проекта ({remainProj} ч). Потребуется утверждение ГД.</div>}
      {isAdminProj && !readOnly && <div className="info-box">Административный проект: дедлайн и плановые часы задачи — по желанию.</div>}
      <div className="form-grid">
        <label className="lbl">Название *</label>
        <input className="inp" disabled={!canEditFields} value={f.title} onChange={e => set("title", e.target.value)} />
        <label className="lbl">Описание</label>
        <textarea className="inp" rows="2" disabled={!canEditFields} value={f.desc} onChange={e => set("desc", e.target.value)} />
        
        <label className="lbl">Проект * <span className="mut">(активные)</span></label>
        {readOnly ? (
          <input className="inp" disabled value={db.projects.find(p => p.id === f.projectId)?.name || ""} />
        ) : isPresetProject ? (
          <div className="inp" style={{ background: '#f1f5f9', padding: '8px 12px', borderRadius: '10px', color: '#64748b', cursor: 'default' }}>
            {db.projects.find(p => p.id === f.projectId)?.name || '—'}
          </div>
        ) : (
          <select className="inp sel" disabled={!canEditFields} value={f.projectId} onChange={e => set("projectId", e.target.value)}>
            <option value="">— выберите проект —</option>
            {projs.map(p => <option key={p.id} value={p.id}>{p.code} — {p.name}{p.ptype === "admin" ? " (административный)" : ""}</option>)}
          </select>
        )}

        <label className="lbl">Приоритет *</label>
        <select className="inp sel" disabled={!canEditFields} value={f.priority} onChange={e => set("priority", e.target.value)}>
          {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>

        <label className="lbl">Исполнители *</label>
        {readOnly ? (
          <input className="inp" disabled value={(f.assigneeIds || []).map(id => empName(id)).join(', ')} />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {f.assigneeIds.map(id => {
                const e = db.employees.find(x => x.id === id);
                return e ? (
                  <span key={id} style={{ display: 'inline-flex', alignItems: 'center', background: '#e2e8f0', padding: '2px 8px', borderRadius: '12px', fontSize: '13px' }}>
                    {e.last} {e.first}
                    {canEditFields && <button type="button" onClick={() => removeAssignee(id)} style={{ marginLeft: '6px', border: 'none', background: 'transparent', color: '#dc2626', cursor: 'pointer' }}>×</button>}
                  </span>
                ) : null;
              })}
              {f.assigneeIds.length === 0 && <span className="mut sm">Нет исполнителей</span>}
            </div>
            {canEditFields && (
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button className="btn ghost sm" onClick={() => setShowAssigneeSelector(!showAssigneeSelector)}>
                  <Ic d={ICONS.plus} size={13} /> Добавить
                </button>
                {showAssigneeSelector && (
                  <select className="inp sel sm" style={{ width: '200px' }} value={newAssigneeId} onChange={e => setNewAssigneeId(e.target.value)}>
                    <option value="">— выберите —</option>
                    {availableCandidates.map(e => (
                      <option key={e.id} value={e.id}>{e.last} {e.first} — {primaryDept(e)?.name || ''}</option>
                    ))}
                  </select>
                )}
                {showAssigneeSelector && <button className="btn primary sm" onClick={addAssignee} disabled={!newAssigneeId}>Добавить</button>}
              </div>
            )}
          </div>
        )}

        <label className="lbl">Начало работы</label>
        <input className="inp" type="date" disabled={!canEditFields} value={f.start} onChange={e => set("start", e.target.value)} />
        <label className="lbl">Дедлайн {!isAdminProj && "*"}</label>
        <input className="inp" type="date" disabled={!canEditFields} value={f.deadline || ""} onChange={e => set("deadline", e.target.value)} />
        
        <label className="lbl">Плановые часы {!isAdminProj && "*"}</label>
        <div className="duo">
          <input
            className="inp"
            type="number"
            min="0.5"
            step="0.5"
            disabled={!canEditPlannedHours}
            value={f.plannedHours ?? ""}
            onChange={e => set("plannedHours", e.target.value)}
          />
          {!readOnly && existing && isExec && (
            <button
              className="btn ghost sm"
              type="button"
              onClick={() => onHoursReq("task", existing.id)}
            >
              <Ic d={ICONS.clock} size={13} /> Запросить изменение часов
            </button>
          )}
          {!readOnly && isAdminProj && <span className="duo-note">опционально</span>}
          {readOnly && <span className="duo-note">только чтение</span>}
          {!readOnly && !existing && <span className="duo-note">сохраните задачу для запроса</span>}
        </div>

        <label className="lbl">Статус *</label>
        <select className="inp sel" disabled={!canChangeStatus && !isAuthor && !isExec} value={f.status} onChange={e => set("status", e.target.value)}>
          {statusOptions.map(s => <option key={s} value={s}>{TASK_STATUSES[s].label}</option>)}
        </select>
        {isExec && !canEditFields && !readOnly && <div className="mut sm" style={{ gridColumn: "1 / -1" }}>Исполнитель может переводить задачу в «В работе» и «На проверке»; закрытие и отмена — у ответственного/руководителя.</div>}

        <label className="lbl">Зависит от задачи</label>
        <select className="inp sel" disabled={!canEditFields} value={f.dependencyId || ''} onChange={e => set("dependencyId", e.target.value || null)}>
          <option value="">— нет зависимости —</option>
          {db.tasks
            .filter(t => t.id !== f.id && t.projectId === f.projectId && t.status !== 'closed' && t.status !== 'cancelled')
            .map(t => <option key={t.id} value={t.id}>{t.title}</option>)}
        </select>

        <label className="lbl">Тип зависимости</label>
        <select className="inp sel" disabled={!canEditFields || !f.dependencyId} value={f.dependencyType || 'FS'} onChange={e => set("dependencyType", e.target.value)}>
          {Object.entries(DEPENDENCY_TYPES).map(([key, val]) => <option key={key} value={key}>{val.label} — {val.desc}</option>)}
        </select>
      </div>

      {!existing && !readOnly && (
        <div className="tm-block" style={{ marginTop: '12px' }}>
          <div className="rep-panel-title">Повторение</div>
          <div className="form-grid" style={{ gridTemplateColumns: '150px 1fr' }}>
            <label className="lbl">Тип повторения</label>
            <select className="inp sel" value={f.repeatType} onChange={e => set("repeatType", e.target.value)}>
              <option value="none">Нет</option>
              <option value="daily">Ежедневно</option>
              <option value="weekly_days">Еженедельно по дням</option>
              <option value="workdays">Каждый рабочий день</option>
              <option value="monthly">Ежемесячно</option>
              <option value="yearly">Ежегодно</option>
              <option value="custom">Произвольно (через N дней)</option>
            </select>
            {f.repeatType === 'custom' && (
              <>
                <label className="lbl">Интервал (дней)</label>
                <input className="inp" type="number" min="1" value={f.repeatInterval} onChange={e => set("repeatInterval", e.target.value)} />
              </>
            )}
            {f.repeatType === 'weekly_days' && (
              <>
                <label className="lbl">Дни недели</label>
                <div className="duo" style={{ flexWrap: 'wrap', gap: '6px' }}>
                  {['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map((day, idx) => {
                    const dayNum = idx + 1;
                    const checked = f.repeatDays.includes(String(dayNum));
                    return (
                      <label key={dayNum} className="dept-pick" style={{ margin: 0 }}>
                        <input type="checkbox" checked={checked} onChange={() => {
                          const newDays = checked ? f.repeatDays.filter(d => d !== String(dayNum)) : [...f.repeatDays, String(dayNum)];
                          set("repeatDays", newDays);
                        }} />
                        {day}
                      </label>
                    );
                  })}
                </div>
              </>
            )}
            {f.repeatType !== 'none' && (
              <>
                <label className="lbl">Окончание</label>
                <div className="duo" style={{ display: 'flex', gap: '8px' }}>
                  <select className="inp sel" value={f.repeatEndType} onChange={e => set("repeatEndType", e.target.value)} style={{ width: '120px' }}>
                    <option value="date">По дате</option>
                    <option value="count">По количеству</option>
                  </select>
                  {f.repeatEndType === 'date' ? (
                    <input className="inp" type="date" value={f.repeatEndValue} onChange={e => set("repeatEndValue", e.target.value)} style={{ flex: 1 }} />
                  ) : (
                    <input className="inp" type="number" min="1" value={f.repeatEndValue} onChange={e => set("repeatEndValue", e.target.value)} placeholder="кол-во" style={{ width: '100px' }} />
                  )}
                  <span className="mut sm" style={{ alignSelf: 'center' }}>всего {f.repeatEndType === 'count' ? 'задач' : ''}</span>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {remainProj !== null && <div className="budget-hint">Остаток бюджета проекта «{proj?.code}»: <b>{remainProj} ч</b> из {proj?.budget} ч</div>}

      {isAuthor && isReview && !readOnly && (
        <div style={{ marginTop: 16, display: 'flex', gap: 10 }}>
          <button className="btn primary" onClick={handleAccept}><Ic d={ICONS.check} size={15} /> Принять (закрыть)</button>
          <button className="btn ghost" onClick={handleRework}><Ic d={ICONS.refresh} size={15} /> Отправить на доработку</button>
        </div>
      )}
    </>
  );
}