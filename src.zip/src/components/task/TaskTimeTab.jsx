// components/task/TaskTimeTab.jsx
import React, { useState } from 'react';
import { Ic, ICONS } from '../Icons';
import { fmtD, uid, TODAY, fmtDMY } from '../../utils/date';

export default function TaskTimeTab({ f, setF, sp, canLog, readOnly, empName, toast, ur }) {
  const [logH, setLogH] = useState("");
  const [logNote, setLogNote] = useState("");
  const [logDate, setLogDate] = useState(TODAY);

  const addLog = () => {
    const h = parseFloat(String(logH).replace(",", "."));
    if (!h || h <= 0) return toast("Введите корректное количество часов", "err");
    if (f.plannedHours && sp + h > f.plannedHours) return toast(`Нельзя внести больше плановых: доступно ещё ${Math.max(0, f.plannedHours - sp)} ч`, "err");
    const newLogs = [...f.logs, { id: uid(), userId: ur.id, date: logDate, hours: h, note: logNote.trim() }];
    // Добавляем запись в историю
    const newHistory = [...f.history, { ts: Date.now(), who: ur.id, text: `Внесено ${h} ч (${fmtDMY(logDate)})` }];
    setF(prev => ({ ...prev, logs: newLogs, history: newHistory }));
    setLogH("");
    setLogNote("");
    setLogDate(TODAY);
    toast("Часы учтены");
  };

  return (
    <div className="tm-block" style={{ marginTop: 0 }}>
      <div className="tm-progress"><div className="tm-progress-fill" style={{ width: Math.min(100, (sp / Math.max(1, f.plannedHours || 0)) * 100) + "%" }} /></div>
      {f.logs.length > 0 && (
        <div className="tm-logs">
          {f.logs.map(l => (
            <div key={l.id} className="tm-log">
              <span className="tm-log-name">{empName(l.userId)}</span>
              <span className="mut">{fmtD(l.date)}</span>
              <span className="tm-log-note">{l.note}</span>
              <b className="tm-log-h">{l.hours} ч</b>
            </div>
          ))}
        </div>
      )}
      {canLog ? (
        <div className="tm-add" style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
          <input
            className="inp"
            type="date"
            max={TODAY}
            value={logDate}
            onChange={(e) => setLogDate(e.target.value)}
            style={{ width: '150px' }}
          />
          <input
            className="inp"
            style={{ width: '90px' }}
            type="number"
            min="0.5"
            step="0.5"
            placeholder="часы"
            value={logH}
            onChange={e => setLogH(e.target.value)}
          />
          <input
            className="inp"
            placeholder="комментарий"
            value={logNote}
            onChange={e => setLogNote(e.target.value)}
            style={{ flex: 1, minWidth: '120px' }}
          />
          <button className="btn ghost" onClick={addLog}>
            <Ic d={ICONS.clock} size={14} /> Внести часы
          </button>
        </div>
      ) : (
        <div className="mut sm">{readOnly ? "Учёт часов для архивных задач недоступен." : "Часы вносит только исполнитель задачи."}</div>
      )}
      <div className="mut sm" style={{ marginTop: 8 }}>
        {f.plannedHours ? `Часы не могут превышать плановые: доступно ещё ${Math.max(0, f.plannedHours - sp)} ч.` : "Плановые часы не заданы — ограничение не применяется."}
        {canLog && <span> · Выберите дату, за которую вносятся часы (не позже сегодня).</span>}
      </div>
    </div>
  );
}