// components/Modals/HoursRequestModal.jsx
import React from 'react';
import { Modal } from '../Modal';
import { FormRenderer } from '../forms/FormRenderer';
import { required, positiveNumber } from '../../utils/validation';
import { uid } from '../../utils/date';

const schema = (kind, target, currentValue) => [
  {
    name: 'oldH',
    label: 'Текущее значение',
    type: 'text',
    props: { disabled: true },
  },
  {
    name: 'newH',
    label: 'Новое значение *',
    type: 'text',
    required: true,
    rules: { ...required('Укажите новое значение'), ...positiveNumber() },
    props: { type: 'number', min: 0.5, step: 0.5 },
  },
  {
    name: 'reason',
    label: 'Обоснование *',
    type: 'textarea',
    required: true,
    rules: required('Обоснуйте запрос'),
    props: { rows: 3, placeholder: 'Почему требуется изменение…' },
  },
];

export const HoursRequestModal = ({ db, ur, kind, targetId, onClose, onSubmit }) => {
  const target = kind === "task" ? db.tasks.find(t => t.id === targetId) : db.projects.find(p => p.id === targetId);
  const cur = kind === "task" ? target?.plannedHours : target?.budget;

  const defaultValues = {
    oldH: cur ?? '—',
    newH: cur || '',
    reason: '',
  };

  const handleSubmit = (data) => {
    const request = {
      id: uid(),
      kind,
      targetId,
      oldH: cur,
      newH: +data.newH,
      reason: data.reason.trim(),
      reqId: ur.id,
      status: "pending",
      ts: Date.now(),
    };
    onSubmit(request);
  };

  return (
    <Modal title={`Запрос изменения часов — ${kind === "task" ? "задача" : "бюджет проекта"}`} onClose={onClose} width={480}>
      <p className="mut sm">{kind === "task" ? target?.title : target?.name}. Запрос будет направлен генеральному директору.</p>
      <FormRenderer
        schema={schema(kind, target, cur)}
        defaultValues={defaultValues}
        onSubmit={handleSubmit}
        onCancel={onClose}
        submitLabel="Отправить запрос"
      />
    </Modal>
  );
};