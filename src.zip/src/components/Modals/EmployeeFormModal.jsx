// components/Modals/EmployeeFormModal.jsx
import React from 'react';
import { Modal } from '../Modal';
import { FormRenderer } from '../forms/FormRenderer';
import { getEmployeeFormSchema } from '../../schemas/employeeFormSchema';
import { useServices } from '../../context/ServicesContext';
import { useToast } from '../../context/ToastContext';
import { useFormContext } from 'react-hook-form';
import { ROLES } from '../../utils/constants';

const DepartmentsField = ({ control, disabled, db }) => {
  const { watch, setValue } = useFormContext();
  const departments = watch('departments') || [];

  const addDept = (deptId) => {
    if (!deptId) return;
    if (departments.some(d => d.deptId === deptId)) return;
    const newDepts = [...departments, { deptId, primary: departments.length === 0 }];
    setValue('departments', newDepts);
  };

  const removeDept = (deptId) => {
    const filtered = departments.filter(d => d.deptId !== deptId);
    if (filtered.length && !filtered.some(d => d.primary)) {
      filtered[0].primary = true;
    }
    setValue('departments', filtered);
  };

  const setPrimary = (deptId) => {
    setValue('departments', departments.map(d => ({ ...d, primary: d.deptId === deptId })));
  };

  return (
    <div style={{ gridColumn: '2' }}>
      <div className="duo" style={{ marginBottom: 6 }}>
        <select
          className="inp sel"
          value=""
          onChange={(e) => { addDept(e.target.value); e.target.value = ''; }}
          disabled={disabled}
          style={{ width: 'auto', flex: 1 }}
        >
          <option value="">— выберите отдел —</option>
          {db.departments.map(d => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {departments.map(d => {
          const dept = db.departments.find(x => x.id === d.deptId);
          return dept ? (
            <span key={d.deptId} className={`dept-chip${d.primary ? ' prim' : ''}`}>
              {dept.name} {d.primary && "★"}
              <button type="button" onClick={() => setPrimary(d.deptId)} className="link" style={{ marginLeft: 4, fontSize: 10 }}>осн.</button>
              <button type="button" onClick={() => removeDept(d.deptId)} className="link red-link" style={{ marginLeft: 4, fontSize: 10 }}>×</button>
            </span>
          ) : null;
        })}
      </div>
    </div>
  );
};

const RolesField = ({ control, disabled, db }) => {
  const { watch, setValue } = useFormContext();
  const roles = watch('roles') || [];
  const kbIds = watch('kbIds') || [];
  const headDeptIds = watch('headDeptIds') || [];

  const toggleRole = (role) => {
    if (roles.includes(role)) {
      setValue('roles', roles.filter(r => r !== role));
    } else {
      setValue('roles', [...roles, role]);
    }
  };

  return (
    <div style={{ gridColumn: '2' }}>
      <div className="sub-picks" style={{ paddingLeft: 0 }}>
        {Object.entries(ROLES).map(([key, val]) => (
          <label key={key} className="dept-pick">
            <input type="checkbox" checked={roles.includes(key)} onChange={() => toggleRole(key)} disabled={disabled} />
            <span className="role-chip" style={{ background: val.color + "1e", color: val.color }}>{val.short}</span> {val.label}
          </label>
        ))}
      </div>

      {roles.includes('kb_chief') && (
        <>
          <label className="lbl" style={{ marginTop: 8 }}>КБ для главного конструктора</label>
          <div className="sub-picks" style={{ paddingLeft: 0 }}>
            {db.kbs.map(kb => (
              <label key={kb.id} className="dept-pick">
                <input
                  type="checkbox"
                  checked={kbIds.includes(kb.id)}
                  onChange={() => {
                    const ids = kbIds.includes(kb.id) ? kbIds.filter(id => id !== kb.id) : [...kbIds, kb.id];
                    setValue('kbIds', ids);
                  }}
                  disabled={disabled}
                />
                {kb.name}
              </label>
            ))}
          </div>
        </>
      )}

      {roles.includes('head') && (
        <>
          <label className="lbl" style={{ marginTop: 8 }}>Отделы для руководителя</label>
          <div className="sub-picks" style={{ paddingLeft: 0 }}>
            {db.departments.map(d => (
              <label key={d.id} className="dept-pick">
                <input
                  type="checkbox"
                  checked={headDeptIds.includes(d.id)}
                  onChange={() => {
                    const ids = headDeptIds.includes(d.id) ? headDeptIds.filter(id => id !== d.id) : [...headDeptIds, d.id];
                    setValue('headDeptIds', ids);
                  }}
                  disabled={disabled}
                />
                {d.name}
              </label>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export const EmployeeFormModal = ({ db, setDb, ur, initialEmployee, onClose }) => {
  const services = useServices();
  const { showToast } = useToast();
  const isEdit = !!initialEmployee;

  const defaultValues = initialEmployee ? {
    last: initialEmployee.last || "",
    first: initialEmployee.first || "",
    email: initialEmployee.email || "",
    pass: "",
    position: initialEmployee.position || "Сотрудник",
    departments: initialEmployee.departments || [],
    roles: initialEmployee.roles || ["executor"],
    kbIds: initialEmployee.kbIds || [],
    headDeptIds: initialEmployee.headDeptIds || [],
    phone: initialEmployee.phone || "",
    extension: initialEmployee.extension || "",
    tab: initialEmployee.tab || "",
  } : {
    last: "",
    first: "",
    email: "",
    pass: "",
    position: "Сотрудник",
    departments: [],
    roles: ["executor"],
    kbIds: [],
    headDeptIds: [],
    phone: "",
    extension: "",
    tab: "",
  };

  const onSubmit = (data) => {
    if (!data.last.trim()) { showToast("Фамилия обязательна", "err"); return; }
    if (!data.first.trim()) { showToast("Имя обязательно", "err"); return; }
    if (!data.email.trim()) { showToast("E-mail обязателен", "err"); return; }
    const existing = db.employees.find(e =>
      e.email.toLowerCase() === data.email.trim().toLowerCase() &&
      (isEdit ? e.id !== initialEmployee.id : true)
    );
    if (existing) {
      showToast("Сотрудник с таким e-mail уже существует", "err");
      return;
    }
    if (!isEdit && (!data.pass || data.pass.length < 8)) {
      showToast("Пароль должен быть не менее 8 символов", "err");
      return;
    }
    if (data.departments.length === 0) { showToast("Добавьте хотя бы одно подразделение", "err"); return; }
    if (!data.departments.some(d => d.primary)) { showToast("Укажите основное подразделение", "err"); return; }

    try {
      let employeeData = {
        last: data.last.trim(),
        first: data.first.trim(),
        email: data.email.trim().toLowerCase(),
        position: data.position.trim() || "Сотрудник",
        departments: data.departments,
        roles: data.roles,
        kbIds: data.roles.includes("kb_chief") ? data.kbIds : [],
        headDeptIds: data.roles.includes("head") ? data.headDeptIds : [],
        phone: data.phone || "",
        extension: data.extension || "",
        tab: data.tab || "",
      };
      if (isEdit) {
        if (data.pass && data.pass.length >= 8) {
          employeeData.pass = data.pass;
        }
        services.employee.updateEmployee(initialEmployee.id, employeeData);
        showToast("Данные сотрудника обновлены");
      } else {
        employeeData.pass = data.pass;
        services.employee.createEmployee(employeeData);
        showToast("Сотрудник создан");
      }
      onClose();
    } catch (error) {
      showToast(error.message, 'err');
    }
  };

  const schema = getEmployeeFormSchema(db, isEdit);

  const renderCustomFields = ({ control, disabled }) => (
    <>
      <label className="lbl" style={{ gridColumn: '1' }}>Подразделения *</label>
      <DepartmentsField control={control} disabled={disabled} db={db} />
      <label className="lbl" style={{ gridColumn: '1' }}>Роли</label>
      <RolesField control={control} disabled={disabled} db={db} />
    </>
  );

  return (
    <Modal title={isEdit ? "Редактирование сотрудника" : "Добавить сотрудника"} onClose={onClose} width={640}>
      <FormRenderer
        schema={schema}
        defaultValues={defaultValues}
        onSubmit={onSubmit}
        onCancel={onClose}
        renderCustomFields={renderCustomFields}
        submitLabel={isEdit ? "Сохранить изменения" : "Создать сотрудника"}
      />
    </Modal>
  );
};