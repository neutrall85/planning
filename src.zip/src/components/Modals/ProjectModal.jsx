// components/Modals/ProjectModal.jsx
import React, { useState, useMemo } from 'react';
import { Modal } from '../Modal';
import { FileUploader } from '../FileUploader';
import { FormRenderer } from '../forms/FormRenderer';
import { getProjectFormSchema } from '../../schemas/projectFormSchema';
import { useDataHelpers } from '../../hooks';
import { PROJECT_STATUSES, TASK_STATUSES } from '../../utils/constants';
import { TODAY, iso, addDays, uid, fmtDT, fmtDMY } from '../../utils/date';
import { hasRole, computeScope, canEditProjectFields, canChangeProjectStatus, canCreateProject } from '../../utils/permissions';
import { Ic, ICONS } from '../Icons';
import Discussion from '../Discussion';
import { projectParticipants } from '../../utils/mention';
import { useToast } from '../../context/ToastContext';
import { useConfirm } from '../../context/ConfirmContext';
import { useServices } from '../../context/ServicesContext';

export const ProjectModal = ({ db, ur, projectId, onClose, onSave, onDelete, openTask, store }) => {
  const services = useServices();
  const { showToast } = useToast();
  const { showConfirm } = useConfirm();
  const existing = projectId ? services.project.getProject(projectId) : null;
  const { empName, getTaskSpent } = useDataHelpers(db);
  const scope = computeScope(ur, db);
  const isExec = !scope.all && !hasRole(ur, 'director', 'economist', 'kb_chief', 'head', 'project_lead');

  const [tab, setTab] = useState('info');

  const defaultValues = existing ? { ...existing } : {
    id: "p_" + uid(),
    code: "",
    name: "",
    desc: "",
    kbId: "",
    managerId: "",
    start: TODAY,
    end: iso(addDays(new Date(), 30)),
    status: "active",
    budget: 100,
    color: ["#0ea5e9", "#8b5cf6", "#f43f5e", "#f59e0b", "#10b981", "#ec4899"][Math.floor(Math.random() * 6)],
    ptype: "prod",
    longterm: false,
    archived: false,
    archivedAt: null,
    closedAt: null,
    creatorId: ur.id,
    customer: "",
    aircraftType: "",
    projectType: "",
    comments: existing?.comments || [],
    history: existing?.history || [{ ts: Date.now(), who: ur.id, text: "Проект создан" }],
    files: existing?.files || [],
  };

  const isNew = !existing;
  const readOnly = !!existing?.archived;
  const canEditFields = isNew ? canCreateProject(ur) : canEditProjectFields(ur, defaultValues);
  const canChangeStatus = isNew ? canCreateProject(ur) : canChangeProjectStatus(ur, defaultValues, defaultValues.status);
  const isAdminType = defaultValues.ptype === "admin";

  const onSubmit = (data) => {
    if (!data.name.trim()) {
      showToast("Укажите название проекта", "err");
      return;
    }
    if (!data.code.trim()) {
      showToast("Укажите код проекта", "err");
      return;
    }
    if (!data.start) {
      showToast("Укажите дату начала", "err");
      return;
    }
    if (!isAdminType) {
      if (!data.customer?.trim()) {
        showToast("Укажите заказчика", "err");
        return;
      }
      if (!data.aircraftType) {
        showToast("Выберите тип ВС", "err");
        return;
      }
      if (!data.projectType) {
        showToast("Выберите тип проекта", "err");
        return;
      }
      if (!data.managerId) {
        showToast("Для производственного проекта ответственный обязателен", "err");
        return;
      }
      if (!data.end) {
        showToast("Для производственного проекта дата окончания обязательна", "err");
        return;
      }
      if (!data.budget || +data.budget <= 0) {
        showToast("Для производственного проекта бюджет обязателен", "err");
        return;
      }
    }

    try {
      let saved;
      const projectData = {
        ...data,
        kbId: data.kbId || null,
        budget: isAdminType ? null : +data.budget,
        managerId: isAdminType ? (data.managerId || "") : data.managerId,
        end: isAdminType ? (data.end || null) : data.end,
        longterm: isAdminType ? !!data.longterm : false,
        files: data.files,
      };
      if (existing) {
        saved = services.project.updateProject(projectId, projectData);
      } else {
        saved = services.project.createProject(projectData);
      }
      onSave(saved, !existing);
    } catch (error) {
      showToast(error.message, 'err');
    }
  };

  const taskList = useMemo(() => {
    if (!existing) return [];
    let list = db.tasks.filter(t => t.projectId === projectId);
    if (!existing.archived) {
      list = list.filter(t => !t.archived);
    }
    if (isExec) {
      list = list.filter(t => (t.assigneeIds || []).includes(ur.id));
    }
    return list;
  }, [db, projectId, ur.id, isExec, existing]);

  const handleDelete = () => {
    showConfirm(`Удалить проект "${defaultValues.name}"? Все связанные задачи также будут удалены.`, () => {
      services.project.deleteProject(defaultValues.id);
      onDelete(defaultValues);
      showToast('Проект удалён');
    });
  };

  const handleFilesChange = (updatedFiles) => {
    const newProject = { ...defaultValues, files: updatedFiles };
    if (store && existing) {
      store.upsertProject(newProject);
    }
  };

  const canManageFiles = !readOnly && (hasRole(ur, 'admin', 'director', 'project_manager') || (existing && existing.managerId === ur.id));

  const schema = getProjectFormSchema(db, ur, isAdminType, canEditFields, readOnly);

  return (
    <Modal title={existing ? (canEditFields ? "Проект (Редактирование)" : "Проект (Просмотр)") : "Новый проект"} onClose={onClose} width={900}>
      {readOnly && <div className="info-box">Этот проект находится в архиве. Редактирование недоступно.</div>}

      <div className="tabs sm">
        <button className={`tab${tab === 'info' ? ' on' : ''}`} onClick={() => setTab('info')}>Информация</button>
        <button className={`tab${tab === 'tasks' ? ' on' : ''}`} onClick={() => setTab('tasks')}>Задачи ({taskList.length})</button>
        <button className={`tab${tab === 'discussion' ? ' on' : ''}`} onClick={() => setTab('discussion')}>Обсуждение ({defaultValues.comments?.length || 0})</button>
        <button className={`tab${tab === 'files' ? ' on' : ''}`} onClick={() => setTab('files')}>Файлы ({defaultValues.files?.length || 0})</button>
      </div>

      {tab === 'info' && (
        <>
          {existing && (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
              gap: '12px',
              marginBottom: '16px',
              padding: '12px',
              background: '#f8fafc',
              borderRadius: '10px',
              border: '1px solid var(--line)'
            }}>
              <div><div className="mut sm">Задач</div><div style={{ fontSize: '20px', fontWeight: 700 }}>{taskList.length}</div></div>
              <div><div className="mut sm">Плановые часы</div><div style={{ fontSize: '20px', fontWeight: 700 }}>{taskList.reduce((sum, t) => sum + (t.plannedHours || 0), 0)}</div></div>
              <div><div className="mut sm">Фактические часы</div><div style={{ fontSize: '20px', fontWeight: 700 }}>{taskList.reduce((sum, t) => sum + getTaskSpent(t), 0)}</div></div>
              <div><div className="mut sm">Прогресс</div><div style={{ fontSize: '20px', fontWeight: 700 }}>{(() => { const totalPlan = taskList.reduce((s, t) => s + (t.plannedHours || 0), 0); const totalFact = taskList.reduce((s, t) => s + getTaskSpent(t), 0); return totalPlan ? Math.round((totalFact / totalPlan) * 100) + '%' : '—'; })()}</div></div>
              <div><div className="mut sm">Исполнителей</div><div style={{ fontSize: '20px', fontWeight: 700 }}>{new Set(taskList.flatMap(t => t.assigneeIds || [])).size}</div></div>
            </div>
          )}

          <FormRenderer
            schema={schema}
            defaultValues={defaultValues}
            onSubmit={onSubmit}
            onCancel={onClose}
            disabled={readOnly || !canEditFields}
            submitLabel={isNew ? "Создать проект" : "Сохранить изменения"}
            hideDefaultActions={readOnly || !(canEditFields || canChangeStatus)}
            renderActions={({ disabled }) => (
              <>
                {existing && hasRole(ur, 'admin') && !readOnly && (
                  <button type="button" className="btn danger" onClick={handleDelete}>
                    <Ic d={ICONS.trash} size={14} /> Удалить
                  </button>
                )}
                {readOnly && <span className="mut sm">Режим только для чтения</span>}
              </>
            )}
          />

          {existing && existing.history?.length > 0 && (
            <div className="mut sm" style={{ marginTop: '12px', borderTop: '1px solid var(--line)', paddingTop: '12px' }}>
              Создан: {(() => {
                const creatorId = existing.history.find(h => h.who !== 'system')?.who || existing.history[0]?.who;
                const creator = creatorId ? db.employees.find(e => e.id === creatorId) : null;
                return `${creator ? creator.last + ' ' + creator.first : '—'}, ${fmtDT(existing.history[0].ts)}`;
              })()}
            </div>
          )}
        </>
      )}

      {tab === 'tasks' && (
        <div className="tm-block" style={{ marginTop: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <div className="rep-panel-title">Задачи проекта ({taskList.length})</div>
            <button className="btn primary sm" onClick={() => openTask(null, 'form', projectId)} disabled={readOnly}>
              <Ic d={ICONS.plus} size={14} /> Создать задачу
            </button>
          </div>
          <div style={{ width: '100%', overflowX: 'auto' }}>
            <table className="tbl" style={{ minWidth: 800, fontSize: 13 }}>
              <thead><tr><th>Задача</th><th>Исполнители</th><th>Статус</th><th>План (ч)</th><th>Факт (ч)</th><th>Остаток</th><th>Создал</th><th>Дедлайн</th></tr></thead>
              <tbody>
                {taskList.map(t => {
                  const assignees = (t.assigneeIds || []).map(id => db.employees.find(e => e.id === id)).filter(Boolean);
                  const creatorId = t.history?.length > 0 ? t.history.find(h => h.who !== 'system')?.who || t.history[0]?.who : null;
                  const creator = creatorId ? db.employees.find(e => e.id === creatorId) : null;
                  const spent = getTaskSpent(t);
                  const remaining = (t.plannedHours || 0) - spent;
                  return (
                    <tr key={t.id} style={{ cursor: 'pointer' }} onClick={() => { onClose(); openTask(t.id); }}>
                      <td><b>{t.title}</b></td>
                      <td>{assignees.map(a => `${a.last} ${a.first}`).join(', ') || '—'}</td>
                      <td><span className="st-chip" style={{ background: TASK_STATUSES[t.status].color + '22', color: TASK_STATUSES[t.status].color }}>{TASK_STATUSES[t.status].label}</span></td>
                      <td>{t.plannedHours ?? '—'}</td>
                      <td>{spent}</td>
                      <td style={{ color: remaining < 0 ? '#dc2626' : 'var(--mut)' }}>{t.plannedHours ? remaining : '—'}</td>
                      <td className="mut sm">{creator ? `${creator.last} ${creator.first}` : 'Система'}</td>
                      <td className="mut sm">{t.deadline ? fmtDMY(t.deadline) : '—'}</td>
                    </tr>
                  );
                })}
                {taskList.length === 0 && <tr><td colSpan="8" className="mut" style={{ textAlign: 'center' }}>Нет задач</td></tr>}
              </tbody>
            </table>
          </div>
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </div>
      )}

      {tab === 'discussion' && (
        <div style={{ marginTop: 8 }}>
          {!existing ? (
            <div className="info-box">Сохраните проект, чтобы начать обсуждение.</div>
          ) : (
            <Discussion
              comments={defaultValues.comments}
              onAddComment={(newComment, parentId, updatedComments) => {
                if (updatedComments) {
                  const newProject = { ...defaultValues, comments: updatedComments };
                  if (store) store.upsertProject(newProject);
                  return;
                }
                const newComments = [...defaultValues.comments, newComment];
                const newProject = { ...defaultValues, comments: newComments };
                if (store) store.upsertProject(newProject);
                showToast("Комментарий добавлен");
              }}
              candidates={existing ? projectParticipants(db, defaultValues.id).filter(e => e.id !== ur.id) : []}
              currentUser={ur}
              db={db}
              readOnly={readOnly || !existing}
              toast={showToast}
              projectId={defaultValues.id}
            />
          )}
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </div>
      )}

      {tab === 'files' && (
        <>
          <FileUploader
            files={defaultValues.files}
            onFilesChange={handleFilesChange}
            canUpload={!readOnly && canManageFiles}
            canDelete={!readOnly && canManageFiles}
            db={db}
            currentUser={ur}
            label="Выбрать файл"
            showSize
          />
          <div className="modal-foot">
            <div className="spacer" />
            <button className="btn ghost" onClick={onClose}>Закрыть</button>
          </div>
        </>
      )}
    </Modal>
  );
};