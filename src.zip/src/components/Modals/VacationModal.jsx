// components/Modals/VacationModal.jsx
import React, { useState } from 'react';
import { Modal } from '../Modal';
import { FormRenderer } from '../forms/FormRenderer';
import { getVacationFormSchema } from '../../schemas/vacationFormSchema';
import { useDataHelpers } from '../../hooks';
import { TASK_STATUSES } from '../../utils/constants';
import { TODAY, iso, addDays, uid, fmtDMY } from '../../utils/date';
import { canManageAllVacations } from '../../utils/permissions';
import { useServices } from '../../context/ServicesContext';
import { useToast } from '../../context/ToastContext';
import { useFormContext } from 'react-hook-form';

const DelegationField = ({ control, disabled, db, empName, primaryDept }) => {
  const { watch, setValue } = useFormContext();
  const delegationEnabled = watch('delegation_enabled');

  return (
    <div className="tm-block" style={{ marginTop: 0, gridColumn: '1 / -1' }}>
      <label className="roles-item" style={{ border: 'none', padding: 0 }}>
        <input
          type="checkbox"
          checked={delegationEnabled}
          onChange={(e) => setValue('delegation_enabled', e.target.checked)}
          disabled={disabled}
        />
        <b>Делегировать задачи на время отпуска</b>
      </label>
      {delegationEnabled && (
        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <label className="lbl" style={{ marginTop: 0 }}>Замещающий сотрудник *</label>
          <select
            className="inp sel"
            value={watch('delegation_subId') || ''}
            onChange={(e) => setValue('delegation_subId', e.target.value)}
            disabled={disabled}
            style={{ borderColor: !watch('delegation_subId') ? '#dc2626' : '' }}
          >
            <option value="">— выберите —</option>
            {db.employees
              .filter(e => e.id !== watch('empId'))
              .map(e => (
                <option key={e.id} value={e.id}>{empName(e.id)} — {primaryDept(e)?.name || ""}</option>
              ))}
          </select>
          {!watch('delegation_subId') && (
            <div className="error-message show" style={{ color: '#dc2626', fontSize: 12 }}>Выберите замещающего сотрудника</div>
          )}
          <label className="lbl" style={{ marginTop: 8 }}>Какие задачи делегировать</label>
          <div className="sub-picks">
            {["new", "inwork", "review"].map((st) => (
              <label key={st} className="dept-pick">
                <input
                  type="checkbox"
                  checked={watch('delegation_statuses')?.includes(st) || false}
                  onChange={(e) => {
                    const current = watch('delegation_statuses') || [];
                    const newVal = e.target.checked ? [...current, st] : current.filter(x => x !== st);
                    setValue('delegation_statuses', newVal);
                  }}
                  disabled={disabled}
                />
                {TASK_STATUSES[st].label}
              </label>
            ))}
            <span className="mut sm">пусто = все активные задачи</span>
          </div>
          <p className="mut sm" style={{ marginTop: 6 }}>Делегирование утверждает руководитель до начала отпуска. Задачи вернутся автоматически после окончания отпуска.</p>
        </div>
      )}
    </div>
  );
};

export const VacationModal = ({ db, ur, vacationId, forEmpId, onClose, onSave }) => {
  const services = useServices();
  const { showToast } = useToast();
  const existing = vacationId ? services.vacation.getVacation(vacationId) : null;
  const canPick = canManageAllVacations(ur);
  const { empName, primaryDept } = useDataHelpers(db);

  const defaultValues = existing ? { ...existing, delegation_enabled: existing.delegation.enabled } : {
    id: "v_" + uid(),
    empId: forEmpId || ur.id,
    start: TODAY,
    end: iso(addDays(new Date(), 7)),
    type: "annual",
    comment: "",
    status: canManageAllVacations(ur) && forEmpId ? "approved" : "pending",
    delegation_enabled: false,
    delegation_subId: "",
    delegation_statuses: [],
  };

  const [error, setError] = useState('');

  const onSubmit = (data) => {
    setError('');
    if (!data.start || !data.end || data.end < data.start) {
      setError('Даты указаны некорректно');
      return;
    }
    if (data.delegation_enabled && !data.delegation_subId) {
      setError('Для делегирования необходимо выбрать замещающего сотрудника');
      return;
    }
    try {
      const vacationData = {
        ...data,
        delegation: {
          enabled: data.delegation_enabled,
          subId: data.delegation_subId || "",
          statuses: data.delegation_statuses || [],
          state: null,
        },
      };
      delete vacationData.delegation_enabled;
      delete vacationData.delegation_subId;
      delete vacationData.delegation_statuses;

      let saved;
      if (existing) {
        saved = services.vacation.updateVacation(vacationId, vacationData);
      } else {
        saved = services.vacation.createVacation(vacationData);
      }
      onSave(saved, !existing);
    } catch (error) {
      setError(error.message);
    }
  };

  const schema = getVacationFormSchema(db, ur, canPick, canManageAllVacations(ur));

  const renderCustomFields = ({ control, disabled }) => (
    <DelegationField
      control={control}
      disabled={disabled}
      db={db}
      empName={empName}
      primaryDept={primaryDept}
    />
  );

  return (
    <Modal title={existing ? "Отпуск" : "Новый отпуск"} onClose={onClose} width={560}>
      {error && <div className="login-err">{error}</div>}
      <FormRenderer
        schema={schema}
        defaultValues={defaultValues}
        onSubmit={onSubmit}
        onCancel={onClose}
        renderCustomFields={renderCustomFields}
        submitLabel="Сохранить"
      />
    </Modal>
  );
};