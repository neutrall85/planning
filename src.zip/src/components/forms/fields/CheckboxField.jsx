import React from 'react';
import { Controller } from 'react-hook-form';

export const CheckboxField = ({ name, control, rules, ...props }) => {
  return (
    <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field }) => (
        <input type="checkbox" checked={!!field.value} onChange={e => field.onChange(e.target.checked)} {...props} />
      )}
    />
  );
};