import React from 'react';
import { Controller } from 'react-hook-form';

export const DateField = ({ name, control, rules, hint, ...props }) => {
  const id = `field-${name}`;
  return (
    <div className="field-wrapper">
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <>
            <input id={id} type="date" className={`inp ${error ? 'error' : ''}`} {...field} {...props} />
            {error && <div className="error-message">{error.message}</div>}
            {hint && <div className="mut sm hint">{hint}</div>}
          </>
        )}
      />
    </div>
  );
};