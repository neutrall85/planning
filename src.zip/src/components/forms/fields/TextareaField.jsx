import React from 'react';
import { Controller } from 'react-hook-form';

export const TextareaField = ({ name, control, rules, hint, rows = 2, ...props }) => {
  const id = `field-${name}`;
  return (
    <div className="field-wrapper">
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <>
            <textarea id={id} className={`inp ${error ? 'error' : ''}`} rows={rows} {...field} {...props} />
            {error && <div className="error-message">{error.message}</div>}
            {hint && <div className="mut sm hint">{hint}</div>}
          </>
        )}
      />
    </div>
  );
};