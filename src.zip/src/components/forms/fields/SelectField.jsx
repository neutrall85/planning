import React from 'react';
import { Controller } from 'react-hook-form';

export const SelectField = ({ name, control, rules, options, hint, ...props }) => {
  const id = `field-${name}`;
  return (
    <div className="field-wrapper">
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <>
            <select
              id={id}
              className={`inp sel ${error ? 'error' : ''}`}
              {...field}
              value={field.value ?? ''}
              {...props}
            >
              {options.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            {error && <div className="error-message">{error.message}</div>}
            {hint && <div className="mut sm hint">{hint}</div>}
          </>
        )}
      />
    </div>
  );
};