// components/forms/AssigneeList.jsx
import React, { useState } from 'react';
import { useFieldArray, Controller } from 'react-hook-form';

export const AssigneeList = ({
  name,
  control,
  options,
  disabled,
  label,
  multiple = true,
  placeholder = "— выберите —",
}) => {
  const { fields, append, remove, replace } = useFieldArray({ control, name });
  const [showAdd, setShowAdd] = useState(false);
  const [selectedNew, setSelectedNew] = useState('');

  const availableOptions = options.filter(
    (o) => !fields.some((f) => f.value === o.value)
  );

  const addAssignee = () => {
    if (!selectedNew) return;
    if (fields.some((f) => f.value === selectedNew)) return;
    if (multiple) {
      append(selectedNew);
    } else {
      replace([selectedNew]);
    }
    setSelectedNew('');
    setShowAdd(false);
  };

  const cancelAdd = () => {
    setShowAdd(false);
    setSelectedNew('');
  };

  const removeAssignee = (index) => {
    if (!multiple && fields.length === 1) return;
    remove(index);
  };

  const getOption = (value) => options.find((o) => o.value === value);

  return (
    <div style={{ gridColumn: '2' }}>
      {label && <label className="lbl">{label}</label>}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {fields.map((field, index) => {
            const opt = getOption(field.value);
            const name = opt?.label || field.value;
            const dept = opt?.dept || '';
            return (
              <span
                key={field.id}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  background: '#e2e8f0',
                  padding: '4px 8px 4px 12px',
                  borderRadius: '12px',
                  fontSize: '13px',
                  gap: '6px',
                }}
              >
                {name}{dept && ` — ${dept}`}
                {!disabled && (
                  <button
                    type="button"
                    onClick={() => removeAssignee(index)}
                    style={{
                      border: 'none',
                      background: 'transparent',
                      color: '#dc2626',
                      cursor: 'pointer',
                      fontSize: '16px',
                      lineHeight: 1,
                      padding: '0 2px',
                    }}
                  >
                    ×
                  </button>
                )}
              </span>
            );
          })}
          {fields.length === 0 && (
            <span className="mut sm">Не выбрано</span>
          )}
        </div>

        {!disabled && (
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            {showAdd ? (
              <>
                <select
                  className="inp sel"
                  value={selectedNew}
                  onChange={(e) => setSelectedNew(e.target.value)}
                  style={{ flex: 1 }}
                >
                  <option value="">{placeholder}</option>
                  {availableOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}{opt.dept && ` — ${opt.dept}`}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  className="btn primary sm"
                  onClick={addAssignee}
                  disabled={!selectedNew}
                >
                  Добавить
                </button>
                <button
                  type="button"
                  className="btn ghost sm"
                  onClick={cancelAdd}
                >
                  Отмена
                </button>
              </>
            ) : (
              <button
                type="button"
                className="btn ghost sm"
                onClick={() => setShowAdd(true)}
                disabled={availableOptions.length === 0}
              >
                + {multiple ? 'Добавить исполнителя' : 'Выбрать ответственного'}
              </button>
            )}
          </div>
        )}
        {!disabled && availableOptions.length === 0 && fields.length > 0 && (
          <div className="mut sm">
            {multiple ? 'Все доступные исполнители уже добавлены' : 'Доступных сотрудников нет'}
          </div>
        )}
      </div>
    </div>
  );
};