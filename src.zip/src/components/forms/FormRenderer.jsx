import React from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { TextField, SelectField, DateField, CheckboxField, TextareaField } from './fields';

const fieldComponents = {
  text: TextField,
  select: SelectField,
  date: DateField,
  checkbox: CheckboxField,
  textarea: TextareaField,
};

export const FormRenderer = ({
  schema,
  defaultValues,
  onSubmit,
  onCancel,
  submitLabel = 'Сохранить',
  cancelLabel = 'Отмена',
  disabled = false,
  renderCustomFields = null,
  hideDefaultActions = false,
  renderActions = null,
}) => {
  const methods = useForm({ defaultValues, mode: 'onChange' });
  const { handleSubmit, control } = methods;

  const renderField = (fieldDef) => {
    const FieldComponent = fieldComponents[fieldDef.type];
    if (FieldComponent) {
      const fieldProps = {
        ...fieldDef.props,
        name: fieldDef.name,
        control,
        rules: fieldDef.rules,
        hint: fieldDef.hint,
        disabled: disabled || fieldDef.disabled,
      };
      const colSpan = fieldDef.fullWidth ? '1 / -1' : '2';
      const key = fieldDef.name;

      if (fieldDef.label && fieldDef.type !== 'checkbox') {
        return (
          <React.Fragment key={key}>
            <label className="lbl" style={{ gridColumn: '1', alignSelf: 'center' }}>
              {fieldDef.label}{fieldDef.required && ' *'}
            </label>
            <div style={{ gridColumn: colSpan }}>
              <FieldComponent key={key} {...fieldProps} />
            </div>
          </React.Fragment>
        );
      } else if (fieldDef.type === 'checkbox') {
        return (
          <div key={key} style={{ gridColumn: colSpan, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FieldComponent key={key} {...fieldProps} />
            {fieldDef.label && <span>{fieldDef.label}</span>}
          </div>
        );
      } else {
        return (
          <div key={key} style={{ gridColumn: colSpan }}>
            <FieldComponent key={key} {...fieldProps} />
          </div>
        );
      }
    }
    if (fieldDef.type === 'custom' && fieldDef.render) {
      return (
        <React.Fragment key={fieldDef.name}>
          {fieldDef.label && <label className="lbl" style={{ gridColumn: '1' }}>{fieldDef.label}</label>}
          <div style={{ gridColumn: '2' }}>
            {fieldDef.render({ control, disabled: disabled || fieldDef.disabled, value: fieldDef.defaultValue })}
          </div>
        </React.Fragment>
      );
    }
    return null;
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="form-grid">
          {schema.map(renderField)}
          {renderCustomFields && renderCustomFields({ control, disabled })}
        </div>
        <div className="modal-foot">
          <div className="spacer" />
          {renderActions && renderActions({ disabled })}
          {!hideDefaultActions && (
            <>
              <button type="button" className="btn ghost" onClick={onCancel}>{cancelLabel}</button>
              <button type="submit" className="btn primary" disabled={disabled}>{submitLabel}</button>
            </>
          )}
        </div>
      </form>
    </FormProvider>
  );
};