import React from 'react';
import { Controller } from 'react-hook-form';

export const RepeatConfig = ({ control, disabled }) => {
  const repeatType = useWatch({ control, name: 'repeatType' });
  return (
    <div className="tm-block" style={{ marginTop: '12px' }}>
      <div className="rep-panel-title">Повторение</div>
      <div className="form-grid" style={{ gridTemplateColumns: '150px 1fr' }}>
        <Controller
          name="repeatType"
          control={control}
          render={({ field }) => (
            <>
              <label className="lbl">Тип повторения</label>
              <select {...field} className="inp sel" disabled={disabled}>
                <option value="none">Нет</option>
                <option value="daily">Ежедневно</option>
                <option value="weekly_days">Еженедельно по дням</option>
                <option value="workdays">Каждый рабочий день</option>
                <option value="monthly">Ежемесячно</option>
                <option value="yearly">Ежегодно</option>
                <option value="custom">Произвольно (через N дней)</option>
              </select>
            </>
          )}
        />
        {repeatType === 'custom' && (
          <>
            <label className="lbl">Интервал (дней)</label>
            <Controller
              name="repeatInterval"
              control={control}
              render={({ field }) => <input {...field} type="number" min="1" className="inp" disabled={disabled} />}
            />
          </>
        )}
        {repeatType === 'weekly_days' && (
          <>
            <label className="lbl">Дни недели</label>
            <div className="duo" style={{ flexWrap: 'wrap', gap: '6px' }}>
              {['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map((day, idx) => {
                const dayNum = idx + 1;
                return (
                  <Controller
                    key={dayNum}
                    name="repeatDays"
                    control={control}
                    render={({ field }) => (
                      <label className="dept-pick">
                        <input
                          type="checkbox"
                          checked={field.value?.includes(String(dayNum))}
                          onChange={(e) => {
                            const newDays = e.target.checked
                              ? [...(field.value || []), String(dayNum)]
                              : (field.value || []).filter(d => d !== String(dayNum));
                            field.onChange(newDays);
                          }}
                          disabled={disabled}
                        />
                        {day}
                      </label>
                    )}
                  />
                );
              })}
            </div>
          </>
        )}
        {repeatType !== 'none' && (
          <>
            <label className="lbl">Окончание</label>
            <div className="duo" style={{ display: 'flex', gap: '8px' }}>
              <Controller
                name="repeatEndType"
                control={control}
                render={({ field }) => (
                  <select {...field} className="inp sel" style={{ width: '120px' }} disabled={disabled}>
                    <option value="date">По дате</option>
                    <option value="count">По количеству</option>
                  </select>
                )}
              />
              <Controller
                name="repeatEndValue"
                control={control}
                render={({ field }) =>
                  field.value?.endType === 'date' ? (
                    <input {...field} type="date" className="inp" style={{ flex: 1 }} disabled={disabled} />
                  ) : (
                    <input {...field} type="number" min="1" className="inp" placeholder="кол-во" style={{ width: '100px' }} disabled={disabled} />
                  )
                }
              />
              <span className="mut sm">всего {repeatType === 'count' ? 'задач' : ''}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};