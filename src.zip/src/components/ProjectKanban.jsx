// components/ProjectKanban.jsx
import React, { useMemo } from 'react';
import KanbanBoard from './KanbanBoard';
import { PROJECT_STATUSES, PROJECT_TYPES } from '../utils/constants';
import { fmtDMY, initials } from '../utils/date';
import { Ic, ICONS } from './Icons';
import { hasRole, canChangeProjectStatus, canCloseProject } from '../utils/permissions';

const PROJECT_STATUS_ORDER = ['inactive', 'active', 'closed', 'cancelled'];

// Вспомогательная функция для вычисления статистики проекта (не хук)
function computeProjectStats(project, db) {
  const tasks = (db.tasks || []).filter(t => t.projectId === project.id && !t.archived);
  const plan = tasks.reduce((s, t) => s + (t.plannedHours || 0), 0);
  const fact = tasks.reduce((s, t) => s + (t.logs || []).reduce((lsum, l) => lsum + l.hours, 0), 0);
  const usePct = project.budget ? Math.round((fact / Math.max(1, project.budget)) * 100) : 0;
  const uniqueAssignees = [...new Set(tasks.flatMap(t => t.assigneeIds || []))];
  const manager = project.managerId ? db.employees.find(e => e.id === project.managerId) : null;
  return { tasks, plan, fact, usePct, uniqueAssignees, manager };
}

export default function ProjectKanban({ projects = [], db, ur, openProject, closeProject, cancelProject, moveProject }) {
  // Обогащаем проекты статистикой один раз
  const projectsWithStats = useMemo(() => {
    return projects.map(project => ({
      ...project,
      stats: computeProjectStats(project, db),
    }));
  }, [projects, db]);

  const renderCard = (project) => {
    const { plan, fact, usePct, uniqueAssignees, manager } = project.stats;

    return (
      <>
        <div className="kcard-title">{project.name}</div>
        <div className="kcard-proj">
          <span className="pdot" style={{ background: project.color }} />
          {project.code}
        </div>
        <div style={{ fontSize: '11px', color: 'var(--mut)', marginTop: '2px' }}>
          {project.customer && <div>Заказчик: {project.customer}</div>}
          {project.start && (
            <div>Сроки: {fmtDMY(project.start)} — {project.end ? fmtDMY(project.end) : '…'}</div>
          )}
          {manager && <div>Ответственный: {manager.last} {manager.first}</div>}
          {project.stage && <div>Стадия: {project.stage}</div>}
        </div>
        <div className="kcard-meta">
          <span className="mut sm">{PROJECT_TYPES[project.ptype || 'prod']}</span>
          {project.budget != null && (
            <span className="khours">
              <Ic d={ICONS.clock} size={13} /> {fact}/{project.budget} ч ({usePct}%)
            </span>
          )}
        </div>
        <div className="kcard-foot">
          <div className="pj-avatars" style={{ flex: 1 }}>
            {uniqueAssignees.slice(0, 4).map(id => {
              const a = (db.employees || []).find(e => e.id === id);
              return a ? (
                <span key={id} className="avatar xs" title={`${a.last} ${a.first}`}>
                  {a.photo ? (
                    <img src={a.photo} alt="Аватар" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                  ) : (
                    initials(a.first, a.last)
                  )}
                </span>
              ) : null;
            })}
            {uniqueAssignees.length > 4 && <span className="mut sm">+{uniqueAssignees.length - 4}</span>}
          </div>
          <div className="pj-actions" onClick={(e) => e.stopPropagation()}>
            {canCloseProject(ur, project) && project.status !== 'closed' && project.status !== 'cancelled' && (
              <button
                className="icon-btn danger"
                title="Закрыть/Отменить проект"
                onClick={() => {
                  const action = window.confirm(`Закрыть проект "${project.name}"? Все задачи проекта будут закрыты.`) 
                    ? 'close' 
                    : (window.confirm(`Отменить проект "${project.name}"? Все задачи проекта будут отменены.`) ? 'cancel' : null);
                  if (action === 'close') closeProject(project);
                  else if (action === 'cancel') cancelProject(project);
                }}
              >
                <Ic d={ICONS.x} size={15} />
              </button>
            )}
          </div>
        </div>
      </>
    );
  };

  const canDragProject = (project) => canChangeProjectStatus(ur, project, project.status);

  return (
    <KanbanBoard
      items={projectsWithStats}
      statusOrder={PROJECT_STATUS_ORDER}
      statusConfig={PROJECT_STATUSES}
      renderCard={renderCard}
      onDrop={moveProject}
      onCardClick={openProject}
      renderFilters={null}
      db={db}
      ur={ur}
      canDrag={canDragProject}
      emptyText="Нет проектов"
    />
  );
}