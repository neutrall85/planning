import { ICONS, Ic } from '../Icons';
import NotifPanel from '../NotifPanel';

export default function Topbar({ 
  view, 
  navItems, 
  user, 
  notifOpen, 
  setNotifOpen, 
  notifRef, 
  myNotifs, 
  handleNotificationNavigate, 
  onVacationClick,
  onHelpClick,      // новый проп
  setDb             // для NotifPanel
}) {
  const unread = myNotifs.filter(n => !n.read).length;

  return (
    <header className="topbar">
      <div>
        <h1 className="page-title">{navItems.find(n => n.id === view)?.label || 'Личный кабинет'}</h1>
        <div className="page-sub">Вторник, 4 августа 2026 · вы вошли как {user.last} {user.first}</div>
      </div>
      <div className="top-tools">
        <button className="btn ghost" onClick={onVacationClick}>
          <Ic d={ICONS.beach} size={15} /> Сотрудники в отпусках
        </button>
        <button className="icon-btn" onClick={onHelpClick} title="Справка">
          <Ic d={ICONS.help} size={17} />
        </button>
        <div className="bell-wrap" ref={notifRef}>
          <button className={`icon-btn bell${unread ? ' has' : ''}`} onClick={() => setNotifOpen(v => !v)}>
            <Ic d={ICONS.bell} size={17} />
            {unread > 0 && <span className="bell-count">{unread}</span>}
          </button>
          {notifOpen && (
            <NotifPanel
              list={myNotifs}
              setDb={setDb}
              onNavigate={handleNotificationNavigate}
              onClose={() => setNotifOpen(false)}
            />
          )}
        </div>
      </div>
    </header>
  );
}