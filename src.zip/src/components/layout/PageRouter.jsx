// components/layout/PageRouter.jsx
import React from 'react';
import { Ic, ICONS } from '../Icons';
import { TODAY } from '../../utils/date';
import Gantt from '../Gantt';
import Calendar from '../Calendar';
import Cabinet from '../Cabinet';
import Staff from '../Staff';
import Reports from '../reports/Reports';
import Archive from '../Archive';
import Requests from '../Requests';
import Journal from '../Journal';
import TasksView from '../task/TasksView';
import ProjectsView from '../ProjectsView';

export default function PageRouter({
  view,
  data,
  user,
  openTask,
  openProject,
  openHoursReq,
  openRoles,
  openDepts,
  openVacation,
  openDelegation,
  handleMoveTask,
  store,
  requestsTab,
  setRequestsTab,
  restoreTask,
  restoreProject,
  closeProject,
  cancelProject,
  moveProject,
}) {
  switch (view) {
    case 'tasks':
      return <TasksView db={data} ur={user} openTask={openTask} onMove={handleMoveTask} onNew={() => openTask(null)} />;
    case 'projects':
      return (
        <ProjectsView
          db={data}
          ur={user}
          openProject={openProject}
          closeProject={closeProject}
          cancelProject={cancelProject}
          moveProject={moveProject}
          openHoursReq={openHoursReq}
        />
      );
    case 'gantt':
      return <Gantt db={data} ur={user} openTask={openTask} openProject={openProject} patchTask={store.upsertTask} />;
    case 'calendar':
      return <Calendar db={data} ur={user} openTask={openTask} />;
    case 'cabinet':
      return <Cabinet store={store} data={data} user={user} openTask={openTask} openVacation={openVacation} openDelegation={openDelegation} />;
    case 'staff':
      return <Staff db={data} ur={user} setDb={(fn) => { store._data = fn(store._data); store._notify(); }} openRoles={openRoles} openDepts={openDepts} openVacation={openVacation} />;
    case 'reports':
      return <Reports db={data} ur={user} />;
    case 'archive':
      return <Archive db={data} ur={user} openTask={openTask} openProject={openProject} restoreTask={restoreTask} restoreProject={restoreProject} />;
    case 'requests':
      return <Requests db={data} setDb={(fn) => { store._data = fn(store._data); store._notify(); }} ur={user} initialTab={requestsTab} addAudit={store.addAudit.bind(store)} />;
    case 'journal':
      return <Journal db={data} ur={user} />;
    default:
      return <div>Страница не найдена</div>;
  }
}