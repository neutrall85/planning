import { ICONS, Ic } from '../Icons';
import { initials } from '../../utils/date';

export default function Sidebar({ navItems, view, setView, user, logout }) {
  return (
    <aside className="sidebar">
      <div className="logo">
        <div className="logo-mark">АП</div>
        <div>
          <div className="logo-name">АвиаГоризонт</div>
          <div className="logo-sub">планирование и учёт времени</div>
        </div>
      </div>
      <div className="user-card" onClick={() => setView('cabinet')} style={{ cursor: 'pointer', marginBottom: '16px' }}>
        <div className="avatar">
          {user.photo ? (
            <img src={user.photo} alt="Аватар" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
          ) : (
            initials(user.first, user.last)
          )}
        </div>
        <div className="user-meta">
          <div className="user-name">{user.last} {user.first}</div>
          <div className="user-roles">{user.roles.join(' · ')}</div>
        </div>
        <button className="icon-btn dark" onClick={(e) => { e.stopPropagation(); logout(); }} title="Выйти">
          <Ic d={ICONS.out} size={16} />
        </button>
      </div>
      <nav className="nav">
        {navItems.map(n => (
          <button key={n.id} className={`nav-item${view === n.id ? ' on' : ''}`} onClick={() => setView(n.id)}>
            <Ic d={n.icon} /> <span className="nav-lbl">{n.label}</span>
          </button>
        ))}
      </nav>
      <div className="side-foot">
        <div className="env-badge"><Ic d={ICONS.shield} size={14} /> Демо · заглушка Java/PostgreSQL</div>
      </div>
    </aside>
  );
}