// components/Modals/ModalRenderer.jsx
import { TaskModal, ProjectModal, HoursRequestModal, RolesModal, DeptsModal, VacationModal, DelegationModal, VacNowModal } from '../Modals';
import { hasRole } from '../../utils/permissions';
import { ROLES } from '../../utils/constants';

export default function ModalRenderer({
  modal,
  setModal,
  data,
  user,
  store,
  openTask,
  openHoursReq,
  empName,
  planSum,
  spent,
  toast,
  vacModalOpen,
  setVacModalOpen,
}) {
  if (!modal && !vacModalOpen) return null;

  if (vacModalOpen) {
    return <VacNowModal db={data} onClose={() => setVacModalOpen(false)} toast={toast} />;
  }

  switch (modal.type) {
    case 'task':
      return (
        <TaskModal
          db={data}
          ur={user}
          taskId={modal.taskId}
          initialTab={modal.initialTab}
          presetProjectId={modal.projectId}
          planSum={planSum}
          spent={spent}
          onClose={() => setModal(null)}
          onSave={(t, isNew) => {
            store.upsertTask(t);
            if (isNew) {
              (t.assigneeIds || []).forEach(id => {
                if (id !== user.id) {
                  store.addNotification(id, `Вам назначена задача "${t.title}" (проект ${data.projects.find(p => p.id === t.projectId)?.code || '—'}).`, { targetType: 'task', targetId: t.id });
                }
              });
            }
            setModal(null);
          }}
          onDelete={(id) => {
            store.deleteTask(id);
            setModal(null);
          }}
          onHoursReq={openHoursReq}
          toast={toast}
          patchTask={(task) => store.upsertTask(task)}   // ← обёртка для сохранения контекста
          notify={store.addNotification}
          store={store}
        />
      );

    case 'project':
      return (
        <ProjectModal
          db={data}
          ur={user}
          projectId={modal.projectId}
          openTask={openTask}
          onClose={() => setModal(null)}
          onSave={(p) => {
            store.upsertProject(p);
            setModal(null);
          }}
          onDelete={(p) => {
            store.deleteProject(p.id);
            setModal(null);
          }}
          toast={toast}
          store={store}
        />
      );

    case 'hours':
      return (
        <HoursRequestModal
          db={data}
          ur={user}
          kind={modal.kind}
          targetId={modal.targetId}
          onClose={() => setModal(null)}
          onSubmit={(r) => {
            store.addHoursRequest(r);
            let authorId = null;
            if (modal.kind === 'task') {
              const task = data.tasks.find(t => t.id === modal.targetId);
              if (task) authorId = task.creatorId || (task.history?.length > 0 ? task.history[0].who : null);
            } else if (modal.kind === 'project') {
              const project = data.projects.find(p => p.id === modal.targetId);
              if (project) authorId = project.creatorId || (project.history?.length > 0 ? project.history[0].who : null);
            }
            if (authorId) {
              const target = modal.kind === 'task' ? data.tasks.find(t => t.id === modal.targetId) : data.projects.find(p => p.id === modal.targetId);
              store.addNotification(authorId, `Запрос на изменение часов по ${modal.kind === 'task' ? 'задаче' : 'проекту'} "${target?.title || target?.name || ''}" от ${user.last} ${user.first}.`, { targetType: 'hours', targetId: r.id });
            }
            store.addAudit('Запрос изменения часов', {
              target: modal.kind === 'task' ? data.tasks.find(t => t.id === modal.targetId)?.title : data.projects.find(p => p.id === modal.targetId)?.name,
              oldH: r.oldH,
              newH: r.newH,
            }, 'hoursRequest', r.id);
            setModal(null);
          }}
        />
      );

    case 'roles':
      return (
        <RolesModal
          db={data}
          setDb={(fn) => { store._data = fn(store._data); store._notify(); }}
          empId={modal.empId}
          onClose={() => setModal(null)}
          toast={toast}
          audit={store.addAudit}
        />
      );

    case 'depts':
      return (
        <DeptsModal
          db={data}
          setDb={(fn) => { store._data = fn(store._data); store._notify(); }}
          empId={modal.empId}
          onClose={() => setModal(null)}
          toast={toast}
          audit={store.addAudit}
        />
      );

    case 'vacation':
      return (
        <VacationModal
          db={data}
          ur={user}
          vacationId={modal.vacationId}
          forEmpId={modal.forEmpId || null}
          onClose={() => setModal(null)}
          onSave={(v) => {
            store.upsertVacation(v);
            setModal(null);
          }}
        />
      );

    case 'delegation':
      return (
        <DelegationModal
          db={data}
          ur={user}
          onClose={() => setModal(null)}
          onSubmit={(rd) => {
            store.upsertRoleDelegation(rd);
            store.addNotification(rd.toId, `Вам предложено временное принятие ролей: ${rd.roles.map(r => ROLES[r].label).join(", ")}.`, { targetType: 'delegation', targetId: rd.id });
            setModal(null);
          }}
        />
      );

    default:
      return null;
  }
}