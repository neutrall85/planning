// components/reports/Reports.jsx
import React, { useState, useMemo, useEffect } from 'react';
import { useDataHelpers } from '../../hooks';
import { computeScope } from '../../utils/permissions';
import { useFilteredTasks } from '../../hooks/useFilteredTasks';
import { useFilteredProjects } from '../../hooks/useFilteredProjects';
import ReportFilters from './ReportFilters';
import SavedFilters from './SavedFilters';
import TasksReportTable from './TasksReportTable';
import ProjectsReportTable from './ProjectsReportTable';
import EmployeesReportTable from './EmployeesReportTable';
import WorklogReportTable from './WorklogReportTable';
import { REPORT_TYPES } from './constants';
import { Ic, ICONS } from '../Icons';

export default function Reports({ db, ur }) {
  const { empName, getTaskSpent, getProjectStats } = useDataHelpers(db);
  const scope = useMemo(() => computeScope(ur, db), [ur, db]);
  const safeDb = useMemo(() => {
    if (!db) return { projects: [], tasks: [], employees: [], departments: [], kbs: [], vacations: [] };
    return db;
  }, [db]);

  const [filters, setFilters] = useState({
    type: 'tasks',
    dateFrom: '',
    dateTo: '',
    deadlineFrom: '',
    deadlineTo: '',
    projectId: 'all',
    assigneeId: 'all',
    status: 'all',
    priority: 'all',
    aircraftType: 'all',
    projectType: 'all',
    stage: 'all',
    customer: '',
  });

  const [savedFilters, setSavedFilters] = useState(() => {
    try {
      const data = localStorage.getItem('savedReportFilters');
      return data ? JSON.parse(data) : [];
    } catch { return []; }
  });

  const [results, setResults] = useState([]);

  const taskFilters = useMemo(() => ({
    search: '',
    projectId: filters.projectId,
    assigneeId: filters.assigneeId,
    priority: filters.priority,
    deptId: 'all',
    showOnlyMy: false,
  }), [filters.projectId, filters.assigneeId, filters.priority]);

  const projectFilters = useMemo(() => ({
    search: '',
    aircraftType: filters.aircraftType,
    projectType: filters.projectType,
    stage: filters.stage,
    customer: filters.customer,
    status: 'all',
    showOnlyMy: false,
  }), [filters.aircraftType, filters.projectType, filters.stage, filters.customer]);

  const filteredTasks = useFilteredTasks(db, ur, taskFilters);
  const filteredProjects = useFilteredProjects(db, ur, projectFilters);

  const applyFilters = () => {
    const type = filters.type;
    if (type === 'tasks') {
      let tasks = filteredTasks;
      if (filters.dateFrom || filters.dateTo) {
        tasks = tasks.filter(t => {
          if (!t.createdAt) return false;
          if (filters.dateFrom && t.createdAt < filters.dateFrom) return false;
          if (filters.dateTo && t.createdAt > filters.dateTo) return false;
          return true;
        });
      }
      if (filters.deadlineFrom || filters.deadlineTo) {
        tasks = tasks.filter(t => {
          if (!t.deadline) return false;
          if (filters.deadlineFrom && t.deadline < filters.deadlineFrom) return false;
          if (filters.deadlineTo && t.deadline > filters.deadlineTo) return false;
          return true;
        });
      }
      if (filters.status !== 'all') tasks = tasks.filter(t => t.status === filters.status);
      setResults(tasks);
    } else if (type === 'projects') {
      let projects = filteredProjects;
      if (filters.dateFrom) projects = projects.filter(p => p.start >= filters.dateFrom);
      if (filters.dateTo) projects = projects.filter(p => p.start <= filters.dateTo);
      if (filters.deadlineFrom) projects = projects.filter(p => p.end && p.end >= filters.deadlineFrom);
      if (filters.deadlineTo) projects = projects.filter(p => p.end && p.end <= filters.deadlineTo);
      if (filters.status !== 'all') projects = projects.filter(p => p.status === filters.status);
      setResults(projects);
    } else if (type === 'employees') {
      let employees = db.employees;
      if (filters.projectId !== 'all') {
        const taskIds = db.tasks.filter(t => t.projectId === filters.projectId).map(t => t.id);
        employees = employees.filter(e =>
          db.tasks.some(t => t.assigneeIds?.includes(e.id) && taskIds.includes(t.id))
        );
      }
      if (filters.assigneeId !== 'all') employees = employees.filter(e => e.id === filters.assigneeId);
      setResults(employees);
    } else if (type === 'worklog') {
      let logs = [];
      db.tasks.forEach(t => {
        (t.logs || []).forEach(l => {
          logs.push({ ...l, taskTitle: t.title, projectId: t.projectId, assigneeIds: t.assigneeIds || [] });
        });
      });
      if (filters.dateFrom) logs = logs.filter(l => l.date >= filters.dateFrom);
      if (filters.dateTo) logs = logs.filter(l => l.date <= filters.dateTo);
      if (filters.projectId !== 'all') logs = logs.filter(l => l.projectId === filters.projectId);
      if (filters.assigneeId !== 'all') logs = logs.filter(l => l.userId === filters.assigneeId);
      setResults(logs);
    }
  };

  useEffect(() => {
    applyFilters();
  }, [filters, filteredTasks, filteredProjects, db, ur, scope]);

  const handleFilterChange = (key, value) => setFilters(prev => ({ ...prev, [key]: value }));
  const resetFilters = () => setFilters({
    type: filters.type,
    dateFrom: '', dateTo: '', deadlineFrom: '', deadlineTo: '',
    projectId: 'all', assigneeId: 'all', status: 'all', priority: 'all',
    aircraftType: 'all', projectType: 'all', stage: 'all', customer: ''
  });

  const saveFilter = (name) => {
    if (!name.trim()) return alert('Введите название фильтра');
    const newFilter = { id: Date.now(), name: name.trim(), filters: { ...filters } };
    const updated = [...savedFilters, newFilter];
    setSavedFilters(updated);
    localStorage.setItem('savedReportFilters', JSON.stringify(updated));
  };

  const loadFilter = (filter) => setFilters(filter.filters);
  const deleteFilter = (id) => {
    const updated = savedFilters.filter(f => f.id !== id);
    setSavedFilters(updated);
    localStorage.setItem('savedReportFilters', JSON.stringify(updated));
  };

  const downloadXLSX = () => {
    if (results.length === 0) return alert('Нет данных для выгрузки');
    alert(`Выгрузка XLSX пока не реализована. Данных: ${results.length} строк`);
  };

  const renderTable = () => {
    const type = filters.type;
    if (results.length === 0) return <div className="empty-note" style={{ padding: '20px 0' }}>Нет данных</div>;
    switch (type) {
      case 'tasks': return <TasksReportTable tasks={results} db={safeDb} empName={empName} getTaskSpent={getTaskSpent} />;
      case 'projects': return <ProjectsReportTable projects={results} getProjectStats={getProjectStats} empName={empName} db={safeDb} />;
      case 'employees': return <EmployeesReportTable employees={results} db={safeDb} getTaskSpent={getTaskSpent} />;
      case 'worklog': return <WorklogReportTable logs={results} db={safeDb} empName={empName} />;
      default: return null;
    }
  };

  return (
    <div className="rep">
      <ReportFilters
        filters={filters}
        onFilterChange={handleFilterChange}
        onReset={resetFilters}
        onApply={applyFilters}
        visibleProjects={scope.all ? safeDb.projects : safeDb.projects.filter(p => scope.projIds.has(p.id))}
        visibleEmployees={scope.all ? safeDb.employees : safeDb.employees.filter(e => scope.empIds.has(e.id))}
        reportTypes={REPORT_TYPES}
        saveFilter={saveFilter}
      />
      <SavedFilters savedFilters={savedFilters} loadFilter={loadFilter} deleteFilter={deleteFilter} db={safeDb} />
      <div className="rep-panel" style={{ padding: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <div className="rep-panel-title" style={{ marginBottom: 0 }}>Результаты ({results.length})</div>
          <button className="btn primary sm" onClick={downloadXLSX} disabled={results.length === 0}>
            <Ic d={ICONS.download} size={13} /> Выгрузить XLSX
          </button>
        </div>
        {renderTable()}
      </div>
    </div>
  );
}