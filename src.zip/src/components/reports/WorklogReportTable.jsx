import { fmtDMY } from '../../utils/date';

export default function WorklogReportTable({ logs, db, empName }) {
  return (
    <div style={{ width: '100%', overflowX: 'auto' }}>
      <table className="tbl" style={{ minWidth: '700px', fontSize: '13px' }}>
        <thead>
          <tr>
            <th>#</th>
            <th>Дата</th>
            <th>Сотрудник</th>
            <th>Задача</th>
            <th>Проект</th>
            <th>Часы</th>
            <th>Комментарий</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l, idx) => {
            const project = db.projects?.find(p => p.id === l.projectId);
            const user = db.employees?.find(e => e.id === l.userId);
            return (
              <tr key={idx}>
                <td>{idx + 1}</td>
                <td>{fmtDMY(l.date)}</td>
                <td>{user ? `${user.last} ${user.first}` : '—'}</td>
                <td>{l.taskTitle}</td>
                <td>{project?.code || '—'}</td>
                <td><b>{l.hours}</b></td>
                <td>{l.note || '—'}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}