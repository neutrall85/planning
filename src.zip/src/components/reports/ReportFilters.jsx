import React, { useState } from 'react';
import { TASK_STATUSES, PRIORITIES } from '../../utils/constants';
import { Ic, ICONS } from '../Icons';
import { fmtDMY } from '../../utils/date';

const AIRCRAFT_TYPES = ['Все', 'Су-57', 'МиГ-35', 'Ту-160', 'Ил-76', 'Ка-52', 'Другой'];
const PROJECT_TYPE_OPTIONS = ['Все', 'Ремонт', 'Модификация'];
const STAGES = ['Все', 'Эскизный проект', 'Рабочая документация', 'Изготовление', 'Испытания', 'Сдача'];

export default function ReportFilters({ filters, onFilterChange, onReset, onApply, visibleProjects, visibleEmployees, reportTypes, saveFilter }) {
  const [filterName, setFilterName] = useState('');
  const type = filters.type;
  const showDateRange = type !== 'employees';
  const showDeadlineRange = type === 'tasks' || type === 'projects';
  const showStatusPriority = type === 'tasks';
  const showWorklogDates = type === 'worklog';
  const showProjectDates = type === 'projects';

  const handleSave = () => {
    saveFilter(filterName);
    setFilterName('');
  };

  return (
    <div className="rep-panel" style={{ padding: '16px' }}>
      <div className="rep-panel-title">Фильтры отчёта</div>

      <div className="toolbar" style={{ marginBottom: '8px' }}>
        <label className="lbl" style={{ margin: 0 }}>Тип отчёта:</label>
        <div className="seg">
          {reportTypes.map(typeOption => (
            <button key={typeOption.value} className={`seg-btn${filters.type === typeOption.value ? ' on' : ''}`} onClick={() => onFilterChange('type', typeOption.value)}>
              {typeOption.label}
            </button>
          ))}
        </div>
      </div>

      <div className="toolbar" style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
        {showDateRange && (
          <>
            <label className="lbl" style={{ margin: 0 }}>{showWorklogDates ? 'Дата записи:' : showProjectDates ? 'Начало:' : 'Создан с:'}</label>
            <input className="inp" type="date" value={filters.dateFrom} onChange={e => onFilterChange('dateFrom', e.target.value)} style={{ width: '150px' }} />
            <span>—</span>
            <input className="inp" type="date" value={filters.dateTo} onChange={e => onFilterChange('dateTo', e.target.value)} style={{ width: '150px' }} />
          </>
        )}

        {showDeadlineRange && (
          <>
            <label className="lbl" style={{ margin: 0 }}>{showProjectDates ? 'Окончание:' : 'Дедлайн:'}</label>
            <input className="inp" type="date" value={filters.deadlineFrom} onChange={e => onFilterChange('deadlineFrom', e.target.value)} style={{ width: '150px' }} />
            <span>—</span>
            <input className="inp" type="date" value={filters.deadlineTo} onChange={e => onFilterChange('deadlineTo', e.target.value)} style={{ width: '150px' }} />
          </>
        )}

        <label className="lbl" style={{ margin: 0 }}>Проект:</label>
        <select className="inp sel" value={filters.projectId} onChange={e => onFilterChange('projectId', e.target.value)} style={{ width: '180px' }}>
          <option value="all">Все проекты</option>
          {visibleProjects.map(p => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
        </select>

        <label className="lbl" style={{ margin: 0 }}>Исполнитель:</label>
        <select className="inp sel" value={filters.assigneeId} onChange={e => onFilterChange('assigneeId', e.target.value)} style={{ width: '180px' }}>
          <option value="all">Все</option>
          {visibleEmployees.map(e => <option key={e.id} value={e.id}>{e.last} {e.first}</option>)}
        </select>
      </div>

      <div className="toolbar" style={{ marginTop: '8px', display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
        <label className="lbl" style={{ margin: 0 }}>Тип ВС:</label>
        <select className="inp sel" value={filters.aircraftType} onChange={e => onFilterChange('aircraftType', e.target.value)} style={{ width: '140px' }}>
          {AIRCRAFT_TYPES.map(t => <option key={t} value={t === 'Все' ? 'all' : t}>{t}</option>)}
        </select>

        <label className="lbl" style={{ margin: 0 }}>Тип проекта:</label>
        <select className="inp sel" value={filters.projectType} onChange={e => onFilterChange('projectType', e.target.value)} style={{ width: '140px' }}>
          {PROJECT_TYPE_OPTIONS.map(t => <option key={t} value={t === 'Все' ? 'all' : t}>{t}</option>)}
        </select>

        <label className="lbl" style={{ margin: 0 }}>Стадия:</label>
        <select className="inp sel" value={filters.stage} onChange={e => onFilterChange('stage', e.target.value)} style={{ width: '160px' }}>
          {STAGES.map(s => <option key={s} value={s === 'Все' ? 'all' : s}>{s}</option>)}
        </select>

        <label className="lbl" style={{ margin: 0 }}>Заказчик:</label>
        <input className="inp" type="text" value={filters.customer} onChange={e => onFilterChange('customer', e.target.value)} placeholder="поиск по названию" style={{ width: '200px' }} />

        {showStatusPriority && (
          <>
            <label className="lbl" style={{ margin: 0 }}>Статус задачи:</label>
            <select className="inp sel" value={filters.status} onChange={e => onFilterChange('status', e.target.value)} style={{ width: '140px' }}>
              <option value="all">Все</option>
              {Object.keys(TASK_STATUSES).map(st => <option key={st} value={st}>{TASK_STATUSES[st].label}</option>)}
            </select>

            <label className="lbl" style={{ margin: 0 }}>Приоритет:</label>
            <select className="inp sel" value={filters.priority} onChange={e => onFilterChange('priority', e.target.value)} style={{ width: '140px' }}>
              <option value="all">Все</option>
              {Object.keys(PRIORITIES).map(pr => <option key={pr} value={pr}>{PRIORITIES[pr].label}</option>)}
            </select>
          </>
        )}
      </div>

      <div style={{ marginTop: '12px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        <button className="btn primary" onClick={onApply}>Применить</button>
        <button className="btn ghost" onClick={onReset}>Сбросить фильтры</button>
        <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
          <input className="inp" type="text" value={filterName} onChange={e => setFilterName(e.target.value)} placeholder="Название шаблона" style={{ width: '180px' }} />
          <button className="btn ghost" onClick={handleSave}><Ic d={ICONS.plus} size={13} /> Сохранить фильтр</button>
        </div>
      </div>
    </div>
  );
}