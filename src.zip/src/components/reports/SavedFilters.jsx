// components/reports/SavedFilters.jsx
import React from 'react';
import { Ic, ICONS } from '../Icons';
import { fmtDMY } from '../../utils/date';
import { REPORT_TYPES } from './constants';
import { TASK_STATUSES, PRIORITIES } from '../../utils/constants';

export default function SavedFilters({ savedFilters, loadFilter, deleteFilter, db }) {
  if (savedFilters.length === 0) return null;

  return (
    <div className="rep-panel" style={{ padding: '16px' }}>
      <div className="rep-panel-title">Сохранённые шаблоны</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
        {savedFilters.map(f => {
          const criteria = [];
          const typeLabel = REPORT_TYPES.find(t => t.value === f.filters.type)?.label || 'Задачи';
          criteria.push(`Тип: ${typeLabel}`);
          if (f.filters.dateFrom || f.filters.dateTo) {
            const from = f.filters.dateFrom ? fmtDMY(f.filters.dateFrom) : '';
            const to = f.filters.dateTo ? fmtDMY(f.filters.dateTo) : '';
            criteria.push(`Период: ${from} — ${to}`);
          }
          if (f.filters.deadlineFrom || f.filters.deadlineTo) {
            const from = f.filters.deadlineFrom ? fmtDMY(f.filters.deadlineFrom) : '';
            const to = f.filters.deadlineTo ? fmtDMY(f.filters.deadlineTo) : '';
            criteria.push(`Дедлайн: ${from} — ${to}`);
          }
          if (f.filters.projectId !== 'all') {
            const proj = db?.projects?.find(p => p.id === f.filters.projectId);
            criteria.push(`Проект: ${proj?.code || '—'}`);
          }
          if (f.filters.assigneeId !== 'all') {
            const emp = db?.employees?.find(e => e.id === f.filters.assigneeId);
            criteria.push(`Исполнитель: ${emp ? emp.last : '—'}`);
          }
          if (f.filters.status !== 'all') criteria.push(`Статус: ${TASK_STATUSES[f.filters.status]?.label || f.filters.status}`);
          if (f.filters.priority !== 'all') criteria.push(`Приоритет: ${PRIORITIES[f.filters.priority]?.label || f.filters.priority}`);
          if (f.filters.aircraftType !== 'all') criteria.push(`Тип ВС: ${f.filters.aircraftType}`);
          if (f.filters.projectType !== 'all') criteria.push(`Тип проекта: ${f.filters.projectType}`);
          if (f.filters.stage !== 'all') criteria.push(`Стадия: ${f.filters.stage}`);
          if (f.filters.customer) criteria.push(`Заказчик: ${f.filters.customer}`);
          const displayText = criteria.length ? criteria.join(' · ') : 'Все';

          return (
            <div key={f.id} className="pj-card" style={{ minWidth: '200px', maxWidth: '280px', cursor: 'pointer', padding: '12px', position: 'relative' }}>
              <div style={{ fontWeight: '700', fontSize: '14px', marginBottom: '6px' }}>{f.name}</div>
              <div style={{ fontSize: '12px', color: 'var(--mut)', lineHeight: '1.4' }}>{displayText}</div>
              <button className="icon-btn" style={{ position: 'absolute', top: '6px', right: '6px' }} onClick={(e) => { e.stopPropagation(); deleteFilter(f.id); }} title="Удалить шаблон">
                <Ic d={ICONS.x} size={14} />
              </button>
              <div style={{ marginTop: '8px' }}>
                <button className="btn ghost sm" onClick={() => loadFilter(f)}>Загрузить</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}