export default function EmployeesReportTable({ employees, db, getTaskSpent }) {
  return (
    <div style={{ width: '100%', overflowX: 'auto' }}>
      <table className="tbl" style={{ minWidth: '600px', fontSize: '13px' }}>
        <thead>
          <tr>
            <th>#</th>
            <th>Сотрудник</th>
            <th>Отдел (основной)</th>
            <th>План (ч)</th>
            <th>Факт (ч)</th>
            <th>Кол-во задач</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((e, idx) => {
            const dept = (e.departments || []).find(d => d.primary);
            const deptName = dept ? db.departments?.find(d => d.id === dept.deptId)?.name : '—';
            const tasks = db.tasks?.filter(t => t.assigneeIds?.includes(e.id)) || [];
            const plan = tasks.reduce((s, t) => s + (t.plannedHours || 0), 0);
            const fact = tasks.reduce((s, t) => s + getTaskSpent(t), 0);
            return (
              <tr key={e.id}>
                <td>{idx + 1}</td>
                <td><b>{e.last} {e.first}</b></td>
                <td>{deptName}</td>
                <td>{plan}</td>
                <td>{fact}</td>
                <td>{tasks.length}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}