import { PROJECT_STATUSES } from '../../utils/constants';

export default function ProjectsReportTable({ projects, getProjectStats, empName }) {
  return (
    <div style={{ width: '100%', overflowX: 'auto' }}>
      <table className="tbl" style={{ minWidth: '800px', fontSize: '13px' }}>
        <thead>
          <tr>
            <th>#</th>
            <th>Код</th>
            <th>Проект</th>
            <th>Статус</th>
            <th>Заказчик</th>
            <th>Тип ВС</th>
            <th>Тип проекта</th>
            <th>Стадия</th>
            <th>Бюджет (ч)</th>
            <th>План (ч)</th>
            <th>Факт (ч)</th>
            <th>Ответственный</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((p, idx) => {
            const stats = getProjectStats(p.id);
            return (
              <tr key={p.id}>
                <td>{idx + 1}</td>
                <td><b>{p.code}</b></td>
                <td>{p.name}</td>
                <td><span className={`st-chip ${p.status === 'active' ? 'active' : ''}`}>{PROJECT_STATUSES[p.status]?.label || p.status}</span></td>
                <td>{p.customer || '—'}</td>
                <td>{p.aircraftType || '—'}</td>
                <td>{p.projectType || '—'}</td>
                <td>{p.stage || '—'}</td>
                <td>{p.budget ?? '—'}</td>
                <td>{stats.plan}</td>
                <td>{stats.fact}</td>
                <td>{empName(p.managerId)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}