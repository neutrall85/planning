// components/reports/TasksReportTable.jsx
import { TASK_STATUSES, PRIORITIES } from '../../utils/constants';
import { fmtDMY } from '../../utils/date';

export default function TasksReportTable({ tasks, db, empName, getTaskSpent }) {
  return (
    <div style={{ width: '100%', overflowX: 'auto' }}>
      <table className="tbl" style={{ minWidth: '800px', fontSize: '13px' }}>
        <thead>
          <tr>
            <th>#</th>
            <th>Задача</th>
            <th>Проект</th>
            <th>Исполнители</th>
            <th>Статус</th>
            <th>Приоритет</th>
            <th>План (ч)</th>
            <th>Факт (ч)</th>
            <th>Дедлайн</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((t, idx) => {
            const project = db?.projects?.find(p => p.id === t.projectId);
            const statusDef = TASK_STATUSES[t.status] || { label: t.status || 'Неизвестно', color: '#64748b' };
            const priorityDef = PRIORITIES[t.priority] || { label: t.priority || 'Неизвестно', color: '#64748b' };
            return (
              <tr key={t.id}>
                <td>{idx + 1}</td>
                <td><b>{t.title}</b></td>
                <td>{project?.code || '—'}</td>
                <td>{(t.assigneeIds || []).map(id => empName(id)).join(', ') || '—'}</td>
                <td><span className="st-chip" style={{ background: statusDef.color + '22', color: statusDef.color }}>{statusDef.label}</span></td>
                <td><span style={{ color: priorityDef.color }}>{priorityDef.label}</span></td>
                <td>{t.plannedHours ?? '—'}</td>
                <td>{getTaskSpent(t)}</td>
                <td>{t.deadline ? fmtDMY(t.deadline) : '—'}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}