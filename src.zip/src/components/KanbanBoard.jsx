// components/KanbanBoard.jsx
import React, { useState } from 'react';

export default function KanbanBoard({
  items,
  statusOrder,
  statusConfig,
  renderCard,
  onDrop,
  onCardClick,
  renderFilters,
  db,
  ur,
  canDrag,
  emptyText = 'Нет элементов',
}) {
  const [dragOverCol, setDragOverCol] = useState(null);

  const filtersContent = renderFilters ? renderFilters({ db, ur }) : null;

  // Количество колонок определяется количеством статусов
  const numColumns = statusOrder.length;

  return (
    <div>
      {filtersContent && <div className="toolbar">{filtersContent}</div>}
      <div 
        className="kanban" 
        style={{ 
          gridTemplateColumns: `repeat(${numColumns}, minmax(240px, 1fr))` 
        }}
      >
        {statusOrder.map((statusKey) => {
          const list = items.filter((item) => item.status === statusKey);
          const config = statusConfig[statusKey];
          return (
            <div
              key={statusKey}
              className={`kcol${dragOverCol === statusKey ? ' over' : ''}`}
              onDragOver={(e) => { e.preventDefault(); setDragOverCol(statusKey); }}
              onDragLeave={() => setDragOverCol(null)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOverCol(null);
                const id = e.dataTransfer.getData('text/plain');
                if (id && onDrop) {
                  const item = items.find((i) => i.id === id);
                  if (item && canDrag && !canDrag(item)) {
                    alert(`Нет прав на перемещение в статус "${config.label}"`);
                    return;
                  }
                  onDrop(id, statusKey);
                }
              }}
            >
              <div className="kcol-head">
                <span className="kdot" style={{ background: config.color }} />
                {config.label}
                <span className="kcount">{list.length}</span>
              </div>
              <div className="kcol-body">
                {list.length === 0 ? (
                  <div className="kempty">{emptyText}</div>
                ) : (
                  list.map((item) => (
                    <div
                      key={item.id}
                      className="kcard"
                      draggable={canDrag ? canDrag(item) : false}
                      onDragStart={(e) => e.dataTransfer.setData('text/plain', item.id)}
                      onClick={() => onCardClick && onCardClick(item.id)}
                    >
                      {renderCard(item, db, ur)}
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}