// components/Projects.jsx
import React, { useMemo } from 'react';
import { PROJECT_STATUSES, PROJECT_TYPES } from '../utils/constants';
import { fmtDMY, initials } from '../utils/date';
import { Ic, ICONS } from './Icons';
import { hasRole } from '../utils/permissions';
import { useDataHelpers } from '../hooks';

// Вспомогательная функция для вычисления статистики проекта (не хук)
function computeProjectStats(project, db) {
  const tasks = (db.tasks || []).filter(t => t.projectId === project.id && !t.archived);
  const plan = tasks.reduce((s, t) => s + (t.plannedHours || 0), 0);
  const fact = tasks.reduce((s, t) => s + (t.logs || []).reduce((lsum, l) => lsum + l.hours, 0), 0);
  const usePct = project.budget ? Math.round((fact / Math.max(1, project.budget)) * 100) : 0;
  const uniqueAssignees = [...new Set(tasks.flatMap(t => t.assigneeIds || []))];
  const manager = project.managerId ? db.employees.find(e => e.id === project.managerId) : null;
  return { tasks, plan, fact, usePct, uniqueAssignees, manager };
}

export default function Projects({ projects, db, ur, openProject, openHoursReq, closeProject, cancelProject }) {
  const { empName } = useDataHelpers(db);
  const safeProjects = Array.isArray(projects) ? projects : [];

  // Обогащаем проекты статистикой
  const projectsWithStats = useMemo(() => {
    return safeProjects.map(project => ({
      ...project,
      stats: computeProjectStats(project, db),
    }));
  }, [safeProjects, db]);

  const canCloseProject = (project) => {
    const creatorId = project.creatorId || (project.history?.find(h => h.who !== 'system')?.who);
    return hasRole(ur, 'admin') || hasRole(ur, 'director') || (creatorId && creatorId === ur.id);
  };

  return (
    <div className="pj-grid">
      {projectsWithStats.map(p => {
        const { plan, fact, usePct, uniqueAssignees, manager } = p.stats;
        const overPlan = p.budget != null && plan > p.budget;

        return (
          <div key={p.id} className="pj-card" onClick={() => openProject(p.id)} style={{ cursor: 'pointer' }}>
            <div className="pj-top">
              <span className="pj-code" style={{ background: p.color + '22', color: p.color }}>{p.code}</span>
              <span className={`pj-st ${p.status}`}>{PROJECT_STATUSES[p.status].label}</span>
              <span style={{ fontSize: '11px', color: '#64748b' }}>{PROJECT_TYPES[p.ptype || 'prod']}</span>
            </div>
            <div className="pj-name">{p.name}</div>
            <div className="pj-row">
              <span className="mut">Сроки:</span> {fmtDMY(p.start)} — {p.end ? fmtDMY(p.end) : 'не задан'}
            </div>
            {p.customer && (
              <div className="pj-row"><span className="mut">Заказчик:</span> {p.customer}</div>
            )}
            {p.aircraftType && (
              <div className="pj-row"><span className="mut">Тип ВС:</span> {p.aircraftType}</div>
            )}
            {p.stage && (
              <div className="pj-row"><span className="mut">Стадия:</span> {p.stage}</div>
            )}
            {manager && (
              <div className="pj-row"><span className="mut">Ответственный:</span> {manager.last} {manager.first}</div>
            )}
            {p.ptype !== 'admin' && p.budget != null && (
              <div className="pj-budget">
                <div className="pj-budget-row">
                  <span>Бюджет: <b>{p.budget} ч</b></span>
                  <span>План: <b className={overPlan ? 'red' : ''}>{plan} ч</b></span>
                  <span>Факт: <b>{fact} ч</b></span>
                  <span>Использовано: <b>{usePct}%</b></span>
                </div>
                <div className="pj-progress">
                  <div className={`pj-progress-fill${usePct > 100 ? ' over' : ''}`} style={{ width: Math.min(100, usePct) + '%', background: p.color }} />
                </div>
              </div>
            )}
            <div className="pj-foot">
              <div className="pj-avatars">
                {uniqueAssignees.slice(0, 6).map(id => {
                  const a = (db.employees || []).find(e => e.id === id);
                  return a && (
                    <span key={id} className="avatar xs" title={`${a.last} ${a.first}`}>
                      {initials(a.first, a.last)}
                    </span>
                  );
                })}
              </div>
              <div className="pj-actions" onClick={(e) => e.stopPropagation()}>
                {((hasRole(ur, 'project_lead') && p.managerId === ur.id) || hasRole(ur, 'admin', 'director', 'economist', 'kb_chief')) && p.status === 'active' && p.ptype !== 'admin' && (
                  <button className="btn ghost sm" onClick={() => openHoursReq('project', p.id)}>
                    <Ic d={ICONS.clock} size={13} /> Запросить часы
                  </button>
                )}
                {hasRole(ur, 'admin', 'director', 'economist', 'kb_chief') && (
                  <button className="icon-btn" title="Редактировать" onClick={() => openProject(p.id)}>
                    <Ic d={ICONS.edit} size={15} />
                  </button>
                )}
                {canCloseProject(p) && p.status !== 'closed' && p.status !== 'cancelled' && (
                  <button className="icon-btn danger" title="Закрыть/Отменить проект" onClick={(e) => {
                    e.stopPropagation();
                    const action = window.confirm(`Закрыть проект "${p.name}"? Все задачи проекта будут закрыты.`) 
                      ? 'close' 
                      : (window.confirm(`Отменить проект "${p.name}"? Все задачи проекта будут отменены.`) ? 'cancel' : null);
                    if (action === 'close') closeProject(p);
                    else if (action === 'cancel') cancelProject(p);
                  }}>
                    <Ic d={ICONS.x} size={15} />
                  </button>
                )}
              </div>
            </div>
          </div>
        );
      })}
      {projectsWithStats.length === 0 && (
        <div className="empty-note" style={{ gridColumn: '1 / -1' }}>Нет проектов по выбранным фильтрам</div>
      )}
    </div>
  );
}