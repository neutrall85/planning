import React, { useEffect } from 'react';

const Toast = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const bgColor = type === 'err' ? '#fef2f2' : '#f0fdf4';
  const borderColor = type === 'err' ? '#fecaca' : '#bbf7d0';
  const textColor = type === 'err' ? '#dc2626' : '#16a34a';

  return (
    <div style={{
      padding: '12px 20px',
      borderRadius: 8,
      background: bgColor,
      border: `1px solid ${borderColor}`,
      color: textColor,
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      maxWidth: 400,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      animation: 'popIn 0.2s ease',
    }}>
      <span>{message}</span>
      <button onClick={onClose} style={{ marginLeft: 12, border: 'none', background: 'none', cursor: 'pointer', fontSize: 18, color: 'inherit' }}>×</button>
    </div>
  );
};

export const ToastContainer = ({ toasts, removeToast }) => {
  return (
    <div style={{
      position: 'fixed',
      bottom: 20,
      right: 20,
      zIndex: 9999,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
    }}>
      {toasts.map(t => (
        <Toast key={t.id} message={t.message} type={t.type} onClose={() => removeToast(t.id)} />
      ))}
    </div>
  );
};