// components/MainLayout.jsx
import React, { useState } from 'react';
import { useStore } from '../hooks/useStore';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../hooks/useNotifications';
import { useAppActions } from '../hooks/useAppActions';
import { useProjectActions } from '../hooks/useProjectActions';
import { hasRole } from '../utils/permissions';
import { ICONS } from './Icons';
import { useToast } from '../context/ToastContext';
import { useConfirm } from '../context/ConfirmContext';

import Sidebar from './layout/Sidebar';
import Topbar from './layout/Topbar';
import PageRouter from './layout/PageRouter';
import ModalRenderer from './layout/ModalRenderer';
import { Modal } from './Modal';
import HelpContent from './HelpContent';
import { ServicesProvider } from '../providers/ServicesProvider';

export default function MainLayout({ store, data, user }) {
  const { showToast } = useToast();
  const { logout } = useStore();
  const { showConfirm } = useConfirm();
  const [activeView, setActiveView] = useState('tasks');
  const [modal, setModal] = useState(null);
  const [requestsTab, setRequestsTab] = useState('hours');
  const [projectsView, setProjectsView] = useState('kanban');
  const [vacModalOpen, setVacModalOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  const { notifOpen, setNotifOpen, notifRef } = useNotifications();

  const toggleHelp = () => setHelpOpen(v => !v);

  const {
    openTask,
    openProject,
    openHoursReq,
    openRoles,
    openDepts,
    openVacation,
    openDelegation,
    handleMoveTask,
    handleNotificationNavigate,
    empName,
  } = useAppActions({
    store,
    data,
    user,
    setModal,
    setView: setActiveView,
    setRequestsTab,
    showToast,
  });

  const projectActions = useProjectActions(store, data, user, showConfirm, showToast);

  const planSum = (projectId) => {
    return data.tasks
      .filter(t => t.projectId === projectId && !t.archived)
      .reduce((sum, t) => sum + (t.plannedHours || 0), 0);
  };
  const spent = (taskId) => {
    const task = data.tasks.find(t => t.id === taskId);
    if (!task) return 0;
    return (task.logs || []).reduce((s, l) => s + l.hours, 0);
  };

  const restoreTask = (taskId) => {
    const task = data.tasks.find(t => t.id === taskId);
    if (!task) return;
    showConfirm(`Восстановить задачу "${task.title}"?`, () => {
      const updated = { ...task, archived: false, archivedAt: null };
      store.upsertTask(updated);
      store.addAudit('Восстановление задачи', task.title, 'task', taskId);
      showToast(`Задача "${task.title}" восстановлена`);
    });
  };

  const userNotifications = data.notifications
    .filter(n => n.userId === user.id)
    .sort((a, b) => b.ts - a.ts);

  const menuItems = [
    { id: 'tasks', label: 'Задачи', icon: ICONS.file },
    { id: 'projects', label: 'Проекты', icon: ICONS.folder },
    { id: 'gantt', label: 'Диаграмма Ганта', icon: ICONS.gantt },
    { id: 'reports', label: 'Отчёты', icon: ICONS.chart },
    { id: 'calendar', label: 'Календарь', icon: ICONS.cal },
    { id: 'requests', label: 'Запросы', icon: ICONS.inbox },
    { id: 'archive', label: 'Архив', icon: ICONS.archive },
    { id: 'staff', label: 'Сотрудники', icon: ICONS.users },
    { id: 'journal', label: 'Журнал', icon: ICONS.book },
  ];

  const canSee = (id) => {
    if (id === 'admin') return hasRole(user, 'admin');
    if (id === 'requests') return hasRole(user, 'admin', 'director', 'hr', 'economist', 'kb_chief', 'head', 'project_lead', 'project_manager');
    if (id === 'journal') return hasRole(user, 'admin', 'director', 'economist', 'hr', 'kb_chief', 'head', 'project_lead', 'project_manager');
    return true;
  };

  const filteredMenu = menuItems.filter(item => canSee(item.id));

  return (
    <ServicesProvider store={store} user={user}>
      <div className="shell">
        <Sidebar
          navItems={filteredMenu}
          view={activeView}
          setView={setActiveView}
          user={user}
          logout={logout}
        />

        <main className="main">
          <Topbar
            view={activeView}
            navItems={filteredMenu}
            user={user}
            notifOpen={notifOpen}
            setNotifOpen={setNotifOpen}
            notifRef={notifRef}
            myNotifs={userNotifications}
            handleNotificationNavigate={handleNotificationNavigate}
            onVacationClick={() => setVacModalOpen(true)}
            onHelpClick={toggleHelp}
            setDb={(fn) => { store._data = fn(store._data); store._notify(); }}
          />

          <div className="content">
            <PageRouter
              view={activeView}
              data={data}
              user={user}
              openTask={openTask}
              openProject={openProject}
              openHoursReq={openHoursReq}
              openRoles={openRoles}
              openDepts={openDepts}
              openVacation={openVacation}
              openDelegation={openDelegation}
              handleMoveTask={handleMoveTask}
              store={store}
              projectsView={projectsView}
              setProjectsView={setProjectsView}
              requestsTab={requestsTab}
              setRequestsTab={setRequestsTab}
              restoreTask={restoreTask}
              restoreProject={projectActions.restoreProject}
              closeProject={projectActions.closeProject}
              cancelProject={projectActions.cancelProject}
              moveProject={projectActions.moveProject}
            />
          </div>
        </main>

        {helpOpen && (
          <Modal title="Справка по системе" onClose={() => setHelpOpen(false)} width={800}>
            <div style={{ maxHeight: '70vh', overflow: 'auto', padding: '4px 0' }}>
              <HelpContent />
            </div>
          </Modal>
        )}

        <ModalRenderer
          modal={modal}
          setModal={setModal}
          data={data}
          user={user}
          store={store}
          openTask={openTask}
          openHoursReq={openHoursReq}
          empName={empName}
          planSum={planSum}
          spent={spent}
          toast={showToast}
          vacModalOpen={vacModalOpen}
          setVacModalOpen={setVacModalOpen}
        />
      </div>
    </ServicesProvider>
  );
}