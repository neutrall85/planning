// components/ProjectsView.jsx
import React from 'react';
import Projects from './Projects';
import ProjectKanban from './ProjectKanban';
import ProjectFilters from './ProjectFilters';
import { useFilters } from '../hooks/useFilters';
import { useFilteredProjects } from '../hooks/useFilteredProjects';
import { hasRole } from '../utils/permissions';

export default function ProjectsView({
  db,
  ur,
  openProject,
  closeProject,
  cancelProject,
  moveProject,
  openHoursReq,
}) {
  const { filters, setFilter } = useFilters({
    view: 'kanban',
    search: '',
    aircraftType: 'all',
    projectType: 'all',
    stage: 'all',
    customer: 'all',
    status: 'all',
    showOnlyMy: false,
  });

  const projects = useFilteredProjects(db, ur, filters);
  const canSeeAll = hasRole(ur, 'admin', 'director', 'economist', 'kb_chief', 'head', 'project_lead', 'project_manager');
  const canCreateProject = hasRole(ur, 'admin', 'director', 'kb_chief', 'project_manager');

  return (
    <div>
      <ProjectFilters
        view={filters.view}
        setView={(v) => setFilter('view', v)}
        search={filters.search}
        setSearch={(v) => setFilter('search', v)}
        aircraftType={filters.aircraftType}
        setAircraftType={(v) => setFilter('aircraftType', v)}
        projectType={filters.projectType}
        setProjectType={(v) => setFilter('projectType', v)}
        stage={filters.stage}
        setStage={(v) => setFilter('stage', v)}
        customer={filters.customer}
        setCustomer={(v) => setFilter('customer', v)}
        status={filters.status}
        setStatus={(v) => setFilter('status', v)}
        showOnlyMy={filters.showOnlyMy}
        setShowOnlyMy={(v) => setFilter('showOnlyMy', v)}
        projects={projects}
        canSeeAll={canSeeAll}
        canCreateProject={canCreateProject}
        onNew={() => openProject(null)}
      />
      {filters.view === 'kanban' ? (
        <ProjectKanban
          projects={projects}
          db={db}
          ur={ur}
          openProject={openProject}
          closeProject={closeProject}
          cancelProject={cancelProject}
          moveProject={moveProject}
        />
      ) : (
        <Projects
          projects={projects}
          db={db}
          ur={ur}
          openProject={openProject}
          openHoursReq={openHoursReq}
          closeProject={closeProject}
          cancelProject={cancelProject}
        />
      )}
    </div>
  );
}