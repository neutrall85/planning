import React from 'react';
import { Ic, ICONS } from './Icons';
import ViewToggle from './ViewToggle';

export default function ProjectFilters({
  view,
  setView,
  search,
  setSearch,
  aircraftType,
  setAircraftType,
  projectType,
  setProjectType,
  stage,
  setStage,
  customer,
  setCustomer,
  status,
  setStatus,
  showOnlyMy,
  setShowOnlyMy,
  projects,
  canSeeAll,
  canCreateProject,
  onNew,
}) {
  const safeProjects = Array.isArray(projects) ? projects : [];
  const getUnique = (field) => {
    if (!safeProjects.length) return [];
    return [...new Set(safeProjects.map(p => p[field]).filter(Boolean))];
  };

  const statusOptions = [
    { value: 'all', label: 'Все статусы' },
    { value: 'active', label: 'Активный' },
    { value: 'inactive', label: 'Неактивный' },
    { value: 'closed', label: 'Закрыт' },
    { value: 'cancelled', label: 'Отменён' },
  ];

  return (
    <div style={{
      display: 'flex',
      flexWrap: 'nowrap',
      gap: '6px',
      alignItems: 'center',
      overflowX: 'auto',
      paddingBottom: '4px',
      marginBottom: '14px',
      whiteSpace: 'nowrap',
    }}>
      <ViewToggle view={view} setView={setView} />

      <div className="search-box" style={{ flex: '0 0 auto', minWidth: '140px' }}>
        <Ic d={ICONS.search} size={15} />
        <input
          placeholder="Поиск проектов…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: '120px' }}
        />
      </div>

      <select
        className="inp sel sm"
        value={aircraftType}
        onChange={(e) => setAircraftType(e.target.value)}
        style={{ flex: '0 0 auto', width: '130px' }}
      >
        <option value="all">Все типы ВС</option>
        {getUnique('aircraftType').map((val) => (
          <option key={val} value={val}>{val}</option>
        ))}
      </select>

      <select
        className="inp sel sm"
        value={projectType}
        onChange={(e) => setProjectType(e.target.value)}
        style={{ flex: '0 0 auto', width: '130px' }}
      >
        <option value="all">Все типы проекта</option>
        {getUnique('projectType').map((val) => (
          <option key={val} value={val}>{val}</option>
        ))}
      </select>

      <select
        className="inp sel sm"
        value={stage}
        onChange={(e) => setStage(e.target.value)}
        style={{ flex: '0 0 auto', width: '140px' }}
      >
        <option value="all">Все стадии</option>
        {getUnique('stage').map((val) => (
          <option key={val} value={val}>{val}</option>
        ))}
      </select>

      <select
        className="inp sel sm"
        value={customer}
        onChange={(e) => setCustomer(e.target.value)}
        style={{ flex: '0 0 auto', width: '130px' }}
      >
        <option value="all">Все заказчики</option>
        {getUnique('customer').map((val) => (
          <option key={val} value={val}>{val}</option>
        ))}
      </select>

      <select
        className="inp sel sm"
        value={status}
        onChange={(e) => setStatus(e.target.value)}
        style={{ flex: '0 0 auto', width: '130px' }}
      >
        {statusOptions.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>

      {canSeeAll && (
        <label style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <input
            type="checkbox"
            checked={showOnlyMy}
            onChange={(e) => setShowOnlyMy(e.target.checked)}
          />
          <span style={{ fontSize: 13 }}>Только мои</span>
        </label>
      )}

      <div style={{ flex: '1 1 auto', minWidth: '20px' }} />

      {canCreateProject && (
        <button className="btn primary sm" onClick={onNew} style={{ flex: '0 0 auto' }}>
          <Ic d={ICONS.plus} size={15} /> Проект
        </button>
      )}
    </div>
  );
}