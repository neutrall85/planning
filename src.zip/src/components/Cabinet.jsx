// components/Cabinet.jsx
import React, { useState, useMemo, useRef } from 'react';
import { TASK_STATUSES, TASK_STATUS_ORDER, VACATION_TYPES } from '../utils/constants';
import { TODAY, fmtDMY, fmtD, iso, addDays, initials, isTaskActive } from '../utils/date';
import { useDataHelpers } from '../hooks';
import { Ic, ICONS } from './Icons';
import { useToast } from '../context/ToastContext';
import { useConfirm } from '../context/ConfirmContext';
import { useServices } from '../context/ServicesContext';

function downloadCSV(name, rows) {
  const csv = '\uFEFF' + rows.map(r => r.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name.endsWith('.csv') ? name : name + '.csv';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 500);
}

export default function Cabinet({ store, data, user, openTask, openProject, openVacation, openDelegation }) {
  const services = useServices();
  const { showToast } = useToast();
  const { showConfirm } = useConfirm();
  const { empName, getEmployeeLoad } = useDataHelpers(data);
  const [tab, setTab] = useState('overview');

  const [expFrom, setExpFrom] = useState('');
  const [expTo, setExpTo] = useState('');

  const myTasks = data.tasks.filter(t => isTaskActive(t) && (t.assigneeIds || []).includes(user.id) && !user.fired);
  const myProjects = [...new Set(myTasks.map(t => t.projectId))].map(id => data.projects.find(p => p.id === id)).filter(Boolean);
  const myVacs = data.vacations.filter(v => v.empId === user.id);
  const myDeleg = data.roleDelegations.filter(r => r.fromId === user.id || r.toId === user.id);

  const range = 20;
  const days = [];
  for (let i = range - 1; i >= 0; i--) days.push(iso(addDays(new Date(), -i)));

  const taskTableData = useMemo(() => {
    return myTasks.map(t => {
      const logMap = {};
      t.logs.forEach(l => {
        logMap[l.date] = (logMap[l.date] || 0) + l.hours;
      });
      return { task: t, logMap };
    });
  }, [myTasks]);

  const exportMyReport = () => {
    if (!expFrom || !expTo) {
      showToast('Выберите даты начала и окончания периода', 'err');
      return;
    }
    if (expFrom > expTo) {
      showToast('Дата начала не может быть позже даты окончания', 'err');
      return;
    }

    const allLogs = [];
    myTasks.forEach(t => {
      const project = data.projects.find(p => p.id === t.projectId);
      t.logs.forEach(l => {
        if (l.date >= expFrom && l.date <= expTo) {
          allLogs.push({
            date: l.date,
            hours: l.hours,
            task: t.title,
            project: project?.code || '—'
          });
        }
      });
    });

    if (!allLogs.length) {
      showToast('За выбранный период нет учтенных часов', 'err');
      return;
    }

    const rows = [['Проект', 'Задача', 'Дата', 'Часы']];
    allLogs.forEach(l => rows.push([l.project, l.task, fmtDMY(l.date), l.hours]));
    downloadCSV(`отчет_${user.last}_${expFrom}_${expTo}`, rows);
    showToast('Отчёт выгружен!');
  };

  const tabs = [
    ['overview', 'Сводка'],
    ['vacations', 'Мои отпуска'],
    ['delegation', 'Делегирование ролей'],
    ['profile', 'Профиль и уведомления']
  ];

  const changePassword = () => {
    const newPass = window.prompt('Введите новый пароль:');
    if (!newPass) return;
    try {
      services.employee.updateEmployee(user.id, { pass: newPass });
      showToast('Пароль изменён. На вашу почту отправлено подтверждение.');
    } catch (error) {
      showToast(error.message, 'err');
    }
  };

  const fileInputRef = useRef(null);
  const handlePhotoUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const photoData = ev.target.result;
      services.employee.updateEmployee(user.id, { photo: photoData });
      showToast('Фото загружено');
    };
    reader.readAsDataURL(file);
  };
  
  const handlePhotoDelete = () => {
    showConfirm('Удалить фото?', () => {
      services.employee.updateEmployee(user.id, { photo: null });
      showToast('Фото удалено');
    });
  };

  return (
    <div className="cab">
      <div className="tabs">
        {tabs.map(([id, label]) => (
          <button key={id} className={`tab${tab === id ? ' on' : ''}`} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>

      {tab === 'overview' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          
          <div className="rep-panel">
            <div className="rep-panel-title">Затраченные часы по задачам (последние 20 дней)</div>
            <div className="toolbar" style={{ marginBottom: 12, display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <span className="mut sm">Экспорт:</span>
              <input className="inp" type="date" style={{ width: 150 }} value={expFrom} onChange={e => setExpFrom(e.target.value)} />
              <span className="mut sm">—</span>
              <input className="inp" type="date" style={{ width: 150 }} value={expTo} onChange={e => setExpTo(e.target.value)} />
              <button className="btn primary sm" onClick={exportMyReport}>
                <Ic d={ICONS.download} size={13} /> Выгрузить в Excel (CSV)
              </button>
            </div>

            <div style={{ width: '100%', overflowX: 'auto' }}>
              <table className="tbl" style={{ width: '100%', minWidth: '700px', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    <th style={{ minWidth: '200px', textAlign: 'left', borderBottom: '1px solid var(--line)' }}>Задача</th>
                    {days.map(d => (
                      <th key={d} style={{ textAlign: 'center', minWidth: '60px', borderBottom: '1px solid var(--line)', fontSize: '11px', color: 'var(--mut)' }}>
                        {fmtD(d)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {taskTableData.map(({ task, logMap }) => (
                    <tr key={task.id} style={{ cursor: 'pointer' }} onClick={() => openTask(task.id)}>
                      <td style={{ textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #f1f5f9' }}>
                        {task.title}
                        <span className="mut sm" style={{ marginLeft: 8, fontWeight: 400 }}>
                          ({data.projects.find(p => p.id === task.projectId)?.code || '—'})
                        </span>
                      </td>
                      {days.map(d => (
                        <td key={d} style={{ textAlign: 'center', borderBottom: '1px solid #f1f5f9' }}>
                          {logMap[d] ? <b>{logMap[d]} ч</b> : ''}
                        </td>
                      ))}
                    </tr>
                  ))}
                  {taskTableData.length === 0 && (
                    <tr><td colSpan={days.length + 1} className="mut" style={{ textAlign: 'center', padding: 20 }}>Нет учтённых часов</td></tr>
                  )}
                  {taskTableData.length > 0 && (
                    <tr>
                      <td style={{ fontWeight: 700, borderTop: '2px solid var(--line)' }}>Итого за период</td>
                      {days.map(d => {
                        const total = taskTableData.reduce((sum, row) => sum + (row.logMap[d] || 0), 0);
                        return (
                          <td key={d} style={{ textAlign: 'center', fontWeight: 700, borderTop: '2px solid var(--line)' }}>
                            {total > 0 ? `${total} ч` : ''}
                          </td>
                        );
                      })}
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rep-panel">
            <div className="rep-panel-title">Мои задачи по статусам</div>
            {TASK_STATUS_ORDER.map(st => {
              const list = myTasks.filter(t => t.status === st);
              if (!list.length) return null;
              return (
                <div key={st} className="cab-stat">
                  <div className="cab-stat-head">
                    <span className="kdot" style={{ background: TASK_STATUSES[st].color }} />
                    {TASK_STATUSES[st].label}
                    <span className="kcount">{list.length}</span>
                  </div>
                  {list.map(t => (
                    <div key={t.id} className="cab-task" onClick={() => openTask(t.id)}>
                      <span className="pdot" style={{ background: data.projects.find(p => p.id === t.projectId)?.color }} />
                      {t.title}
                      <span className="mut sm"> · {t.deadline ? `до ${fmtD(t.deadline)}` : 'без дедлайна'} · {t.plannedHours ?? '—'} ч</span>
                    </div>
                  ))}
                </div>
              );
            })}
            {myTasks.length === 0 && <div className="mut">Задач пока нет</div>}
          </div>

          <div className="rep-panel">
            <div className="rep-panel-title">Мои проекты</div>
            {myProjects.map(p => (
              <div key={p.id} className="cab-proj" onClick={() => openProject(p.id)} style={{ cursor: 'pointer' }}>
                <span className="pdot" style={{ background: p.color }} />
                {p.code} — {p.name}
                {p.ptype === 'admin' && <span className="adm-badge" style={{ marginLeft: 8 }}>адм</span>}
              </div>
            ))}
            {myProjects.length === 0 && <div className="mut">Нет участия в проектах</div>}
          </div>

        </div>
      )}

      {tab === 'vacations' && (
        <div className="rep-panel">
          <div className="rep-panel-title">
            Мои отпуска
            <button className="btn primary sm" style={{ marginLeft: 'auto' }} onClick={() => openVacation(null)}>
              <Ic d={ICONS.plus} size={13} /> Добавить отпуск
            </button>
          </div>
          <table className="tbl">
            <thead><tr><th>Начало</th><th>Окончание</th><th>Тип</th><th>Комментарий</th><th>Делегирование</th><th>Статус</th><th></th></tr></thead>
            <tbody>
              {myVacs.map(v => {
                const started = v.start <= TODAY;
                return (
                  <tr key={v.id}>
                    <td>{fmtDMY(v.start)}</td><td>{fmtDMY(v.end)}</td>
                    <td>{VACATION_TYPES[v.type]}</td>
                    <td>{v.comment || '—'}</td>
                    <td>{v.delegation.enabled ? `→ ${empName(v.delegation.subId)}` : '—'}</td>
                    <td><span className={`st-chip ${v.status}`}>
                      {{ pending: 'На утверждении', approved: 'Утверждён', rejected: 'Отклонён' }[v.status]}
                    </span></td>
                    <td>
                      {!started && v.status !== 'rejected' ? (
                        <>
                          <button className="icon-btn" onClick={() => openVacation(v.id)}><Ic d={ICONS.edit} size={14} /></button>
                          <button 
                            className="icon-btn danger" 
                            onClick={() => {
                              showConfirm(`Удалить отпуск с ${fmtDMY(v.start)} по ${fmtDMY(v.end)}?`, () => {
                                services.vacation.deleteVacation(v.id);
                                showToast('Отпуск удалён');
                              });
                            }}
                          >
                            <Ic d={ICONS.trash} size={14} />
                          </button>
                        </>
                      ) : <span className="mut sm">{started ? 'изменение через HR/администратора' : ''}</span>}
                    </td>
                  </tr>
                );
              })}
              {myVacs.length === 0 && <tr><td colSpan="7" className="mut">Отпусков нет</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'delegation' && (
        <div className="rep-panel">
          <div className="rep-panel-title">
            Временная передача ролей
            <button className="btn primary sm" style={{ marginLeft: 'auto' }} onClick={openDelegation}>
              <Ic d={ICONS.plus} size={13} /> Делегировать роль
            </button>
          </div>
          <p className="mut sm">Роли «Суперадминистратор» и «Генеральный директор» делегируются только через суперадминистратора. Получатель должен подтвердить принятие.</p>
          <table className="tbl">
            <thead><tr><th>От кого</th><th>Кому</th><th>Роли</th><th>Период</th><th>Статус</th><th></th></tr></thead>
            <tbody>
              {myDeleg.map(r => (
                <tr key={r.id}>
                  <td>{empName(r.fromId)}</td><td>{empName(r.toId)}</td>
                  <td>{r.roles.join(', ')}</td>
                  <td>{fmtDMY(r.start)} — {r.end ? fmtDMY(r.end) : 'до отмены'}</td>
                  <td><span className={`st-chip ${r.status}`}>
                    {{ pending: 'Ожидает принятия', active: 'Активно', rejected: 'Отклонено', revoked: 'Отозвано', expired: 'Истекло' }[r.status]}
                  </span></td>
                  <td>{r.status === 'active' && r.fromId === user.id && <button className="btn ghost sm" onClick={() => { /* revoke */ }}>Отозвать</button>}</td>
                </tr>
              ))}
              {myDeleg.length === 0 && <tr><td colSpan="6" className="mut">Делегирований нет</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'profile' && (
        <div className="cab-grid">
          <div className="rep-panel">
            <div className="rep-panel-title">Личные данные</div>
            <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
              <div style={{ flex: '0 0 140px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                {user.photo ? (
                  <img src={user.photo} alt="Аватар" style={{ width: 120, height: 120, borderRadius: '50%', objectFit: 'cover', border: '1px solid var(--line)' }} />
                ) : (
                  <div style={{ width: 120, height: 120, borderRadius: '50%', background: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 12 }}>Нет фото</div>
                )}
                <input type="file" accept="image/*" ref={fileInputRef} style={{ display: 'none' }} onChange={handlePhotoUpload} />
                <button className="btn primary sm" onClick={() => fileInputRef.current?.click()}>Загрузить фото</button>
                {user.photo && <button className="btn ghost sm" onClick={handlePhotoDelete}>Удалить фото</button>}
              </div>

              <div style={{ flex: 1, minWidth: 300 }}>
                <div className="form-grid">
                  <label className="lbl">Фамилия</label>
                  <input className="inp" disabled value={user.last} />
                  <label className="lbl">Имя</label>
                  <input className="inp" disabled value={user.first} />
                  
                  <label className="lbl">E-mail</label>
                  <div className="duo">
                    <input className="inp" disabled value={user.email + '@volga-dnepr.com'} />
                    <button className="btn ghost sm" onClick={() => showToast('Письмо подтверждения отправлено на новый адрес (заглушка)')}>изменить</button>
                  </div>
                  
                  <label className="lbl">Мобильный телефон</label>
                  <input className="inp" value={user.phone} onChange={e => {
                    services.employee.updateEmployee(user.id, { phone: e.target.value });
                  }} />

                  <label className="lbl">Внутренний номер телефона *</label>
                  <input
                    className="inp"
                    value={user.extension || ''}
                    onChange={e => {
                      const val = e.target.value;
                      if (val.trim() === '') {
                        showToast('Внутренний номер телефона не может быть пустым', 'err');
                        return;
                      }
                      services.employee.updateEmployee(user.id, { extension: val.trim() });
                    }}
                    onBlur={e => {
                      if (!e.target.value.trim()) {
                        showToast('Внутренний номер телефона обязателен', 'err');
                      }
                    }}
                  />
                  
                  <label className="lbl">Табельный №</label>
                  <input className="inp" value={user.tab} onChange={e => {
                    services.employee.updateEmployee(user.id, { tab: e.target.value });
                  }} />
                  
                  <label className="lbl">Подразделения</label>
                  <div className="depts-readonly">
                    {user.departments.map(d => {
                      const dd = data.departments.find(x => x.id === d.deptId);
                      return dd ? <span key={d.deptId} className={`dept-chip${d.primary ? ' prim' : ''}`}>{dd.name}{d.primary ? ' · основное' : ''}</span> : null;
                    })}
                    {user.departments.length === 0 && <span className="mut sm">не назначены</span>}
                    <div className="mut sm" style={{ marginTop: 6 }}>Подразделения изменяют только HR-менеджер, суперадминистратор и генеральный директор.</div>
                  </div>
                  
                  <label className="lbl">Пароль</label>
                  <div className="duo">
                    <input className="inp" disabled value="••••••••" />
                    <button className="btn ghost sm" onClick={changePassword}>сменить</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="rep-panel">
            <div className="rep-panel-title">Уведомления</div>
            {[
              ['deadlineEmail', 'E-mail о сроках — за 3 дня до дедлайна задачи'],
              ['overdueDigest', 'Контроль просрочек — ежедневная сводка'],
              ['commentSub', 'Подписка на обсуждение задач, где я исполнитель или ответственный']
            ].map(([k, label]) => (
              <label key={k} className="toggle-row">
                <span>{label}</span>
                <span className={`toggle${user.notif[k] ? ' on' : ''}`} onClick={() => {
                  const updated = { ...user, notif: { ...user.notif, [k]: !user.notif[k] } };
                  services.employee.updateEmployee(user.id, updated);
                }}><span className="toggle-knob" /></span>
              </label>
            ))}
            <p className="mut sm">Критичные уведомления (восстановление пароля, утверждения) отключить нельзя.</p>

            <div className="rep-panel-title" style={{ marginTop: 16 }}>История делегирований</div>
            {data.roleDelegations.filter(r => r.fromId === user.id).map(r => (
              <div key={r.id} className="mut sm">→ {empName(r.toId)}: {r.roles.join(', ')} ({fmtDMY(r.start)} — {r.end ? fmtDMY(r.end) : 'до отмены'})</div>
            ))}
            {data.roleDelegations.filter(r => r.fromId === user.id).length === 0 && <div className="mut sm">Передач ролей не было</div>}
          </div>
        </div>
      )}
    </div>
  );
}